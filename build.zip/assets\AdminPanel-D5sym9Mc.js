import{c as R,r as h,a as j,j as e,B as Ce,U as ue,I as Ae,G as ye,P as wt,A as pe,m as ee,b as ca,M as Nt,X as de,u as Ct,E as ke,C as kt,F as At,d as Dt,e as pa,f as Et,g as St}from"./index-D3IyNygb.js";import{C as De,E as la}from"./eye-Dlh5fE4J.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ft=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],zt=R("arrow-left",Ft);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bt=[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]],oe=R("building-2",Bt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pt=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],le=R("circle-check",Pt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],Q=R("image",$t);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _t=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],Ut=R("key-round",_t);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qt=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],Ee=R("layers",qt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tt=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],Lt=R("layout-dashboard",Tt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ht=[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]],Rt=R("log-out",Ht);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mt=[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]],J=R("pen-line",Mt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],be=R("plus",Gt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],fe=R("save",Ot);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vt=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],Yt=R("search",Vt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wt=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],oa=R("settings",Wt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Qt=R("shield-check",Jt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xt=[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]],xa=R("sliders-vertical",Xt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zt=[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]],M=R("trash-2",Zt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]],re=R("upload",Kt),l={brand:"#6B3F1D",accent:"#E07B39",accentSoft:"#FDF0E6",surface:"#FFFFFF",bg:"#F4F1EE",border:"#E8E0D8",text:"#1A1208",muted:"#8A7A6A",danger:"#DC2626",dangerSoft:"#FEF2F2",success:"#16A34A",successSoft:"#F0FDF4"},V=t=>St(t),ma=({children:t,color:a=l.accent})=>e.jsx("span",{style:{background:a+"20",color:a},className:"admin-pill text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",children:t}),L=({onClick:t,danger:a,children:s,className:n="",title:d})=>e.jsx("button",{onClick:t,type:"button",title:d,"aria-label":d,className:`admin-icon-btn p-2 rounded-lg transition-all hover:scale-105 active:scale-95 ${a?"is-danger bg-red-50 text-red-500 hover:bg-red-100":"bg-gray-100 text-gray-600 hover:bg-gray-200"} ${n}`,children:s}),It=({note:t,onDismiss:a})=>e.jsx(pe,{children:t&&e.jsxs(ee.div,{role:"status","aria-live":"polite",initial:{opacity:0,y:-18,scale:.97},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-18,scale:.97},transition:{type:"spring",stiffness:420,damping:28},className:"mx-4 mt-4 flex max-w-2xl items-center gap-3 rounded-2xl border p-3 shadow-lg md:mx-6 lg:mx-8",style:{background:"#FFFFFF",borderColor:t.type==="error"?"#FECACA":"#BBF7D0",boxShadow:"0 18px 40px rgba(26, 18, 8, 0.18)"},children:[e.jsx("div",{className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",style:{background:t.type==="error"?l.dangerSoft:l.successSoft,color:t.type==="error"?l.danger:l.success},children:t.type==="error"?e.jsx(De,{size:21}):e.jsx(le,{size:21})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-[0.12em]",style:{color:t.type==="error"?l.danger:l.success},children:t.type==="error"?"Action needs attention":"Saved successfully"}),e.jsx("p",{className:"mt-0.5 break-words text-sm font-semibold leading-snug",style:{color:l.text},children:t.message})]}),e.jsx("button",{onClick:a,type:"button","aria-label":"Dismiss notification",className:"shrink-0 rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700",children:e.jsx(de,{size:17})})]})}),c=({label:t,hint:a,required:s,children:n})=>e.jsxs("div",{className:"admin-field flex flex-col gap-1.5",children:[e.jsxs("div",{className:"admin-field-label flex items-center gap-1.5",children:[e.jsx("label",{className:"text-[13px] font-bold tracking-wide",style:{color:l.text},children:t}),s&&e.jsx("span",{className:"text-red-500 text-xs font-bold",children:"*"})]}),a&&e.jsx("p",{className:"text-[11px] leading-relaxed",style:{color:l.muted},children:a}),n]}),je=({title:t,children:a})=>e.jsxs("div",{className:"space-y-4",children:[t&&e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"h-px flex-1",style:{background:l.border}}),e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.18em]",style:{color:l.muted},children:t}),e.jsx("div",{className:"h-px flex-1",style:{background:l.border}})]}),a]}),_="w-full px-4 py-3 rounded-xl border-2 bg-white text-sm text-gray-800 outline-none transition-all placeholder:text-gray-400",U={borderColor:"#E8E4DF"},ga="w-full py-3.5 rounded-xl text-sm font-bold text-white tracking-wide shadow-lg hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2",ha="flex-1 py-3.5 rounded-xl border-2 text-sm font-semibold text-gray-600 bg-white hover:bg-gray-50 transition-all",f=({className:t="",style:a={},...s})=>e.jsx("input",{...s,className:`${_} ${t} focus:border-amber-500 focus:ring-0`,style:{...U,...a}}),q=({className:t="",style:a={},...s})=>e.jsx("textarea",{...s,className:`${_} resize-none ${t} focus:border-amber-500 focus:ring-0`,style:{...U,...a}}),ne=({className:t="",style:a={},...s})=>e.jsx("select",{...s,className:`${_} ${t} focus:border-amber-500 focus:ring-0 cursor-pointer`,style:{...U,...a}}),ua=({show:t,onClose:a,title:s,subtitle:n,children:d})=>typeof document>"u"?null:ca.createPortal(e.jsx(pe,{children:t&&e.jsxs("div",{className:"admin-modal-overlay fixed inset-0 flex items-center justify-center p-4 sm:p-6",style:{fontFamily:"'DM Sans', sans-serif",zIndex:9999,minHeight:"100dvh",overflow:"hidden",padding:"clamp(14px, 2.4vw, 28px)"},children:[e.jsx("style",{children:`
            .form-scroll-container::-webkit-scrollbar {
              width: 8px !important;
              display: block !important;
            }
            .form-scroll-container::-webkit-scrollbar-track {
              background: #F0ECE7 !important;
              border-radius: 8px !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb {
              background: #6B3F1D !important;
              border-radius: 8px !important;
              border: 2px solid #F0ECE7 !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb:hover {
              background: #4A2B14 !important;
            }
            .form-scroll-container {
              overflow-y: auto !important;
              scrollbar-width: thin !important;
              scrollbar-color: #6B3F1D #F0ECE7 !important;
              -webkit-overflow-scrolling: touch;
              overscroll-behavior: contain;
              min-height: 0;
            }
            .admin-modal-overlay {
              align-items: center !important;
              justify-content: center !important;
              inset: 0 !important;
              width: 100vw !important;
              min-height: 100dvh !important;
            }
            .admin-modal-card {
              margin: 0 auto !important;
              width: min(720px, calc(100vw - 32px)) !important;
              max-height: calc(100dvh - 32px) !important;
              height: auto !important;
              border-radius: 18px !important;
              box-shadow: 0 30px 80px rgba(26, 18, 8, 0.32) !important;
            }
            .admin-modal-header {
              padding: 20px 24px !important;
              min-height: 78px;
              gap: 18px;
            }
            .admin-modal-header h3,
            .admin-modal-header p {
              margin: 0;
            }
            .admin-modal-header h3 {
              font-size: 18px !important;
              line-height: 1.2 !important;
            }
            .admin-modal-header p {
              margin-top: 6px !important;
              line-height: 1.35 !important;
            }
            .admin-modal-body {
              padding: 24px !important;
              max-height: calc(100dvh - 110px) !important;
              background: #FAFAF9 !important;
            }
            .admin-modal-body form .grid {
              display: grid !important;
              grid-template-columns: minmax(0, 1fr) !important;
              gap: 16px !important;
            }
            .admin-modal-body form {
              display: flex;
              flex-direction: column;
              gap: 22px;
            }
            .admin-modal-body form > * {
              margin-top: 0 !important;
              margin-bottom: 0 !important;
            }
            .admin-field {
              gap: 9px !important;
              min-width: 0;
            }
            .admin-field-label {
              min-height: 20px;
              align-items: center;
            }
            .admin-field-label label {
              line-height: 1.35 !important;
            }
            .admin-modal-body input,
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body label {
              max-width: 100%;
            }
            .admin-modal-body input,
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body .admin-field > label {
              min-height: 46px;
            }
            .admin-form-actions {
              position: sticky;
              bottom: -24px;
              z-index: 2;
              background: linear-gradient(180deg, rgba(250,250,249,0.88), #FAFAF9 35%);
              padding-top: 18px !important;
              padding-bottom: 2px;
            }
            .admin-form-actions button {
              min-height: 46px;
            }
            @media (min-width: 760px) {
              .admin-modal-body form .grid {
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
              }
              .admin-modal-body form .grid-cols-1 {
                grid-template-columns: minmax(0, 1fr) !important;
              }
            }
            @media (min-width: 1024px) {
              .admin-modal-overlay {
                padding: 28px !important;
              }
            }
            @media (max-width: 640px) {
              .admin-modal-card {
                border-radius: 14px !important;
                width: calc(100vw - 24px) !important;
                max-height: calc(100dvh - 24px) !important;
              }
              .admin-modal-header {
                padding: 16px !important;
                min-height: auto;
              }
              .admin-modal-body {
                padding: 16px !important;
                max-height: calc(100dvh - 88px) !important;
              }
              .admin-form-actions {
                flex-direction: column;
                bottom: -16px;
              }
              .admin-form-actions button {
                width: 100%;
                min-width: 0 !important;
              }
            }
          `}),e.jsx(ee.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:a,className:"fixed inset-0 bg-black/60 backdrop-blur-[3px]",style:{zIndex:0}}),e.jsxs(ee.div,{initial:{opacity:0,scale:.94,y:-20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.94,y:-20},transition:{duration:.22,ease:[.16,1,.3,1]},className:"admin-modal-card relative w-full rounded-2xl shadow-2xl overflow-hidden flex flex-col",style:{background:"#fff",zIndex:1,width:"min(720px, calc(100vw - 32px))",maxWidth:"720px",maxHeight:"calc(100dvh - 32px)",height:"auto",minHeight:0},children:[e.jsxs("div",{className:"admin-modal-header flex items-start justify-between px-7 py-5 border-b shrink-0",style:{borderColor:"#EDE9E4",background:"linear-gradient(135deg, #6B3F1D 0%, #8B5E3C 100%)"},children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-[17px] font-bold text-white leading-tight",children:s}),n&&e.jsx("p",{className:"text-sm mt-1 text-white/70",children:n})]}),e.jsx("button",{type:"button",onClick:a,className:"p-2 rounded-xl border border-white/20 hover:bg-white/10 transition shrink-0 ml-4 mt-0.5",children:e.jsx(de,{size:18,className:"text-white"})})]}),e.jsx("div",{className:"admin-modal-body px-6 sm:px-7 py-6 overflow-y-auto form-scroll-container flex-1",style:{background:"#FAFAF9",minHeight:0},children:d})]})]})}),document.body),ba="flex items-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed bg-white cursor-pointer hover:bg-amber-50 hover:border-amber-400 transition-all text-sm font-medium",G=({onCancel:t,submitLabel:a="Save Changes"})=>e.jsxs("div",{className:"admin-form-actions flex flex-col-reverse gap-3 pt-5 mt-2 border-t sm:flex-row sm:items-center sm:justify-end",style:{borderColor:"#EDE9E4"},children:[e.jsx("button",{type:"button",onClick:t,className:`${ha} w-full sm:w-auto`,style:{borderColor:"#D1C7BC",minWidth:"120px"},children:"Cancel"}),e.jsxs("button",{type:"submit",className:`${ga} w-full sm:w-auto sm:min-w-[180px]`,style:{background:"linear-gradient(135deg, #6B3F1D 0%, #9B6A43 100%)",justifyContent:"center"},children:[e.jsx(fe,{size:16}),a]})]}),ei=({editItem:t,programForm:a,setProgramForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a cover image","error");const r=new FormData;r.append("title",a.title||""),r.append("description",a.description||""),r.append("duration",a.duration||""),r.append("category",a.category||"Undergraduate"),r.append("courses",JSON.stringify(typeof a.courses=="string"?a.courses.split(",").map(x=>x.trim()).filter(Boolean):a.courses||[])),a.image instanceof File&&r.append("image",a.image);const u=t?`/programs/${t._id}`:"/programs";try{t?await j.put(u,r):await j.post(u,r),o(t?"Updated":"Created"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Program Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:i=>s({...a,title:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})}),e.jsx(c,{label:"Category",children:e.jsxs(ne,{value:a.category,onChange:i=>s({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate"}),e.jsx("option",{children:"Postgraduate"}),e.jsx("option",{children:"Diploma"})]})})]}),e.jsx(c,{label:"Description",required:!0,children:e.jsx(q,{required:!0,rows:3,value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Describe the program objectives, curriculum overview…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Duration",children:e.jsx(f,{value:a.duration,onChange:i=>s({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsxs(c,{label:"Cover Image",children:[e.jsxs("label",{className:ba,style:{color:"#6B7280"},children:[e.jsx(Q,{size:16,style:{color:l.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose image file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>s({...a,image:i.target.files[0]})})]}),a.image instanceof File?e.jsx("img",{src:URL.createObjectURL(a.image),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"preview"}):t?.imageUrl?e.jsx("img",{src:V(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"current"}):null]})]}),e.jsx(c,{label:"Courses (comma separated)",hint:"e.g.  Anatomy, Physiology, Microbiology",children:e.jsx(q,{rows:2,value:a.courses,onChange:i=>s({...a,courses:i.target.value})})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Create Program"})]}),ai=({editItem:t,testimonialForm:a,setTestimonialForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a photo","error");const r=new FormData;Object.entries(a).forEach(([x,k])=>{x==="image"&&k instanceof File?r.append("image",k):x!=="image"&&r.append(x,k)});const u=t?`/testimonials/${t._id}`:"/testimonials";try{t?await j.put(u,r):await j.post(u,r),o(t?"Updated":"Created"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Student Name",required:!0,children:e.jsx(f,{required:!0,value:a.name,onChange:i=>s({...a,name:i.target.value}),placeholder:"Full name"})}),e.jsx(c,{label:"Role / Batch",required:!0,children:e.jsx(f,{required:!0,value:a.role,onChange:i=>s({...a,role:i.target.value}),placeholder:"e.g. B.Sc. Nursing 2023"})})]}),e.jsx(c,{label:"Testimonial",required:!0,children:e.jsx(q,{required:!0,rows:4,value:a.content,onChange:i=>s({...a,content:i.target.value}),placeholder:"Student's review about the college…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Rating (1–5)",children:e.jsx(f,{type:"number",min:1,max:5,value:a.rating,onChange:i=>s({...a,rating:parseInt(i.target.value)})})}),e.jsx(c,{label:"Student Photo",children:e.jsxs("label",{className:ba,style:{color:"#6B7280"},children:[e.jsx(Q,{size:16,style:{color:l.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose photo file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>s({...a,image:i.target.files[0]})})]})})]}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Testimonial"})]}),ti=({editItem:t,milestoneForm:a,setMilestoneForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/about/milestones/${t._id}`:"/about/milestones";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[e.jsx(c,{label:"Year",required:!0,children:e.jsx(f,{required:!0,value:a.year,onChange:i=>s({...a,year:i.target.value}),placeholder:"1963"})}),e.jsx(c,{label:"Icon (emoji)",children:e.jsx(f,{value:a.icon,onChange:i=>s({...a,icon:i.target.value})})}),e.jsx(c,{label:"Sort Order",children:e.jsx(f,{type:"number",min:"0",step:"1",value:a.order,onChange:i=>s({...a,order:Math.max(0,parseInt(i.target.value,10)||0)})})})]}),e.jsx(c,{label:"Event Title",required:!0,children:e.jsx(f,{required:!0,value:a.event,onChange:i=>s({...a,event:i.target.value}),placeholder:"e.g. College Established"})}),e.jsx(c,{label:"Accent Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:i=>s({...a,color:i.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(f,{value:a.color,onChange:i=>s({...a,color:i.target.value})})]})}),e.jsx(c,{label:"Description",required:!0,children:e.jsx(q,{required:!0,rows:3,value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Brief description of this milestone…"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Milestone"})]}),ii=({editItem:t,vmForm:a,setVmForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/about/vision-mission/${t._id}`:"/about/vision-mission";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(c,{label:"Statement Type",children:e.jsxs(ne,{value:a.type,onChange:i=>s({...a,type:i.target.value}),children:[e.jsx("option",{value:"vision",children:"🔭 Vision"}),e.jsx("option",{value:"mission",children:"🎯 Mission"})]})}),e.jsx(c,{label:"Sort Order",children:e.jsx(f,{type:"number",value:a.order||0,onChange:i=>s({...a,order:parseInt(i.target.value)||0})})})]}),e.jsx(c,{label:"Content",required:!0,children:e.jsx(q,{required:!0,rows:5,value:a.content,onChange:i=>s({...a,content:i.target.value}),placeholder:"Enter the statement content…"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Statement"})]}),si=({editItem:t,cvForm:a,setCvForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/about/core-values/${t._id}`:"/about/core-values";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(c,{label:"Value Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:i=>s({...a,title:i.target.value}),placeholder:"e.g. Excellence"})}),e.jsx(c,{label:"Icon (emoji)",children:e.jsx(f,{value:a.icon,onChange:i=>s({...a,icon:i.target.value})})})]}),e.jsx(c,{label:"Description",required:!0,children:e.jsx(q,{required:!0,rows:4,value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Brief description of this value…"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Core Value"})]}),ri=({editItem:t,courseForm:a,setCourseForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/courses/${t._id}`:"/courses",u={...a,highlights:typeof a.highlights=="string"?a.highlights.split(",").map(x=>x.trim()).filter(Boolean):a.highlights};try{t?await j.put(r,u):await j.post(r,u),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx("div",{className:"sm:col-span-2",children:e.jsx(c,{label:"Course Name",required:!0,children:e.jsx(f,{required:!0,value:a.name,onChange:i=>s({...a,name:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})})}),e.jsx(c,{label:"Icon",children:e.jsx(f,{value:a.icon,onChange:i=>s({...a,icon:i.target.value})})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(c,{label:"Category",children:e.jsxs(ne,{value:a.category,onChange:i=>s({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate Programs"}),e.jsx("option",{children:"Postgraduate Programs"}),e.jsx("option",{children:"Diploma Programs"})]})}),e.jsx(c,{label:"Duration",children:e.jsx(f,{value:a.duration,onChange:i=>s({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsx(c,{label:"Seats",children:e.jsx(f,{value:a.seats,onChange:i=>s({...a,seats:i.target.value}),placeholder:"e.g. 60"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Annual Fees",children:e.jsx(f,{value:a.fees,onChange:i=>s({...a,fees:i.target.value}),placeholder:"e.g. ₹50,000"})}),e.jsx(c,{label:"Official Website Link",children:e.jsx(f,{value:a.websiteLink,onChange:i=>s({...a,websiteLink:i.target.value}),placeholder:"https://…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Brief Description",children:e.jsx(q,{rows:3,value:a.description||"",onChange:i=>s({...a,description:i.target.value}),placeholder:"Short overview of the course…"})}),e.jsx(c,{label:"Eligibility",children:e.jsx(q,{rows:3,value:a.eligibility,onChange:i=>s({...a,eligibility:i.target.value}),placeholder:"Who can apply…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Highlights",hint:"Comma separated",children:e.jsx(q,{rows:2,value:a.highlights,onChange:i=>s({...a,highlights:i.target.value})})}),e.jsx(c,{label:"Admission Method",children:e.jsx(q,{rows:2,value:a.admission||"",onChange:i=>s({...a,admission:i.target.value})})})]}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Course"})]}),ni=({editItem:t,stepForm:a,setStepForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/admission-steps/${t._id}`:"/admission-steps";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(c,{label:"Step Number",required:!0,children:e.jsx(f,{type:"number",required:!0,value:a.step,onChange:i=>s({...a,step:parseInt(i.target.value)})})}),e.jsx(c,{label:"Icon",children:e.jsx(ne,{value:a.icon,onChange:i=>s({...a,icon:i.target.value}),children:["Calendar","Users","CheckCircle","GraduationCap","FileText","Download"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(c,{label:"Step Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:i=>s({...a,title:i.target.value}),placeholder:"e.g. Submit Application Form"})}),e.jsx(c,{label:"Description",required:!0,children:e.jsx(q,{required:!0,rows:4,value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Explain what the applicant needs to do in this step…"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Step"})]}),li=({editItem:t,ruleForm:a,setRuleForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/admission-rules/${t._id}`:"/admission-rules";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Category",children:e.jsxs(ne,{value:a.category,onChange:i=>s({...a,category:i.target.value}),children:[e.jsx("option",{children:"UnderGraduated Programs"}),e.jsx("option",{children:"PostGraduated Programs"}),e.jsx("option",{children:"General Rules"})]})}),e.jsx(c,{label:"Icon",children:e.jsx(ne,{value:a.icon,onChange:i=>s({...a,icon:i.target.value}),children:["CheckCircle","Calendar","Stethoscope","GraduationCap","Info"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(c,{label:"Rule Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:i=>s({...a,title:i.target.value}),placeholder:"e.g. Minimum Percentage Required"})}),e.jsx(c,{label:"Description",required:!0,children:e.jsx(q,{required:!0,rows:4,value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Full explanation of this rule…"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Rule"})]}),oi=({editItem:t,bondForm:a,setBondForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=t?`/bonds/${t._id}`:"/bonds";try{t?await j.put(r,a):await j.post(r,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsx(c,{label:"Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:i=>s({...a,title:i.target.value}),placeholder:"e.g. Government Bond Agreement"})}),e.jsx(c,{label:"Content",required:!0,children:e.jsx(q,{required:!0,rows:5,value:a.content,onChange:i=>s({...a,content:i.target.value}),placeholder:"Bond details and conditions…"})}),e.jsx(c,{label:"Display Order",children:e.jsx(f,{type:"number",value:a.order,onChange:i=>s({...a,order:parseInt(i.target.value)||0})})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Bond"})]}),di=({editItem:t,guidelineForm:a,setGuidelineForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r={...a,points:typeof a.points=="string"?a.points.split(`
`).map(x=>x.trim()).filter(Boolean):a.points},u=t?`/guidelines/${t._id}`:"/guidelines";try{t?await j.put(u,r):await j.post(u,r),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Category",children:e.jsx(ne,{value:a.category,onChange:i=>s({...a,category:i.target.value}),children:["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(i=>e.jsx("option",{children:i},i))})}),e.jsx(c,{label:"Sub-Category / Title",required:!0,children:e.jsx(f,{required:!0,value:a.subCategory,onChange:i=>s({...a,subCategory:i.target.value}),placeholder:"e.g. Dress Code Policy"})})]}),e.jsx(c,{label:"Points",hint:"Enter one point per line — each line becomes a separate bullet",children:e.jsx(q,{required:!0,rows:7,value:a.points,onChange:i=>s({...a,points:i.target.value}),placeholder:`Guideline point 1
Guideline point 2
Guideline point 3`})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Guideline"})]}),ci=({editItem:t,deptForm:a,setDeptForm:s,closeModal:n,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const r=new FormData;r.append("name",a.name||""),r.append("slug",a.slug||""),r.append("category",a.category||"Nursing Department"),r.append("description",a.description||""),a.logo instanceof File&&r.append("logo",a.logo);const u=t?`/departments/${t._id}`:"/departments";try{t?await j.put(u,r):await j.post(u,r),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"flex flex-col items-center gap-3 py-5 px-6 rounded-2xl border-2 border-dashed",style:{borderColor:"#D1C7BC",background:"#FDFCFB"},children:[a.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(a.logo),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"preview"}):t?.logoUrl?e.jsx("img",{src:V(t.logoUrl),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"logo"}):e.jsx("div",{className:"w-20 h-20 rounded-2xl flex items-center justify-center text-4xl",style:{background:l.accentSoft},children:"🏥"}),e.jsxs("label",{className:"flex items-center gap-2 px-5 py-2.5 rounded-xl cursor-pointer text-sm font-semibold text-white shadow hover:opacity-90 transition-all",style:{background:l.brand},children:[e.jsx(re,{size:15}),a.logo instanceof File?"Change Logo":t?.logoUrl?"Replace Logo":"Upload Department Logo",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:i=>s({...a,logo:i.target.files[0]})})]}),e.jsx("p",{className:"text-xs",style:{color:l.muted},children:"PNG, JPG or WEBP · Recommended 200×200px"})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Department Name",required:!0,children:e.jsx(f,{required:!0,value:a.name,onChange:i=>s({...a,name:i.target.value}),placeholder:"e.g. Fundamentals of Nursing"})}),e.jsx(c,{label:"URL Slug",hint:"Unique ID — no spaces",children:e.jsx(f,{required:!0,value:a.slug,onChange:i=>s({...a,slug:i.target.value.toLowerCase().replace(/\s+/g,"-")}),placeholder:"e.g. fundamentals"})})]}),e.jsx(c,{label:"Category",children:e.jsx(f,{required:!0,value:a.category,onChange:i=>s({...a,category:i.target.value}),placeholder:"e.g. Nursing Department"})}),e.jsx(c,{label:"Short Description",children:e.jsx(f,{value:a.description,onChange:i=>s({...a,description:i.target.value}),placeholder:"Brief description of the department"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Update Department":"Create Department"})]}),pi=({editItem:t,scForm:a,setScForm:s,closeModal:n,fetchData:d,notify:o})=>{const i=()=>s(x=>({...x,items:[...x.items||[],""]})),r=x=>s(k=>({...k,items:k.items.filter((g,y)=>y!==x)})),u=(x,k)=>s(g=>{const y=[...g.items||[]];return y[x]=k,{...g,items:y}});return e.jsxs("form",{onSubmit:async x=>{x.preventDefault();const k=t?`/student-corner/${t._id}`:"/student-corner";try{t?await j.put(k,a):await j.post(k,a),o(t?"Section updated":"Section created"),n(),d()}catch{o("Failed to save section","error")}},className:"space-y-5",children:[e.jsxs(je,{title:"Section Details",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Section Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:x=>s({...a,title:x.target.value}),placeholder:"e.g. Documents for Transcript"})}),e.jsx(c,{label:"Subtitle",children:e.jsx(f,{value:a.subtitle,onChange:x=>s({...a,subtitle:x.target.value}),placeholder:"e.g. All Xerox Copies Required"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(c,{label:"Tag / Badge Label",children:e.jsx(f,{value:a.tag,onChange:x=>s({...a,tag:x.target.value}),placeholder:"e.g. GNM Students"})}),e.jsx(c,{label:"Icon (emoji)",children:e.jsx(f,{value:a.icon,onChange:x=>s({...a,icon:x.target.value}),placeholder:"📄"})}),e.jsx(c,{label:"Sort Order",children:e.jsx(f,{type:"number",value:a.order,onChange:x=>s({...a,order:parseInt(x.target.value)||0})})})]}),e.jsx(c,{label:"Extra Description / Note",hint:"Optional note shown below the badge on the public page",children:e.jsx(q,{rows:2,value:a.description,onChange:x=>s({...a,description:x.target.value}),placeholder:"e.g. For GNM students completing their final year only"})})]}),e.jsx(je,{title:"Colors",children:e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(c,{label:"Main Color",hint:"Card accent & icon background",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:x=>s({...a,color:x.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(f,{value:a.color,onChange:x=>s({...a,color:x.target.value})})]})}),e.jsx(c,{label:"Border Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.borderColor,onChange:x=>s({...a,borderColor:x.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(f,{value:a.borderColor,onChange:x=>s({...a,borderColor:x.target.value})})]})}),e.jsx(c,{label:"Badge Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.badgeColor,onChange:x=>s({...a,badgeColor:x.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(f,{value:a.badgeColor,onChange:x=>s({...a,badgeColor:x.target.value})})]})})]})}),e.jsx(je,{title:"Document Items",children:e.jsxs("div",{className:"space-y-2",children:[(a.items||[]).map((x,k)=>e.jsxs("div",{className:"flex gap-2 items-center",children:[e.jsx("span",{className:"w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0",style:{background:a.color||"#F59E0B"},children:k+1}),e.jsx(f,{value:x,onChange:g=>u(k,g.target.value),placeholder:`Document item ${k+1}`,className:"flex-1"}),e.jsx("button",{type:"button",onClick:()=>r(k),className:"p-2 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition-all shrink-0",children:e.jsx(M,{size:15})})]},k)),e.jsxs("button",{type:"button",onClick:i,className:"w-full py-2.5 rounded-xl border-2 border-dashed text-sm font-semibold transition-all hover:bg-amber-50",style:{borderColor:"#D1C7BC",color:"#8A7A6A"},children:[e.jsx(be,{size:15,className:"inline mr-1"})," Add Document Item"]})]})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Create Section"})]})},xi=({sections:t,openModal:a,setScForm:s,del:n})=>{const d={title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0};return e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:ye,title:"Student Corner — Document Sections",subtitle:"Manage document requirement notices shown on the Student Corner page",action:e.jsx(W,{label:"Add Section",onClick:()=>{s({...d,order:t.length+1}),a("studentCorner")}})}),t.length===0?e.jsx(xe,{icon:ye,text:"No document sections yet — click 'Add Section' to create one"}):e.jsx("div",{className:"space-y-3",children:t.map((o,i)=>e.jsxs("div",{className:"flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:"#FFFFFF",border:"1px solid #E8E0D8"},children:[e.jsx("div",{style:{width:"48px",height:"48px",borderRadius:"14px",background:o.color||"#F59E0B",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"22px",flexShrink:0,boxShadow:`0 4px 12px ${o.color||"#F59E0B"}44`},children:o.icon||"📄"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap mb-0.5",children:[o.tag&&e.jsx("span",{className:"text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",style:{background:(o.badgeColor||"#D97706")+"22",color:o.badgeColor||"#D97706"},children:o.tag}),e.jsxs("span",{className:"text-[11px] font-semibold text-gray-400",children:["#",i+1," · ",(o.items||[]).length," items"]})]}),e.jsx("p",{className:"font-bold text-sm truncate",style:{color:"#1A1208"},children:o.title}),o.subtitle&&e.jsx("p",{className:"text-xs truncate mt-0.5",style:{color:"#8A7A6A"},children:o.subtitle})]}),e.jsx("div",{className:"hidden sm:flex gap-1.5 shrink-0",children:["color","borderColor","badgeColor"].map(r=>e.jsx("div",{style:{width:16,height:16,borderRadius:"50%",background:o[r]||"#ccc",border:"2px solid #F4F1EE"},title:r},r))}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[e.jsx(L,{title:"Edit",onClick:()=>{s({title:o.title||"",subtitle:o.subtitle||"",tag:o.tag||"",icon:o.icon||"📄",color:o.color||"#F59E0B",borderColor:o.borderColor||"#FCD34D",badgeColor:o.badgeColor||"#D97706",items:Array.isArray(o.items)?[...o.items]:[],description:o.description||"",order:o.order||0}),a("studentCorner",o)},children:e.jsx(J,{size:15})}),e.jsx(L,{danger:!0,title:"Delete",onClick:()=>n(`/student-corner/${o._id}`),children:e.jsx(M,{size:15})})]})]},o._id))}),e.jsxs("div",{className:"p-4 rounded-2xl flex items-start gap-3",style:{background:"#FFF7ED",border:"1.5px solid #FDE68A"},children:[e.jsx("span",{className:"text-xl shrink-0",children:"💡"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-bold",style:{color:"#92400e"},children:"Tips"}),e.jsxs("ul",{className:"text-xs mt-1 space-y-1",style:{color:"#78350f"},children:[e.jsxs("li",{children:["• Use ",e.jsx("strong",{children:"Sort Order"})," when editing to control display order on the public page."]}),e.jsxs("li",{children:["• To hide Student Corner from the site, go to ",e.jsx("strong",{children:"Section Control"})," and toggle it off."]}),e.jsx("li",{children:"• Each section supports its own emoji icon, custom colors, badge label, and unlimited document items."})]})]})]})]})},ve=({tabs:t,active:a,onChange:s})=>e.jsx("div",{className:"admin-subtabs",children:t.map(n=>e.jsx("button",{onClick:()=>s(n),type:"button",className:a===n?"is-active":"",children:n},n))}),Y=({icon:t,title:a,subtitle:s,action:n})=>e.jsxs("div",{className:"admin-section-header flex flex-col sm:flex-row sm:items-center gap-4 p-5 rounded-2xl",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0",children:[e.jsx("div",{className:"admin-section-icon w-10 h-10 rounded-xl flex items-center justify-center shrink-0",style:{background:l.accentSoft},children:e.jsx(t,{size:20,style:{color:l.accent}})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h3",{className:"admin-section-title font-bold text-base truncate",style:{color:l.text},children:a}),s&&e.jsx("p",{className:"admin-section-subtitle text-xs mt-0.5 truncate",style:{color:l.muted},children:s})]})]}),n]}),W=({onClick:t,label:a="Add New"})=>e.jsxs("button",{onClick:t,className:"admin-add-btn shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition-all shadow hover:opacity-90 active:scale-95",style:{background:l.brand},children:[e.jsx(be,{size:16}),a]}),ce=({icon:t,badge:a,title:s,sub:n,onEdit:d,onDelete:o,left:i})=>e.jsxs("div",{className:"admin-row-item flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:l.surface,border:`1px solid ${l.border}`},children:[i||e.jsx("div",{className:"admin-row-icon w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0",style:{background:l.accentSoft},children:t||"📌"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[a&&e.jsx("div",{className:"mb-0.5",children:e.jsx(ma,{children:a})}),e.jsx("p",{className:"admin-row-title font-bold text-sm truncate",style:{color:l.text},children:s}),n&&e.jsx("p",{className:"admin-row-subtitle text-xs truncate mt-0.5",style:{color:l.muted},children:n})]}),e.jsxs("div",{className:"admin-row-actions flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[d&&e.jsx(L,{onClick:d,title:"Edit",children:e.jsx(J,{size:15})}),o&&e.jsx(L,{onClick:o,danger:!0,title:"Delete",children:e.jsx(M,{size:15})})]})]}),xe=({icon:t,text:a})=>e.jsxs("div",{className:"flex flex-col items-center justify-center py-20 rounded-3xl border-2 border-dashed shadow-inner",style:{borderColor:l.border,background:l.surface},children:[e.jsx(t,{size:48,style:{color:l.muted},className:"mb-4 opacity-10"}),e.jsx("p",{className:"text-sm font-bold tracking-tight",style:{color:l.muted},children:a})]}),da=({onClose:t,activeTab:a,setActiveTab:s,selectedDept:n,setSelectedDept:d,navItems:o,onLogout:i})=>e.jsxs("div",{className:"flex flex-col min-h-0",style:{height:"100dvh",maxHeight:"100dvh"},children:[e.jsxs("div",{className:"flex items-center gap-3 p-6 border-b border-white/10 shrink-0",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shadow-inner",children:e.jsx(Lt,{size:20,className:"text-white"})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-white font-bold text-sm leading-tight truncate",children:"Ginera Admin"}),e.jsx("p",{className:"text-white/40 text-[10px] uppercase tracking-widest mt-0.5 font-medium",children:"Dashboard Console"})]}),t&&e.jsx("button",{onClick:t,className:"lg:hidden p-2 text-white/40 hover:text-white transition-colors",children:e.jsx(de,{size:20})})]}),e.jsxs("nav",{className:"flex-1 min-h-0 overflow-y-auto py-6 px-4 space-y-1 scrollbar-hide",style:{overscrollBehavior:"contain"},children:[o.map(({name:r,icon:u})=>{const x=a===r&&!n;return e.jsxs("button",{onClick:()=>{s(r),d(null),t&&t()},className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all group",style:{background:x?"rgba(255,255,255,0.12)":"transparent",color:x?"#fff":"rgba(255,255,255,0.55)"},children:[e.jsx(u,{size:18,className:`transition-transform ${x?"scale-110":"group-hover:scale-110"}`}),e.jsx("span",{className:"truncate",children:r}),x&&e.jsx(pa,{size:14,className:"ml-auto opacity-60"})]},r)}),n&&e.jsxs("div",{className:"mt-8 pt-6 border-t border-white/5 px-2",children:[e.jsx("p",{className:"text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-3 px-2",children:"Active Editor"}),e.jsxs("div",{className:"p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx("div",{className:"w-2 h-2 rounded-full bg-amber-400 animate-pulse"}),e.jsx("p",{className:"text-white text-xs font-bold truncate",children:n.name})]}),e.jsx("button",{onClick:()=>d(null),className:"w-full py-2.5 rounded-lg bg-white/10 text-[10px] font-bold text-white/70 hover:bg-white/20 transition-all border border-white/5 uppercase tracking-wider",children:"Exit Management"})]})]})]}),e.jsx("div",{className:"p-5 border-t border-white/10 shrink-0",children:e.jsxs("button",{onClick:i,className:"w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold text-red-300 hover:bg-red-500/20 transition-all active:scale-95",children:[e.jsx(Rt,{size:18})," Sign Out"]})})]}),mi=({isMobile:t,sidebarOpen:a,setSidebarOpen:s,...n})=>e.jsxs(e.Fragment,{children:[!t&&e.jsx("aside",{className:"admin-sidebar flex flex-col w-80 shrink-0 self-stretch border-r border-black/10",style:{background:l.brand,width:"320px",height:"100%",minHeight:"100dvh",maxHeight:"100dvh"},children:e.jsx(da,{onClose:null,...n})}),t&&typeof document<"u"&&ca.createPortal(e.jsx(pe,{children:a&&e.jsxs(e.Fragment,{children:[e.jsx(ee.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>s(!1),className:"fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm",style:{position:"fixed",top:0,right:0,bottom:0,left:0}}),e.jsx(ee.aside,{initial:{x:-340},animate:{x:0},exit:{x:-340},transition:{type:"tween",duration:.3},className:"admin-sidebar fixed inset-y-0 left-0 z-[10000] w-80 flex flex-col shadow-2xl",style:{background:l.brand,position:"fixed",top:0,bottom:0,left:0,width:"min(320px, 86vw)",height:"100dvh",maxHeight:"100dvh",zIndex:1e4},children:e.jsx(da,{onClose:()=>s(!1),...n})})]})}),document.body)]}),gi=({show:t,onClose:a,notify:s})=>{const[n,d]=h.useState(""),[o,i]=h.useState(""),[r,u]=h.useState(!1),[x,k]=h.useState(!1),[g,y]=h.useState(""),P=n.length>8,D=/[!@#$%^&*(),.?":{}|<>_\-+=\\/[\]~`]/.test(n),S=n.length>0&&n===o,F=P&&D&&S,v=()=>{d(""),i(""),u(!1),k(!1),y(""),a()},b=w=>{if(w.preventDefault(),!P){y("New password must be greater than 8 characters (at least 9 characters).");return}if(!D){y("New password must contain at least one unique special character (e.g., @, #, $, %, !).");return}if(n!==o){y("Passwords do not match. Please ensure both fields are identical.");return}localStorage.setItem("adminPassword",n),s("Admin password successfully updated!"),v()};return e.jsx(ua,{show:t,onClose:v,title:"Reset Admin Password",subtitle:"Update credentials to maintain secure administrative access",children:e.jsxs("form",{onSubmit:b,className:"space-y-4",children:[g&&e.jsxs("div",{className:"flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-semibold",children:[e.jsx(De,{size:16,className:"shrink-0"}),e.jsx("span",{children:g})]}),e.jsx(c,{label:"New Password",required:!0,hint:"Must be greater than 8 characters with at least one unique special character",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:r?"text":"password",value:n,onChange:w=>{d(w.target.value),g&&y("")},placeholder:"Enter new strong password",className:_,style:{...U,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>u(w=>!w),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:r?"Hide password":"Show password",children:r?e.jsx(ke,{size:18}):e.jsx(la,{size:18})})]})}),e.jsx(c,{label:"Confirm New Password",required:!0,hint:"Re-enter the exact same new password",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:x?"text":"password",value:o,onChange:w=>{i(w.target.value),g&&y("")},placeholder:"Re-enter new password",className:_,style:{...U,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>k(w=>!w),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:x?"Hide password":"Show password",children:x?e.jsx(ke,{size:18}):e.jsx(la,{size:18})})]})}),e.jsxs("div",{className:"p-3.5 rounded-xl border bg-amber-50/40 border-amber-200/60 space-y-2 text-xs",children:[e.jsx("p",{className:"font-bold text-gray-700 uppercase tracking-wider text-[11px]",children:"Password Security Requirements:"}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${P?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(le,{size:15,className:P?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Greater than 8 characters (at least 9 characters long)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${D?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(le,{size:15,className:D?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"At least 1 unique/special character (e.g. @, #, $, %, !, &, *)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${S?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(le,{size:15,className:S?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Passwords match in both fields"})]})]}),e.jsxs("div",{className:"admin-form-actions flex gap-3 pt-3",children:[e.jsx("button",{type:"button",onClick:v,className:ha,children:"Cancel"}),e.jsxs("button",{type:"submit",disabled:!F,className:ga,style:{background:F?l.brand:"#B5ACA2",cursor:F?"pointer":"not-allowed"},children:[e.jsx(Qt,{size:18}),"Reset Password"]})]})]})})},hi=({setSidebarOpen:t,selectedDept:a,activeTab:s,onOpenResetPassword:n})=>e.jsxs("header",{className:"admin-header h-14 lg:h-16 flex items-center px-4 lg:px-6 border-b shrink-0 z-10",style:{background:l.surface,borderColor:l.border},children:[e.jsx("button",{onClick:()=>t(!0),className:"p-2 rounded-xl hover:bg-gray-100 lg:hidden mr-3 transition",style:{color:l.muted},children:e.jsx(Nt,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h2",{className:"font-bold text-base lg:text-lg truncate",style:{color:l.text},children:a?a.name:s}),e.jsx("p",{className:"text-xs hidden sm:block",style:{color:l.muted},children:a?"Department management console":`Manage ${s.toLowerCase()} system content`})]}),e.jsxs("div",{className:"ml-auto flex items-center gap-2 sm:gap-3",children:[e.jsxs("button",{type:"button",onClick:n,title:"Reset Admin Password",className:"flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 rounded-xl border transition-all text-xs font-semibold shadow-xs hover:shadow-sm hover:scale-[1.02] active:scale-[0.98]",style:{background:"#FFF8F3",borderColor:"#EAD5C5",color:l.brand},children:[e.jsx(Ut,{size:15,style:{color:l.accent}}),e.jsx("span",{className:"hidden sm:inline",children:"Reset Password"})]}),e.jsxs("span",{className:"admin-header-chip hidden md:inline-flex",children:[e.jsx("span",{className:"admin-header-dot"}),"Live Admin"]})]})]}),ui=({selectedDeptForSlider:t,setSelectedDeptForSlider:a,departments:s,sliders:n,handleSliderUpload:d,updateSliderImage:o,del:i})=>{const r=n.filter(g=>t==="null"?!g.department:g.department?._id===t),u=t==="null"?"Homepage Sliders":s.find(g=>g._id===t)?.name||"Department Sliders",x=(g,y)=>`${t==="null"?"Homepage Slider":`${s.find(D=>D._id===t)?.name||"Department"} Slider`} #${y+1}`,k=g=>g.createdAt?new Date(g.createdAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}):"Recent Upload";return e.jsxs("div",{className:"home-manager-shell",children:[e.jsx("style",{children:`
        .home-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .home-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .home-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .home-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .home-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .home-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .home-manager-subtitle {
          margin: 8px 0 0;
          max-width: 620px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .home-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .home-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .home-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .home-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .home-manager-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 16px;
          align-items: end;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .home-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .home-manager-select-wrap {
          position: relative;
        }
        .home-manager-select-wrap select {
          width: 100%;
          height: 46px;
          appearance: none;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 750;
          outline: none;
          padding: 0 42px 0 14px;
          cursor: pointer;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .home-manager-select-wrap select:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .home-manager-select-wrap svg {
          position: absolute;
          right: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #7A6A5B;
          pointer-events: none;
        }
        .home-manager-upload {
          height: 46px;
          min-width: 168px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .home-manager-upload:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .home-manager-upload input,
        .home-manager-action input {
          display: none;
        }
        .home-manager-content {
          padding: 18px;
        }
        .home-manager-section-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .home-manager-section-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .home-manager-section-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .home-manager-target-badge {
          max-width: 260px;
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 7px 11px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          flex: 0 0 auto;
        }
        .home-manager-empty {
          min-height: 320px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 36px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .home-manager-empty-icon {
          width: 64px;
          height: 64px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(107, 63, 29, 0.08);
          margin-bottom: 16px;
        }
        .home-manager-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .home-manager-empty p {
          margin: 8px 0 18px;
          max-width: 380px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: 16px;
        }
        .home-slider-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          overflow: hidden;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          display: flex;
          flex-direction: column;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .home-slider-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .home-slider-media {
          position: relative;
          aspect-ratio: 16 / 10;
          background: #F3EFEA;
          overflow: hidden;
        }
        .home-slider-media img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 260ms ease;
        }
        .home-slider-card:hover .home-slider-media img {
          transform: scale(1.035);
        }
        .home-slider-overlay {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: rgba(26, 18, 8, 0.18);
          opacity: 0;
          transition: opacity 180ms ease;
          pointer-events: none;
        }
        .home-slider-card:hover .home-slider-overlay {
          opacity: 1;
        }
        .home-slider-overlay span {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: rgba(255,255,255,0.18);
          backdrop-filter: blur(8px);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.18);
        }
        .home-slider-body {
          padding: 14px;
          display: flex;
          flex: 1 1 auto;
          flex-direction: column;
          justify-content: space-between;
          gap: 14px;
        }
        .home-slider-body h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .home-slider-body p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .home-manager-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 9px;
          padding-top: 12px;
          border-top: 1px solid #EFE7DF;
        }
        .home-manager-action {
          height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          font-size: 12px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .home-manager-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .home-manager-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        @media (max-width: 920px) {
          .home-manager-hero,
          .home-manager-toolbar {
            grid-template-columns: 1fr;
          }
          .home-manager-stats {
            min-width: 0;
          }
          .home-manager-upload {
            width: 100%;
          }
        }
        @media (max-width: 560px) {
          .home-manager-hero,
          .home-manager-toolbar,
          .home-manager-content {
            padding: 14px;
          }
          .home-manager-title {
            font-size: 21px;
          }
          .home-manager-title-row {
            align-items: flex-start;
          }
          .home-manager-stats {
            grid-template-columns: 1fr;
          }
          .home-manager-section-head {
            flex-direction: column;
          }
          .home-manager-target-badge {
            max-width: 100%;
          }
          .home-manager-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),e.jsxs("div",{className:"home-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"home-manager-title-row",children:[e.jsx("div",{className:"home-manager-icon",children:e.jsx(Q,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"home-manager-kicker",children:"Homepage Media"}),e.jsx("h1",{className:"home-manager-title",children:"Home Page Management"})]})]}),e.jsx("p",{className:"home-manager-subtitle",children:"Manage homepage banner and department slider images with a cleaner preview-first workflow."})]}),e.jsxs("div",{className:"home-manager-stats",children:[e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:r.length}),e.jsx("span",{children:"Shown Here"})]}),e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:n.length}),e.jsx("span",{children:"Total Images"})]})]})]}),e.jsxs("div",{className:"home-manager-panel",children:[e.jsxs("div",{className:"home-manager-toolbar",children:[e.jsxs("div",{className:"home-manager-field",children:[e.jsx("label",{children:"Target Section"}),e.jsxs("div",{className:"home-manager-select-wrap",children:[e.jsxs("select",{value:t,onChange:g=>a(g.target.value),children:[e.jsx("option",{value:"null",children:"Homepage Sliders"}),s.map(g=>e.jsx("option",{value:g._id,children:g.name},g._id))]}),e.jsx(kt,{size:17})]})]}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(re,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:d})]})]}),e.jsxs("div",{className:"home-manager-content",children:[e.jsxs("div",{className:"home-manager-section-head",children:[e.jsxs("div",{children:[e.jsx("h3",{children:"Gallery Images"}),e.jsx("p",{children:"Replace or remove images currently attached to this slider group."})]}),e.jsx("span",{className:"home-manager-target-badge",children:u})]}),r.length===0?e.jsxs("div",{className:"home-manager-empty",children:[e.jsx("div",{className:"home-manager-empty-icon",children:e.jsx(re,{size:30})}),e.jsx("h4",{children:"No Images Uploaded"}),e.jsx("p",{children:"Upload images for this section. A 16:9 image works best for public slider banners."}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(re,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:d})]})]}):e.jsx("div",{className:"home-manager-grid",children:e.jsx(pe,{children:r.map((g,y)=>e.jsxs(ee.div,{layout:!0,initial:{opacity:0,y:10},animate:{opacity:1,y:0},exit:{opacity:0,scale:.96},className:"home-slider-card",children:[e.jsxs("div",{className:"home-slider-media",children:[e.jsx("img",{src:V(g.imageUrl),alt:x(g,y)}),e.jsx("div",{className:"home-slider-overlay",children:e.jsx("span",{children:e.jsx(Q,{size:18})})})]}),e.jsxs("div",{className:"home-slider-body",children:[e.jsxs("div",{children:[e.jsx("h4",{title:x(g,y),children:x(g,y)}),e.jsxs("p",{children:["Uploaded: ",k(g)]})]}),e.jsxs("div",{className:"home-manager-actions",children:[e.jsxs("label",{className:"home-manager-action",children:[e.jsx(J,{size:13}),"Replace",e.jsx("input",{type:"file",onChange:P=>{const D=P.target.files?.[0];D&&o(g._id,D)}})]}),e.jsxs("button",{type:"button",className:"home-manager-action danger",onClick:()=>i(`/sliders/${g._id}`),children:[e.jsx(M,{size:13}),"Delete"]})]})]})]},g._id))})})]})]})]})},bi=({programs:t,academicContent:a,setAcademicContent:s,axiosInstance:n,notify:d,openModal:o,setProgramForm:i,del:r})=>{const u=new Set(t.map(g=>g.category).filter(Boolean)).size,x=()=>{i({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),o("program")},k=g=>{i({title:g.title,description:g.description,duration:g.duration,category:g.category,courses:g.courses?.join(", ")||"",image:null}),o("program",g)};return e.jsxs("div",{className:"academic-manager-shell",children:[e.jsx("style",{children:`
        .academic-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .academic-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .academic-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .academic-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .academic-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .academic-manager-subtitle {
          margin: 8px 0 0;
          max-width: 650px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .academic-manager-top-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .academic-manager-add {
          height: 44px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-add:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .academic-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .academic-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .academic-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .academic-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .academic-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .academic-manager-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .academic-manager-panel-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-panel-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .academic-manager-panel-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 17px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-manager-panel-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .academic-manager-form {
          padding: 18px;
          display: grid;
          gap: 14px;
        }
        .academic-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .academic-manager-field input,
        .academic-manager-field textarea {
          width: 100%;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 12px 14px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .academic-manager-field input {
          height: 46px;
        }
        .academic-manager-field textarea {
          min-height: 94px;
          resize: vertical;
          line-height: 1.55;
        }
        .academic-manager-field input:focus,
        .academic-manager-field textarea:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .academic-manager-save {
          justify-self: start;
          height: 42px;
          border: 0;
          border-radius: 11px;
          padding: 0 16px;
          color: #FFFFFF;
          background: #6B3F1D;
          box-shadow: 0 10px 20px rgba(107, 63, 29, 0.18);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-save:hover {
          transform: translateY(-1px);
          box-shadow: 0 14px 26px rgba(107, 63, 29, 0.24);
        }
        .academic-programs-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .academic-programs-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-programs-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .academic-programs-wrap {
          padding: 18px;
        }
        .academic-programs-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(310px, 1fr));
          gap: 16px;
        }
        .academic-program-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .academic-program-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .academic-program-top {
          display: grid;
          grid-template-columns: 82px minmax(0, 1fr) auto;
          gap: 13px;
          align-items: start;
        }
        .academic-program-image {
          width: 82px;
          aspect-ratio: 1;
          border-radius: 14px;
          overflow: hidden;
          background: #F3EFEA;
          border: 1px solid #EFE7DF;
          flex: 0 0 auto;
        }
        .academic-program-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }
        .academic-program-main {
          min-width: 0;
        }
        .academic-program-main h4 {
          margin: 0;
          color: #1A1208;
          font-size: 15px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .academic-program-meta {
          display: flex;
          flex-wrap: wrap;
          gap: 7px;
          margin-top: 9px;
        }
        .academic-program-pill {
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-duration {
          border: 1px solid #DDE7F2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #536C8D;
          background: #F6FAFE;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-actions {
          display: flex;
          align-items: center;
          gap: 7px;
        }
        .academic-program-action {
          width: 34px;
          height: 34px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .academic-program-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .academic-program-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        .academic-program-desc {
          margin: 0;
          min-height: 42px;
          color: #786859;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.55;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .academic-program-empty {
          min-height: 260px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 34px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .academic-program-empty-icon {
          width: 60px;
          height: 60px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 15px;
        }
        .academic-program-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .academic-program-empty p {
          margin: 8px 0 18px;
          max-width: 360px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        @media (max-width: 980px) {
          .academic-manager-hero {
            grid-template-columns: 1fr;
          }
          .academic-manager-stats {
            min-width: 0;
          }
          .academic-manager-top-actions {
            align-items: stretch;
            flex-direction: column;
          }
          .academic-manager-add {
            width: 100%;
          }
        }
        @media (max-width: 640px) {
          .academic-manager-hero,
          .academic-manager-panel-head,
          .academic-manager-form,
          .academic-programs-wrap {
            padding: 14px;
          }
          .academic-manager-title {
            font-size: 21px;
          }
          .academic-manager-title-row {
            align-items: flex-start;
          }
          .academic-manager-stats {
            grid-template-columns: 1fr;
          }
          .academic-manager-panel-head,
          .academic-programs-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .academic-programs-grid {
            grid-template-columns: 1fr;
          }
          .academic-program-top {
            grid-template-columns: 68px minmax(0, 1fr);
          }
          .academic-program-image {
            width: 68px;
          }
          .academic-program-actions {
            grid-column: 1 / -1;
            width: 100%;
            justify-content: flex-end;
          }
        }
      `}),e.jsxs("div",{className:"academic-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"academic-manager-title-row",children:[e.jsx("div",{className:"academic-manager-icon",children:e.jsx(Ce,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"academic-manager-kicker",children:"Academic Content"}),e.jsx("h1",{className:"academic-manager-title",children:"Academic Programs"})]})]}),e.jsx("p",{className:"academic-manager-subtitle",children:"Manage the public academic section copy and program cards from one focused workspace."})]}),e.jsxs("div",{className:"academic-manager-top-actions",children:[e.jsxs("div",{className:"academic-manager-stats",children:[e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:t.length}),e.jsx("span",{children:"Programs"})]}),e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:u}),e.jsx("span",{children:"Categories"})]})]}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:x,children:[e.jsx(be,{size:16}),"Add New Program"]})]})]}),e.jsxs("div",{className:"academic-manager-panel",children:[e.jsx("div",{className:"academic-manager-panel-head",children:e.jsxs("div",{className:"academic-manager-panel-title",children:[e.jsx("div",{className:"academic-manager-panel-icon",children:e.jsx(At,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Section Banner Content"}),e.jsx("p",{children:"Copy shown above academic programs on the public website"})]})]})}),e.jsxs("div",{className:"academic-manager-form",children:[e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Section Display Title"}),e.jsx("input",{value:a.title,onChange:g=>s({...a,title:g.target.value}),placeholder:"Academic Programs"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Primary Description"}),e.jsx("textarea",{rows:3,value:a.description1,onChange:g=>s({...a,description1:g.target.value}),placeholder:"Primary description paragraph"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Secondary Description"}),e.jsx("textarea",{rows:2,value:a.description2,onChange:g=>s({...a,description2:g.target.value}),placeholder:"Secondary description paragraph"})]}),e.jsxs("button",{type:"button",className:"academic-manager-save",onClick:async()=>{try{await n.put("/content/academic",a),d("Content Saved Successfully")}catch{d("Failed to save content","error")}},children:[e.jsx(fe,{size:15}),"Update Content"]})]})]}),e.jsx("div",{className:"academic-manager-panel",children:e.jsxs("div",{className:"academic-programs-wrap",children:[e.jsx("div",{className:"academic-programs-head",children:e.jsxs("div",{children:[e.jsx("h3",{children:"Program Cards"}),e.jsx("p",{children:"These programs appear in the academic programs section."})]})}),t.length===0?e.jsxs("div",{className:"academic-program-empty",children:[e.jsx("div",{className:"academic-program-empty-icon",children:e.jsx(Ce,{size:28})}),e.jsx("h4",{children:"No programs registered yet"}),e.jsx("p",{children:"Add the first program to start building the academic page."}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:x,children:[e.jsx(be,{size:16}),"Add New Program"]})]}):e.jsx("div",{className:"academic-programs-grid",children:t.map(g=>e.jsxs(ee.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},className:"academic-program-card",children:[e.jsxs("div",{className:"academic-program-top",children:[e.jsx("div",{className:"academic-program-image",children:e.jsx("img",{src:V(g.imageUrl),alt:g.title})}),e.jsxs("div",{className:"academic-program-main",children:[e.jsx("h4",{title:g.title,children:g.title}),e.jsxs("div",{className:"academic-program-meta",children:[g.category&&e.jsx("span",{className:"academic-program-pill",children:g.category}),g.duration&&e.jsx("span",{className:"academic-program-duration",children:g.duration})]})]}),e.jsxs("div",{className:"academic-program-actions",children:[e.jsx("button",{type:"button",className:"academic-program-action",onClick:()=>k(g),"aria-label":`Edit ${g.title}`,children:e.jsx(J,{size:14})}),e.jsx("button",{type:"button",className:"academic-program-action danger",onClick:()=>r(`/programs/${g._id}`),"aria-label":`Delete ${g.title}`,children:e.jsx(M,{size:14})})]})]}),g.description&&e.jsx("p",{className:"academic-program-desc",children:g.description})]},g._id))})]})})]})},fi=({testimonials:t,testimonialForm:a,setTestimonialForm:s,openModal:n,del:d})=>e.jsxs("div",{className:"testimonial-manager-shell",children:[e.jsx("style",{children:`
      .testimonial-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
      .testimonial-manager-shell > div:first-of-type {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 18px !important;
        padding: 22px !important;
        border: 1px solid #E7DDD2 !important;
        border-radius: 18px !important;
        background:
          linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
          linear-gradient(135deg, #6B3F1D, #E07B39) !important;
        box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08) !important;
      }
      .testimonial-manager-shell > div:first-of-type h3 {
        margin: 0 !important;
        color: #1A1208 !important;
        font-size: 24px !important;
        line-height: 1.15 !important;
        font-weight: 900 !important;
        letter-spacing: 0 !important;
      }
      .testimonial-manager-shell > div:first-of-type p {
        margin: 6px 0 0 !important;
        color: #786859 !important;
        font-size: 13px !important;
        font-weight: 650 !important;
      }
      .testimonial-manager-shell > div:first-of-type button {
        height: 44px !important;
        border: 0 !important;
        border-radius: 12px !important;
        padding: 0 16px !important;
        color: #FFFFFF !important;
        background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%) !important;
        box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2) !important;
        font-size: 13px !important;
        font-weight: 900 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) {
        display: grid !important;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)) !important;
        gap: 16px !important;
        padding: 18px !important;
        border: 1px solid #E8E0D8 !important;
        border-radius: 18px !important;
        background: #FFFFFF !important;
        box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06) !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div {
        min-width: 0 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div:not(.col-span-full) {
        border: 1px solid #E8E0D8 !important;
        border-radius: 16px !important;
        background: #FFFFFF !important;
        box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06) !important;
        padding: 16px !important;
      }
      .testimonial-manager-shell img {
        width: 56px !important;
        height: 56px !important;
        border-radius: 16px !important;
        object-fit: cover !important;
      }
      .testimonial-manager-shell .col-span-full {
        grid-column: 1 / -1 !important;
      }
      .testimonial-manager-shell .col-span-full > div {
        min-height: 340px !important;
        border: 2px dashed #E6DCD1 !important;
        border-radius: 16px !important;
        background: #FBFAF8 !important;
        box-shadow: none !important;
      }
      @media (max-width: 640px) {
        .testimonial-manager-shell > div:first-of-type {
          align-items: stretch !important;
          flex-direction: column !important;
          padding: 14px !important;
        }
        .testimonial-manager-shell > div:nth-of-type(2) {
          grid-template-columns: 1fr !important;
          padding: 14px !important;
        }
      }
    `}),e.jsx(Y,{icon:ue,title:"Student Testimonials",subtitle:`${t.length} reviews published`,action:e.jsx(W,{onClick:()=>{s({name:"",role:"",content:"",rating:5,image:null}),n("testimonial")}})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[t.map(o=>e.jsxs(ee.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},className:"p-6 rounded-3xl group relative shadow-md transition-all hover:shadow-lg flex flex-col h-full",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsxs("div",{className:"flex items-start justify-between gap-4 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("img",{src:V(o.imageUrl),alt:o.name,className:"w-14 h-14 rounded-full object-cover border-2 shadow-inner",style:{borderColor:l.accentSoft}}),e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm leading-tight mb-1",style:{color:l.text},children:o.name}),e.jsx("p",{className:"text-xs font-medium",style:{color:l.muted},children:o.role}),e.jsx("div",{className:"flex gap-0.5 mt-1",children:[...Array(5)].map((i,r)=>e.jsx("span",{className:"text-sm",style:{color:r<o.rating?"#F59E0B":l.border},children:"★"},r))})]})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0",children:[e.jsx(L,{onClick:()=>{s({name:o.name,role:o.role,content:o.content,rating:o.rating,image:null}),n("testimonial",o)},children:e.jsx(J,{size:14})}),e.jsx(L,{danger:!0,onClick:()=>d(`/testimonials/${o._id}`),children:e.jsx(M,{size:14})})]})]}),e.jsxs("p",{className:"text-sm leading-relaxed italic text-gray-600 line-clamp-4 mt-1 flex-1",children:['"',o.content,'"']})]},o._id)),t.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(xe,{icon:ue,text:"No testimonials available"})})]})]}),he=({slot:t,linkedKey:a,label:s,aboutImages:n,setAboutImages:d,aboutImageFiles:o,setAboutImageFiles:i,axiosInstance:r,notify:u})=>{if(!t)return null;const x=o[t.key],k=x?URL.createObjectURL(x):t.imageUrl?V(t.imageUrl):null,g=D=>{d(n.map(S=>S.key===t.key||S.key===a?{...S,...D}:S))},y=async()=>{const D=new FormData;D.append("title",t.title||s),D.append("alt",t.alt||s),x&&D.append("image",x);try{const S=await r.put(`/about/images/${t.key}`,D);let F=n.some(v=>v.key===t.key)?n.map(v=>v.key===t.key?S.data:v):[...n,S.data];if(a){const v=new FormData;v.append("title",t.title||s),v.append("alt",t.alt||s),x&&v.append("image",x);try{const b=await r.put(`/about/images/${a}`,v);F=F.some(w=>w.key===a)?F.map(w=>w.key===a?b.data:w):[...F,b.data]}catch{}}d(F),i({...o,[t.key]:null,...a?{[a]:null}:{}}),u(`${s} image saved`)}catch{u("Image update failed","error")}},P=async()=>{if(window.confirm(`Delete ${s} image? The website will use the default image.`))try{const D=await r.delete(`/about/images/${t.key}`);let S=n.some(F=>F.key===t.key)?n.map(F=>F.key===t.key?D.data:F):[...n,D.data];if(a)try{const F=await r.delete(`/about/images/${a}`);S=S.some(v=>v.key===a)?S.map(v=>v.key===a?F.data:v):[...S,F.data]}catch{}d(S),i({...o,[t.key]:null,...a?{[a]:null}:{}}),u(`${s} image deleted`)}catch{u("Delete failed","error")}};return e.jsxs("div",{className:"p-4 rounded-2xl shadow-sm space-y-3",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest",style:{color:l.muted},children:[s," Image"]}),e.jsx("div",{className:"rounded-xl overflow-hidden bg-gray-50 border border-dashed flex items-center justify-center",style:{borderColor:l.border,maxHeight:"200px",minHeight:"120px"},children:k?e.jsx("img",{src:k,alt:t.alt||s,className:"w-full object-cover",style:{maxHeight:"200px",width:"100%",display:"block"}}):e.jsxs("div",{className:"text-center py-8",style:{color:l.muted},children:[e.jsx(Q,{size:28,className:"mx-auto mb-2 opacity-60"}),e.jsx("p",{className:"text-[11px] font-bold uppercase tracking-wider",children:"Default image active"})]})}),e.jsx(c,{label:"Alt Text",children:e.jsx("input",{value:t.alt||"",onChange:D=>g({alt:D.target.value}),className:_,style:U})}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border-2 border-dashed text-xs font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:l.border,color:l.muted},children:[e.jsx(re,{size:14})," ",x?x.name:"Choose Image",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:D=>i({...o,[t.key]:D.target.files[0]})})]}),e.jsxs("button",{onClick:y,className:"px-4 py-2.5 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition-all flex items-center justify-center gap-2",style:{background:l.brand},children:[e.jsx(fe,{size:14})," Save"]}),e.jsxs("button",{onClick:P,className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 active:scale-95 transition-all flex items-center justify-center gap-2",children:[e.jsx(M,{size:14})," Delete"]})]})]})},ji=({aboutSub:t,setAboutSub:a,collegeLogo:s,setCollegeLogo:n,logoFile:d,setLogoFile:o,deanMessage:i,setDeanMessage:r,deanPhotoFile:u,setDeanPhotoFile:x,milestones:k,milestoneForm:g,setMilestoneForm:y,openModal:P,setMilestones:D,visionMission:S,setVmForm:F,coreValues:v,setCvForm:b,aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,historyContent:$,setHistoryContent:K,axiosInstance:z,notify:m,del:N})=>e.jsxs("div",{className:"about-manager-shell admin-clean-page",children:[e.jsx("style",{children:`
      .about-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
    `}),e.jsx(ve,{tabs:["Branding","Principal","Timeline","Vision & Mission","Core Values"],active:t,onChange:a}),e.jsx(pe,{mode:"wait",children:e.jsxs(ee.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:-8},children:[t==="Branding"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:l.text},children:"Institution Branding"}),e.jsxs("div",{className:"flex flex-col sm:flex-row items-start gap-6",children:[e.jsx("div",{className:"rounded-2xl border-2 border-dashed overflow-hidden bg-gray-50 flex items-center justify-center shrink-0 shadow-inner",style:{width:"100px",height:"100px",minWidth:"100px",minHeight:"100px",maxWidth:"100px",maxHeight:"100px",borderColor:l.border,padding:"6px",background:"#f8fafc",boxSizing:"border-box"},children:s.logoUrl?e.jsx("img",{src:V(s.logoUrl),style:{width:"100%",height:"100%",maxWidth:"86px",maxHeight:"86px",objectFit:"contain",display:"block"},alt:"College Logo"}):e.jsx(Q,{size:32,style:{color:l.muted}})}),e.jsxs("div",{className:"flex-1 w-full space-y-4",children:[e.jsx(c,{label:"College Full Name",children:e.jsx("input",{value:s.collegeName||"",onChange:p=>n({...s,collegeName:p.target.value}),placeholder:"e.g. Ginera Nursing College",className:_,style:U})}),e.jsx(c,{label:"Tagline / Motto",children:e.jsx("input",{value:s.tagline||"",onChange:p=>n({...s,tagline:p.target.value}),placeholder:"e.g. Excellence in Healthcare",className:_,style:U})})]})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-3 pt-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed text-sm font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:l.border,color:l.muted},children:[e.jsx(re,{size:16})," ",d?d.name:"Choose New Logo File",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:p=>o(p.target.files[0])})]}),e.jsx("button",{onClick:async()=>{const p=new FormData;p.append("collegeName",s.collegeName||""),p.append("tagline",s.tagline||""),d&&p.append("logo",d);try{const E=await z.put("/about/college-logo",p);n(E.data),o(null),m("Branding Updated Successfully")}catch{m("Update failed","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all",style:{background:l.brand},children:"Save Branding"})]})]}),t==="Principal"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-5 shadow-sm",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:l.text},children:"Dean / Principal's Message"}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[e.jsx(c,{label:"Full Name",children:e.jsx("input",{value:i.name||"",onChange:p=>r({...i,name:p.target.value}),placeholder:"e.g. Dr. Jane Doe",className:_,style:U})}),e.jsx(c,{label:"Official Title",children:e.jsx("input",{value:i.title||"",onChange:p=>r({...i,title:p.target.value}),placeholder:"e.g. Dean of Nursing",className:_,style:U})})]}),e.jsx(c,{label:"Opening Greeting",children:e.jsx("input",{value:i.greeting||"",onChange:p=>r({...i,greeting:p.target.value}),placeholder:"e.g. Welcome to Ginera...",className:_,style:U})}),e.jsx(c,{label:"Message Content (New line for each paragraph)",children:e.jsx("textarea",{rows:6,className:`${_} resize-none`,style:U,value:(i.paragraphs||[]).join(`
`),onChange:p=>r({...i,paragraphs:p.target.value.split(`
`)})})}),e.jsx(c,{label:"Highlight Quote",children:e.jsx("textarea",{rows:2,className:`${_} resize-none font-medium italic`,style:U,placeholder:"A powerful summary statement...",value:i.highlight||"",onChange:p=>r({...i,highlight:p.target.value})})}),e.jsxs("div",{className:"flex flex-col gap-4 p-4 rounded-2xl bg-gray-50 border border-dashed sm:flex-row sm:items-center",style:{borderColor:l.border},children:[e.jsx("div",{className:"rounded-2xl overflow-hidden border-2 shadow-sm shrink-0",style:{width:"64px",height:"64px",minWidth:"64px",minHeight:"64px",maxWidth:"64px",maxHeight:"64px",borderColor:l.brand+"40"},children:i.photoUrl?e.jsx("img",{src:V(i.photoUrl),className:"w-full h-full object-cover",alt:""}):e.jsx("div",{className:"w-full h-full bg-white flex items-center justify-center",children:e.jsx(ue,{size:24,style:{color:l.muted}})})}),e.jsxs("label",{className:"flex min-w-0 flex-1 items-center gap-3 rounded-xl border-2 border-dashed px-4 py-3 text-sm font-bold cursor-pointer transition-all hover:border-amber-400 hover:bg-amber-50",style:{borderColor:u?l.accent:l.border,color:l.text,background:u?l.accentSoft:"#FFFFFF"},children:[e.jsx("span",{className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",style:{background:l.accentSoft,color:l.accent},children:e.jsx(re,{size:17})}),e.jsxs("span",{className:"min-w-0 flex-1",children:[e.jsx("span",{className:"block text-[11px] uppercase tracking-wider",style:{color:l.muted},children:"Principal photo"}),e.jsx("span",{className:"block truncate mt-0.5",children:u?u.name:"Choose or replace photo"})]}),e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:p=>x(p.target.files[0])})]})]}),e.jsx("button",{onClick:async()=>{const p=new FormData;["name","title","greeting","highlight"].forEach(E=>p.append(E,i[E]||"")),p.append("paragraphs",JSON.stringify((i.paragraphs||[]).filter(E=>E&&E.trim()!==""))),p.append("stats",JSON.stringify(i.stats||[])),u&&p.append("photo",u);try{const E=await z.put("/about/dean",p);r(E.data),x(null),m("Message Updated Successfully")}catch{m("Update failed","error")}},className:"w-full sm:w-auto px-10 py-3.5 rounded-xl text-sm font-bold text-white shadow-xl active:scale-95 transition-all",style:{background:l.brand},children:"Publish Message"})]}),t==="Timeline"&&e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:l.surface,borderColor:l.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:l.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:l.text},children:"History Page Images Management"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:l.muted},children:"Upload, update, or delete images for Hero Banner, Institutional Timeline, and Legacy of Excellence sections"})]})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsx(he,{slot:w.find(p=>p.key==="historyHero")||{key:"historyHero",title:"History Hero Banner Image",alt:"Our History Banner"},label:"History Hero Banner",aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,axiosInstance:z,notify:m}),e.jsx(he,{slot:w.find(p=>p.key==="historyTimeline")||{key:"historyTimeline",title:"Institutional Timeline Image",alt:"Institutional Timeline"},label:"Institutional Timeline Section",aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,axiosInstance:z,notify:m}),e.jsx(he,{slot:w.find(p=>p.key==="historyLegacy")||{key:"historyLegacy",title:"Legacy of Excellence Image",alt:"Legacy of Excellence"},label:"Legacy of Excellence Section",aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,axiosInstance:z,notify:m})]})]}),e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:l.surface,borderColor:l.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:l.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:l.text},children:"History Page Content & Section Titles"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:l.muted},children:"Edit main hero title, section headings, and history paragraphs"})]})}),e.jsx(c,{label:"Hero Banner Title",children:e.jsx(f,{value:$.heroTitle||"",onChange:p=>K({...$,heroTitle:p.target.value}),placeholder:"e.g. Our History"})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6 pt-2",children:[e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:l.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Institutional Timeline Section"}),e.jsx(c,{label:"Section Title",children:e.jsx(f,{value:$.timelineTitle||"",onChange:p=>K({...$,timelineTitle:p.target.value}),placeholder:"e.g. Institutional Timeline"})}),e.jsx(c,{label:"Paragraphs (One paragraph per line)",children:e.jsx(q,{rows:6,value:Array.isArray($.timelineParagraphs)?$.timelineParagraphs.join(`
`):$.timelineParagraphs||"",onChange:p=>K({...$,timelineParagraphs:p.target.value.split(`
`)}),placeholder:"Enter timeline history paragraphs..."})})]}),e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:l.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Legacy of Excellence Section"}),e.jsx(c,{label:"Section Title",children:e.jsx(f,{value:$.legacyTitle||"",onChange:p=>K({...$,legacyTitle:p.target.value}),placeholder:"e.g. Legacy of Excellence"})}),e.jsx(c,{label:"Paragraphs (One paragraph per line)",children:e.jsx(q,{rows:6,value:Array.isArray($.legacyParagraphs)?$.legacyParagraphs.join(`
`):$.legacyParagraphs||"",onChange:p=>K({...$,legacyParagraphs:p.target.value.split(`
`)}),placeholder:"Enter legacy paragraphs..."})})]})]}),e.jsx("div",{className:"flex justify-end pt-2",children:e.jsxs("button",{onClick:async()=>{try{const p={...$,timelineParagraphs:(Array.isArray($.timelineParagraphs)?$.timelineParagraphs:($.timelineParagraphs||"").split(`
`)).filter(Z=>Z&&Z.trim()!==""),legacyParagraphs:(Array.isArray($.legacyParagraphs)?$.legacyParagraphs:($.legacyParagraphs||"").split(`
`)).filter(Z=>Z&&Z.trim()!=="")},E=await z.put("/about/history-content",p);K(E.data),m("History Page Content Updated Successfully!")}catch{m("Failed to update history content","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all flex items-center gap-2",style:{background:l.brand},children:[e.jsx(fe,{size:16})," Save History Page Content"]})})]}),e.jsxs("div",{className:"space-y-4 pt-4 border-t border-gray-200",children:[e.jsx(Y,{icon:Dt,title:"Institutional Milestones",subtitle:"Timeline entries & historical achievements",action:e.jsx(W,{onClick:()=>{y({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),P("milestone")},label:"Add Milestone"})}),e.jsx("div",{className:"grid grid-cols-1 gap-4",children:k.map(p=>e.jsxs("div",{className:"p-5 rounded-2xl transition-all hover:shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",style:{background:l.surface,border:`1px solid ${l.border}`,borderLeft:`5px solid ${p.color||"#f59e0b"}`},children:[e.jsxs("div",{className:"flex items-start gap-4 min-w-0 flex-1",children:[e.jsx("span",{className:"text-3xl shrink-0 p-2 rounded-xl bg-amber-50 border border-amber-100",children:p.icon||"🎯"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("div",{className:"flex items-center gap-2 mb-1",children:e.jsx("span",{className:"px-2.5 py-0.5 rounded-md text-xs font-bold text-gray-800 bg-gray-100 border border-gray-200",children:p.year})}),e.jsx("p",{className:"font-bold text-sm text-gray-900 truncate",children:p.event}),e.jsx("p",{className:"text-xs text-gray-500 line-clamp-2 mt-1 leading-relaxed",children:p.description})]})]}),e.jsxs("div",{className:"flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-100",children:[e.jsxs("button",{onClick:()=>{y({year:p.year,event:p.event,icon:p.icon,color:p.color,description:p.description,order:p.order||0}),P("milestone",p)},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition-all shadow-sm",children:[e.jsx(J,{size:14})," Edit"]}),e.jsxs("button",{onClick:async()=>{if(window.confirm("Delete this milestone?"))try{await z.delete(`/about/milestones/${p._id}`),D(k.filter(E=>E._id!==p._id)),m("Milestone Removed")}catch{m("Delete failed","error")}},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-all shadow-sm",children:[e.jsx(M,{size:14})," Delete"]})]})]},p._id))})]})]}),t==="Vision & Mission"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:Ae,title:"Vision & Mission",subtitle:"Strategic direction statements",action:e.jsx(W,{onClick:()=>{F({type:"vision",content:"",order:0}),P("visionMission")},label:"Add Statement"})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-4",children:[e.jsx(he,{slot:w.find(p=>p.key==="visionMain")||w.find(p=>p.key==="visionGoals"),linkedKey:"visionGoals",label:"Vision",aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,axiosInstance:z,notify:m}),e.jsx(he,{slot:w.find(p=>p.key==="missionMain")||w.find(p=>p.key==="missionValues"),linkedKey:"missionValues",label:"Mission",aboutImages:w,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:X,axiosInstance:z,notify:m})]}),e.jsx("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",style:{gap:"1.5rem"},children:["vision","mission"].map(p=>e.jsxs("div",{className:"flex flex-col gap-3 min-w-0",style:{gap:"0.75rem"},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest pl-2",style:{color:l.muted},children:[p," Statement"]}),S.filter(E=>E.type===p).map(E=>e.jsxs("div",{className:"p-5 rounded-2xl relative group shadow-sm",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx("p",{className:"text-sm leading-relaxed",style:{color:l.text},children:E.content}),e.jsxs("div",{className:"absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(L,{onClick:()=>{F({type:E.type,content:E.content,order:E.order}),P("visionMission",E)},children:e.jsx(J,{size:13})}),e.jsx(L,{danger:!0,onClick:()=>N(`/about/vision-mission/${E._id}`),children:e.jsx(M,{size:13})})]})]},E._id))]},p))})]}),t==="Core Values"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:le,title:"Institutional Values",subtitle:"The pillars of our culture",action:e.jsx(W,{onClick:()=>{b({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),P("coreValue")},label:"Add Core Value"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",style:{gap:"1.25rem"},children:v.map(p=>e.jsxs("div",{className:"p-6 rounded-3xl group relative transition-all hover:shadow-lg overflow-hidden",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx("div",{className:`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${p.color} opacity-[0.03] rounded-bl-[100px] transition-all group-hover:opacity-[0.08]`}),e.jsx("span",{className:"text-4xl block mb-4 filter drop-shadow-sm",children:p.icon}),e.jsx("p",{className:"font-bold text-base mb-2",style:{color:l.text},children:p.title}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:l.muted},children:p.description}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(L,{onClick:()=>{b({icon:p.icon,title:p.title,description:p.description,color:p.color,order:p.order}),P("coreValue",p)},children:e.jsx(J,{size:13})}),e.jsx(L,{danger:!0,onClick:()=>N(`/about/core-values/${p._id}`),children:e.jsx(M,{size:13})})]})]},p._id))})]})]},t)})]}),yi=({admSub:t,setAdmSub:a,courses:s,openModal:n,setCourseForm:d,del:o,admissionSteps:i,setStepForm:r,admissionRules:u,setRuleForm:x,bonds:k,setBondForm:g,guidelines:y,setGuidelineForm:P})=>{const[D,S]=h.useState("All"),F=["All",...Array.from(new Set(s.map(b=>b.category).filter(Boolean)))],v=D==="All"?s:s.filter(b=>b.category===D);return e.jsxs("div",{className:"admission-manager-shell admin-clean-page",children:[e.jsx(ve,{tabs:["Courses","Procedure","Eligibility","Guidelines"],active:t,onChange:a}),t==="Courses"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:ye,title:"Program Offerings",subtitle:`${s.length} courses listed`,action:e.jsx(W,{onClick:()=>{d({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),n("course")},label:"Add Course"})}),e.jsx("div",{className:"flex flex-wrap gap-2",children:F.map(b=>e.jsx("button",{type:"button",onClick:()=>S(b),className:"px-3 py-2 rounded-xl text-xs font-bold border transition-all",style:{background:D===b?l.brand:l.surface,color:D===b?"#fff":l.muted,borderColor:l.border},children:b},b))}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:v.map(b=>e.jsx(ce,{icon:b.icon,badge:b.category,title:b.name,sub:`${b.duration} | ${b.seats} Seats`,onEdit:()=>{d({...b,highlights:b.highlights?.join(", ")||""}),n("course",b)},onDelete:()=>o(`/courses/${b._id}`)},b._id))})]}),t==="Procedure"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:Ee,title:"Admission Steps",subtitle:"Step-by-step guidance for applicants",action:e.jsx(W,{onClick:()=>{r({step:1,title:"",description:"",details:"",icon:"Calendar"}),n("step")},label:"Add Step"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:i.sort((b,w)=>b.step-w.step).map(b=>e.jsxs("div",{className:"p-5 rounded-3xl group relative shadow-sm hover:shadow-md transition-all",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold text-white shadow-md",style:{background:l.brand},children:b.step}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:l.text},children:b.title}),e.jsx("p",{className:"text-xs line-clamp-1",style:{color:l.muted},children:b.description})]})]}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(L,{onClick:()=>{r({...b}),n("step",b)},children:e.jsx(J,{size:13})}),e.jsx(L,{danger:!0,onClick:()=>o(`/admission-steps/${b._id}`),children:e.jsx(M,{size:13})})]})]},b._id))})]}),t==="Eligibility"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:De,title:"Admission Rules",subtitle:"Criteria for selection",action:e.jsx(W,{onClick:()=>{x({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),n("rule")},label:"Add Rule"})}),["UnderGraduated Programs","PostGraduated Programs","General Rules"].map(b=>{const w=u.filter(C=>C.category===b);return w.length?e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em] px-2",style:{color:l.muted},children:b}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:w.map(C=>e.jsx(ce,{icon:C.icon==="CheckCircle"?"✅":"📋",title:C.title,sub:C.description?.slice(0,60)+"...",onEdit:()=>{x({...C}),n("rule",C)},onDelete:()=>o(`/admission-rules/${C._id}`)},C._id))})]},b):null})]}),t==="Guidelines"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:Ae,title:"Guidelines & Conduct",subtitle:"Rules for students and guardians",action:e.jsx(W,{onClick:()=>{P({category:"General Guidelines",subCategory:"",points:"",order:0}),n("guideline")},label:"Add Section"})}),["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(b=>{const w=y.filter(C=>C.category===b);return w.length?e.jsxs("div",{className:"rounded-3xl overflow-hidden shadow-sm border",style:{borderColor:l.border},children:[e.jsx("div",{className:"px-6 py-3.5 border-b",style:{background:l.bg,borderColor:l.border},children:e.jsx("p",{className:"font-bold text-xs uppercase tracking-widest",style:{color:l.text},children:b})}),e.jsx("div",{className:"divide-y divide-gray-100",style:{background:l.surface},children:w.map(C=>e.jsxs("div",{className:"flex items-start gap-5 p-5 group transition-all hover:bg-gray-50/50",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"font-bold text-sm mb-2",style:{color:l.text},children:C.subCategory}),e.jsx("ul",{className:"space-y-1.5",children:C.points.map((O,X)=>e.jsxs("li",{className:"flex items-start gap-2 text-xs leading-relaxed",style:{color:l.muted},children:[e.jsx("span",{className:"mt-1.5 w-1 h-1 rounded-full bg-amber-500 shrink-0"}),O]},X))})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(L,{onClick:()=>{P({...C,points:C.points.join(`
`)}),n("guideline",C)},children:e.jsx(J,{size:14})}),e.jsx(L,{danger:!0,onClick:()=>o(`/guidelines/${C._id}`),children:e.jsx(M,{size:14})})]})]},C._id))})]},b):null})]})]})},vi=({selectedDept:t,setSelectedDept:a,departments:s,deptForm:n,setDeptForm:d,deptSub:o,setDeptSub:i,deptFacultyForm:r,setDeptFacultyForm:u,deptFacilityInput:x,setDeptFacilityInput:k,deptActivityInput:g,setDeptActivityInput:y,sliders:P,axiosInstance:D,fetchData:S,notify:F,openModal:v,del:b,handleSliderUpload:w})=>{const[C,O]=h.useState(null),[X,$]=h.useState(null),[K,z]=h.useState(null);return t?e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-col lg:flex-row items-start lg:items-center gap-6 p-6 rounded-3xl shadow-sm border overflow-hidden",style:{background:l.surface,borderColor:l.border},children:[e.jsxs("div",{className:"flex items-center gap-4 flex-1 min-w-0",children:[e.jsx("button",{onClick:()=>{a(null),O(null),$(null),z(null)},className:"p-3 rounded-2xl hover:bg-gray-50 transition-all shrink-0 border shadow-sm group",style:{borderColor:l.border,color:l.muted},children:e.jsx(zt,{size:20,className:"group-hover:-translate-x-1 transition-transform"})}),n.logoUrl||t.logoUrl?e.jsx("img",{src:V(n.logoUrl||t.logoUrl),className:"w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm",alt:""}):e.jsx("span",{className:"text-3xl shrink-0 drop-shadow-sm",children:"🏥"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-base sm:text-xl whitespace-nowrap overflow-hidden text-ellipsis leading-tight",style:{color:l.text},children:t.name}),e.jsxs("div",{className:"flex items-center gap-2 mt-1",children:[e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em]",style:{color:l.accent},children:t.category}),e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"}),e.jsx("span",{className:"text-[11px] font-bold text-muted-foreground",children:"Editor Mode"})]})]})]}),e.jsxs("button",{onClick:async()=>{try{const m=new FormData;m.append("name",n.name||""),m.append("category",n.category||""),m.append("description",n.description||""),m.append("overview",n.overview||""),m.append("overview2",n.overview2||""),n.faculty&&m.append("faculty",JSON.stringify(n.faculty)),n.facilities&&m.append("facilities",JSON.stringify(n.facilities)),n.activities&&m.append("activities",JSON.stringify(n.activities)),n.logo instanceof File&&m.append("logo",n.logo),await D.put(`/departments/${t._id}`,m),F("Department Updated Successfully"),S()}catch{F("Failed to save changes","error")}},className:"w-full lg:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-sm font-bold text-white shadow-xl hover:opacity-90 active:scale-95 transition-all",style:{background:l.brand},children:[e.jsx(fe,{size:18})," Save All Changes"]})]}),e.jsxs("div",{className:"flex flex-col gap-6",children:[e.jsx(ve,{tabs:["Overview","Faculty","Facilities","Activities","Sliders"],active:o,onChange:i}),e.jsxs("div",{className:"p-7 rounded-3xl shadow-sm border",style:{background:l.surface,borderColor:l.border},children:[o==="Overview"&&e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-5 items-end",children:[e.jsx(c,{label:"Department Display Name",children:e.jsx("input",{value:n.name,onChange:m=>d({...n,name:m.target.value}),className:_,style:U})}),e.jsx(c,{label:"Academic Category",children:e.jsx("input",{value:n.category,onChange:m=>d({...n,category:m.target.value}),className:_,style:U})}),e.jsx(c,{label:"Department Logo",children:e.jsxs("div",{className:"flex items-center gap-3",children:[n.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(n.logo),className:"h-12 w-12 object-cover rounded-xl border",alt:"preview"}):n.logoUrl||t.logoUrl?e.jsx("img",{src:V(n.logoUrl||t.logoUrl),className:"h-12 w-12 object-cover rounded-xl border",alt:"current logo"}):e.jsx("div",{className:"h-12 w-12 rounded-xl flex items-center justify-center text-xl bg-gray-100",children:"🏥"}),e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border bg-white cursor-pointer hover:bg-gray-50 transition text-sm text-gray-500",style:{borderColor:"#E2E8F0"},children:[e.jsx(Q,{size:16}),n.logo instanceof File?"Change Logo":"Upload Image",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:m=>d({...n,logo:m.target.files[0]})})]})]})})]}),e.jsx(c,{label:"Short Introduction",children:e.jsx("input",{value:n.description,onChange:m=>d({...n,description:m.target.value}),className:_,style:U})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-5",children:[e.jsx(c,{label:"Primary Overview Paragraph",children:e.jsx("textarea",{rows:5,value:n.overview,onChange:m=>d({...n,overview:m.target.value}),className:`${_} resize-none`,style:U})}),e.jsx(c,{label:"Secondary Details (Optional)",children:e.jsx("textarea",{rows:5,value:n.overview2,onChange:m=>d({...n,overview2:m.target.value}),className:`${_} resize-none`,style:U})})]})]}),o==="Faculty"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 p-5 rounded-2xl shadow-inner border border-dashed",style:{background:l.bg,borderColor:l.border},children:[["name","designation","qualification"].map(m=>e.jsx("input",{placeholder:m.charAt(0).toUpperCase()+m.slice(1),value:r[m]||"",onChange:N=>u({...r,[m]:N.target.value}),className:_,style:U},m)),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("button",{onClick:()=>{if(r.name){if(C!==null){const m=[...n.faculty];m[C]=r,d({...n,faculty:m}),O(null)}else d({...n,faculty:[...n.faculty,r]});u({name:"",designation:"",qualification:"",specialization:""})}},className:"flex-1 px-4 py-2.5 rounded-xl text-sm font-bold text-white shadow hover:opacity-90 active:scale-95 transition-all",style:{background:l.brand},children:C!==null?"Update Staff":"Add Staff"}),C!==null&&e.jsx("button",{onClick:()=>{O(null),u({name:"",designation:"",qualification:"",specialization:""})},className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition",children:"Cancel"})]})]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:n.faculty.map((m,N)=>e.jsxs("div",{className:`flex items-center justify-between p-4 rounded-2xl shadow-sm border group hover:border-amber-300 transition-all ${C===N?"ring-2 ring-amber-500 bg-amber-50/30":""}`,style:{background:l.bg,borderColor:l.border},children:[e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:l.text},children:m.name}),e.jsxs("div",{className:"flex items-center gap-2 mt-1",children:[e.jsx("p",{className:"text-[10px] font-bold uppercase text-amber-600",children:m.designation}),e.jsx("span",{className:"w-1 h-1 rounded-full bg-gray-300"}),e.jsx("p",{className:"text-[10px] font-medium text-gray-500 truncate",children:m.qualification})]})]}),e.jsxs("div",{className:"flex items-center gap-1.5 ml-2",children:[e.jsx(L,{onClick:()=>{O(N),u({name:m.name||"",designation:m.designation||"",qualification:m.qualification||"",specialization:m.specialization||""})},children:e.jsx(J,{size:15})}),e.jsx(L,{danger:!0,onClick:()=>{d({...n,faculty:n.faculty.filter((p,E)=>E!==N)}),C===N&&(O(null),u({name:"",designation:"",qualification:"",specialization:""}))},children:e.jsx(M,{size:15})})]})]},N))})]}),(o==="Facilities"||o==="Activities")&&(()=>{const m=o==="Facilities"?"facilities":"activities",N=o==="Facilities"?x:g,p=o==="Facilities"?k:y,E=o==="Facilities"?X:K,Z=o==="Facilities"?$:z,me=()=>{if(N.trim()){if(E!==null){const I=[...n[m]];I[E]=N.trim(),d({...n,[m]:I}),Z(null)}else d({...n,[m]:[...n[m],N.trim()]});p("")}};return e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx("input",{value:N,onChange:I=>p(I.target.value),onKeyDown:I=>I.key==="Enter"&&me(),placeholder:E!==null?`Edit ${o.toLowerCase()} point...`:`Describe new ${o.toLowerCase()} point...`,className:`${_} flex-1 shadow-sm`,style:U}),e.jsx("button",{onClick:me,className:"px-6 py-2.5 rounded-xl font-bold text-white shadow-lg hover:opacity-90 active:scale-95 transition-all shrink-0",style:{background:l.brand},children:E!==null?"Update Point":e.jsx(be,{size:20})}),E!==null&&e.jsx("button",{onClick:()=>{Z(null),p("")},className:"px-4 py-2.5 rounded-xl font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition shrink-0 text-xs",children:"Cancel"})]}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:n[m].map((I,se)=>e.jsxs("div",{className:`flex items-center justify-between p-4 rounded-2xl group transition-all border shadow-sm ${E===se?"ring-2 ring-amber-500 bg-amber-50/30":"hover:bg-gray-50"}`,style:{background:l.bg,borderColor:l.border},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0 pr-3",children:[e.jsx("div",{className:"w-6 h-6 rounded-lg bg-white flex items-center justify-center shadow-sm shrink-0",children:e.jsx("span",{className:"text-[10px] font-bold",style:{color:l.accent},children:se+1})}),e.jsx("p",{className:"text-sm leading-relaxed",style:{color:l.text},children:I})]}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(L,{onClick:()=>{Z(se),p(I)},children:e.jsx(J,{size:14})}),e.jsx(L,{danger:!0,onClick:()=>{d({...n,[m]:n[m].filter((Se,we)=>we!==se)}),E===se&&(Z(null),p(""))},children:e.jsx(M,{size:14})})]})]},se))})]})})(),o==="Sliders"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl shadow-inner border border-dashed",style:{background:l.bg,borderColor:l.border},children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm",style:{color:l.text},children:"Department Hero Sliders"}),e.jsx("p",{className:"text-[11px] font-medium mt-0.5",style:{color:l.muted},children:"High-resolution images for the department landing page"})]}),e.jsxs("label",{className:"flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white cursor-pointer shadow-lg active:scale-95 transition-all",style:{background:l.brand},children:[e.jsx(re,{size:16})," Bulk Upload",e.jsx("input",{type:"file",className:"hidden",onChange:m=>{m.target.files[0]&&w(m,t._id)}})]})]}),e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",children:P.filter(m=>m.department?._id===t._id).map(m=>e.jsxs("div",{className:"group relative aspect-video rounded-2xl overflow-hidden shadow-md transition-all hover:shadow-xl",style:{border:`2px solid ${l.border}`},children:[e.jsx("img",{src:V(m.imageUrl),alt:"",className:"w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"}),e.jsx("div",{className:"absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[1px]",children:e.jsx("button",{onClick:()=>b(`/sliders/${m._id}`),className:"p-3 bg-red-500 text-white rounded-2xl shadow-xl hover:bg-red-600 transform transition-transform group-hover:scale-110",children:e.jsx(M,{size:18})})})]},m._id))})]})]})]})]}):e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:oe,title:"Academic Departments",subtitle:`Managing ${s.length} nursing specialties`,action:e.jsx(W,{onClick:()=>{d({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],logo:null}),v("department")},label:"New Department"})}),e.jsxs("div",{className:"admin-department-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[s.map(m=>e.jsxs(ee.div,{whileHover:{y:-4},className:"admin-department-card p-6 rounded-3xl group transition-all relative overflow-hidden",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx("div",{className:"absolute top-0 right-0 w-20 h-20 bg-amber-500 opacity-[0.02] rounded-bl-[80px] group-hover:opacity-[0.06] transition-all"}),e.jsxs("div",{className:"admin-card-actions flex justify-end gap-1.5 mb-3",children:[e.jsx(L,{title:"Edit department",onClick:N=>{N.stopPropagation(),d({...m,logo:null}),v("department",m)},children:e.jsx(J,{size:14})}),e.jsx(L,{danger:!0,title:"Delete department",onClick:N=>{N.stopPropagation(),b(`/departments/${m._id}`)},children:e.jsx(M,{size:14})})]}),e.jsxs("div",{className:"cursor-pointer",onClick:()=>{a(m),d({...m}),i("Overview")},children:[e.jsxs("div",{className:"admin-department-body flex items-center gap-4 mb-5",children:[m.logoUrl?e.jsx("img",{src:V(m.logoUrl),className:"admin-department-logo w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm group-hover:scale-105 transition-transform duration-300",alt:""}):e.jsx("div",{className:"w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0",style:{background:l.accentSoft},children:"🏥"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"admin-department-title font-bold text-sm truncate leading-tight mb-1",style:{color:l.text},children:m.name}),e.jsx(ma,{color:l.brand,children:m.category})]})]}),e.jsxs("div",{className:"admin-department-meta flex items-center justify-between text-[11px] font-bold uppercase tracking-wider",style:{color:l.muted},children:[e.jsxs("div",{className:"flex gap-2 flex-wrap",children:[e.jsxs("span",{children:[m.faculty?.length||0," Staff"]}),e.jsxs("span",{children:[m.facilities?.length||0," Labs"]})]}),e.jsx(pa,{size:14,className:"group-hover:translate-x-1 transition-transform",style:{color:l.accent}})]})]})]},m._id)),s.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(xe,{icon:oe,text:"No departments found"})})]})]})},wi=({editItem:t,formState:a,setFormState:s,closeModal:n,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async r=>{if(r.preventDefault(),!t&&!a.media)return o(`Please select a ${a.mediaType==="video"?"video":"image"}`,"error");const u=new FormData;a.media instanceof File&&u.append("image",a.media),u.append("title",a.title||""),u.append("description",a.description||""),u.append("category",a.category||"college_campus_view"),u.append("mediaType",a.mediaType||"image");const x=t?`/gallery/${t._id}`:"/gallery";try{t?await i.put(x,u):await i.post(x,u),o(t?"Updated":"Created"),n(),d()}catch(k){const g=k.response?.data?.message||"Failed to save gallery item";o(g,"error")}},className:"space-y-5",children:[e.jsx("div",{className:"flex gap-1 p-1 rounded-2xl",style:{background:l.bg,border:`1px solid ${l.border}`},children:["image","video"].map(r=>e.jsxs("button",{type:"button",onClick:()=>s({...a,mediaType:r,media:null}),className:"flex-1 py-2.5 rounded-xl text-sm font-bold transition-all capitalize flex items-center justify-center gap-2",style:{background:a.mediaType===r?l.surface:"transparent",color:a.mediaType===r?l.text:l.muted,boxShadow:a.mediaType===r?"0 1px 6px rgba(0,0,0,0.08)":"none"},children:[r==="image"?e.jsx(Q,{size:15}):e.jsx("span",{style:{fontSize:"15px"},children:"🎬"}),r==="image"?"Image":"Video"]},r))}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Title",required:!0,children:e.jsx(f,{required:!0,value:a.title,onChange:r=>s({...a,title:r.target.value}),placeholder:"e.g. Main Academic Building"})}),e.jsx(c,{label:"Category",children:e.jsxs(ne,{value:a.category,onChange:r=>s({...a,category:r.target.value}),children:[e.jsx("option",{value:"college_campus_view",children:"College Campus View"}),e.jsx("option",{value:"college_highlight",children:"College Highlight"}),e.jsx("option",{value:"hospital",children:"Hospital Main/Additional Images"}),e.jsx("option",{value:"hospital_facility",children:"Hospital Facility & Department"}),e.jsx("option",{value:"event",children:"Main/Additional Event Images"}),e.jsx("option",{value:"event_academic",children:"Academic Events"}),e.jsx("option",{value:"event_cultural",children:"Cultural Events"}),e.jsx("option",{value:"event_sports",children:"Sports Events"}),e.jsx("option",{value:"event_community",children:"Community Service Events"})]})})]}),e.jsx(c,{label:"Description",children:e.jsx(q,{rows:3,value:a.description,onChange:r=>s({...a,description:r.target.value}),placeholder:"Media description..."})}),e.jsxs(c,{label:a.mediaType==="video"?"Video File":"Image File",children:[e.jsx("p",{className:"mb-2 text-xs font-semibold",style:{color:l.muted},children:"Recommended file size: 2–5 MB. Files larger than 5 MB are not accepted."}),e.jsxs("label",{className:"flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-dashed cursor-pointer hover:bg-gray-50 transition",style:{borderColor:a.media?l.accent:l.border},children:[e.jsx("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center shrink-0",style:{background:l.accentSoft},children:a.mediaType==="video"?e.jsx("span",{children:"🎬"}):e.jsx(Q,{size:16,style:{color:l.accent}})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold truncate",style:{color:a.media?l.text:l.muted},children:a.media&&typeof a.media=="object"?a.media.name:`Select ${a.mediaType==="video"?"video":"image"} file`}),e.jsx("p",{className:"text-[11px]",style:{color:l.muted},children:a.mediaType==="video"?"MP4, WebM, OGG, MOV · Max 100MB":"JPG, PNG, WEBP · Max 100MB"})]}),e.jsx("input",{type:"file",className:"hidden",accept:a.mediaType==="video"?"video/mp4,video/webm,video/ogg,video/quicktime":"image/*",onChange:r=>s({...a,media:r.target.files[0]})})]}),a.media&&a.media instanceof File&&(a.mediaType==="video"?e.jsx("video",{src:URL.createObjectURL(a.media),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"180px"}}):e.jsx("img",{src:URL.createObjectURL(a.media),className:"mt-2 h-20 w-20 object-cover rounded-xl border shadow-sm",alt:"preview"})),!a.media&&t&&(t.mediaType==="video"&&t.videoUrl?e.jsx("video",{src:V(t.videoUrl),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"150px"}}):t.imageUrl?e.jsx("img",{src:V(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border shadow-sm",alt:"current"}):null)]}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":a.mediaType==="video"?"Upload Video":"Create Image"})]}),Ni=({galleryImages:t,galleryForm:a,setGalleryForm:s,openModal:n,del:d})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:Q,title:"Photo & Video Gallery",subtitle:"Manage all photos and videos in the gallery",action:e.jsx(W,{onClick:()=>{s({title:"",description:"",category:"college_campus_view",mediaType:"image",media:null}),n("gallery")},label:"Add Media"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(o=>e.jsx(ce,{left:e.jsx("div",{className:"admin-media-thumb w-16 h-12 rounded-xl overflow-hidden border-2 shrink-0 shadow-sm relative",style:{borderColor:l.border},children:o.mediaType==="video"?e.jsx("div",{className:"w-full h-full flex items-center justify-center",style:{background:"#1a1a2e"},children:e.jsx("span",{style:{fontSize:"20px"},children:"🎬"})}):e.jsx("img",{src:V(o.imageUrl),className:"w-full h-full object-cover",alt:""})}),badge:`${o.mediaType==="video"?"🎬 VIDEO · ":""}${o.category.replace(/_/g," ")}`,title:o.title,sub:o.description?.substring(0,50)+"...",onEdit:()=>{s({...o,mediaType:o.mediaType||"image",media:null}),n("gallery",o)},onDelete:()=>d(`/gallery/${o._id}`)},o._id)),t.length===0&&e.jsx(xe,{icon:Q,text:"No gallery media yet. Add your first photo or video."})]})]}),Ci=({institutes:t,openModal:a,del:s})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:oe,title:"Affiliated Institutes",subtitle:`${t.length} partners registered`,action:e.jsx(W,{onClick:()=>a("institute"),label:"Add Institute"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(n=>e.jsx(ce,{left:e.jsx("div",{className:"w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-2xl shadow-sm border border-amber-100",children:n.icon||"🏥"}),badge:n.type,title:n.name,sub:n.capacity,onEdit:()=>a("institute",n),onDelete:()=>s(`/institutes/${n._id}`)},n._id)),t.length===0&&e.jsx(xe,{icon:oe,text:"No institutes registered yet"})]})]}),ki=({editItem:t,closeModal:a,fetchData:s,notify:n})=>{const[d,o]=h.useState({name:"",type:"",description:"",description2:"",description3:"",established:"",capacity:"",icon:"🏥",order:0,specialties:"",services:"",contact:{address:"",phone:"",website:""}});h.useEffect(()=>{t&&o({...t,order:t.order||0,specialties:Array.isArray(t.specialties)?t.specialties.join(", "):"",services:Array.isArray(t.services)?t.services.join(", "):"",contact:{address:t.contact?.address||"",phone:t.contact?.phone||"",website:t.contact?.website||""}})},[t]);const i=async r=>{r.preventDefault();const u={...d,specialties:d.specialties.split(",").map(x=>x.trim()).filter(Boolean),services:d.services.split(",").map(x=>x.trim()).filter(Boolean)};try{t?await j.put(`/institutes/${t._id}`,u):await j.post("/institutes",u),n(t?"Updated":"Created"),a(),s()}catch{n("Operation failed","error")}};return e.jsxs("form",{onSubmit:i,className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Institute Name",required:!0,children:e.jsx(f,{required:!0,value:d.name,onChange:r=>o({...d,name:r.target.value}),placeholder:"e.g. Government Spine Institute"})}),e.jsx(c,{label:"Type (e.g. Hospital)",required:!0,children:e.jsx(f,{required:!0,value:d.type,onChange:r=>o({...d,type:r.target.value}),placeholder:"e.g. Educational Institute"})})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-4",children:[e.jsx(c,{label:"Established",children:e.jsx(f,{value:d.established,onChange:r=>o({...d,established:r.target.value}),placeholder:"e.g. 1980"})}),e.jsx(c,{label:"Capacity",children:e.jsx(f,{value:d.capacity,onChange:r=>o({...d,capacity:r.target.value}),placeholder:"e.g. 80 Beds"})}),e.jsx(c,{label:"Icon Emoji",children:e.jsx(f,{value:d.icon,onChange:r=>o({...d,icon:r.target.value})})}),e.jsx(c,{label:"Sort Order",children:e.jsx(f,{type:"number",required:!0,value:d.order,onChange:r=>o({...d,order:parseInt(r.target.value)||0})})})]}),e.jsx(c,{label:"Main Description",required:!0,children:e.jsx(q,{required:!0,rows:3,value:d.description,onChange:r=>o({...d,description:r.target.value}),placeholder:"Main description..."})}),e.jsx(c,{label:"Additional Description",children:e.jsx(q,{rows:2,value:d.description2,onChange:r=>o({...d,description2:r.target.value}),placeholder:"Extra details..."})}),e.jsx(c,{label:"Clinical Areas (comma separated)",children:e.jsx(q,{rows:2,value:d.specialties,onChange:r=>o({...d,specialties:r.target.value}),placeholder:"e.g. Orthopedics, Spine Surgery"})}),e.jsx(c,{label:"Key Services (comma separated)",children:e.jsx(q,{rows:2,value:d.services,onChange:r=>o({...d,services:r.target.value}),placeholder:"e.g. Emergency, OPD, ICU"})}),e.jsx(je,{title:"Contact Details",children:e.jsxs("div",{className:"p-4 rounded-2xl bg-white space-y-4 border border-gray-200",children:[e.jsx(c,{label:"Address",children:e.jsx(f,{value:d.contact.address,onChange:r=>o({...d,contact:{...d.contact,address:r.target.value}}),placeholder:"Institute address..."})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Phone",children:e.jsx(f,{value:d.contact.phone,onChange:r=>o({...d,contact:{...d.contact,phone:r.target.value}}),placeholder:"Contact number..."})}),e.jsx(c,{label:"Website",children:e.jsx(f,{value:d.contact.website,onChange:r=>o({...d,contact:{...d.contact,website:r.target.value}}),placeholder:"https://..."})})]})]})}),e.jsx(G,{onCancel:a,submitLabel:t?"Save Changes":"Create Institute"})]})},Ai=({editItem:t,keyPersonForm:a,setKeyPersonForm:s,closeModal:n,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async r=>{r.preventDefault();const u=t?`/contact/key-persons/${t._id}`:"/contact/key-persons",x={...a,responsibilities:typeof a.responsibilities=="string"?a.responsibilities.split(`
`).filter(Boolean):a.responsibilities};try{t?await i.put(u,x):await i.post(u,x),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Name",required:!0,children:e.jsx(f,{required:!0,value:a.name,onChange:r=>s({...a,name:r.target.value}),placeholder:"Full name"})}),e.jsx(c,{label:"Position",required:!0,children:e.jsx(f,{required:!0,value:a.position,onChange:r=>s({...a,position:r.target.value}),placeholder:"e.g. Principal"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Qualification",children:e.jsx(f,{value:a.qualification,onChange:r=>s({...a,qualification:r.target.value}),placeholder:"e.g. M.Sc. Nursing, Ph.D."})}),e.jsx(c,{label:"Phone",children:e.jsx(f,{value:a.phone,onChange:r=>s({...a,phone:r.target.value}),placeholder:"Phone number"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Email",children:e.jsx(f,{value:a.email,onChange:r=>s({...a,email:r.target.value}),placeholder:"Email address"})}),e.jsx(c,{label:"Office Hours",children:e.jsx(f,{value:a.hours,onChange:r=>s({...a,hours:r.target.value}),placeholder:"e.g. 9:00 AM - 5:00 PM"})})]}),e.jsx(c,{label:"Icon Emoji",children:e.jsx(f,{value:a.icon,onChange:r=>s({...a,icon:r.target.value})})}),e.jsx(c,{label:"Responsibilities (one per line)",required:!0,children:e.jsx(q,{required:!0,rows:4,value:a.responsibilities,onChange:r=>s({...a,responsibilities:r.target.value}),placeholder:`Responsibility 1
Responsibility 2`})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Key Contact"})]}),Di=({editItem:t,contactDeptForm:a,setContactDeptForm:s,closeModal:n,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async r=>{r.preventDefault();const u=t?`/contact/departments/${t._id}`:"/contact/departments";try{t?await i.put(u,a):await i.post(u,a),o("Saved"),n(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Department Name",required:!0,children:e.jsx(f,{required:!0,value:a.name,onChange:r=>s({...a,name:r.target.value}),placeholder:"e.g. Admission Office"})}),e.jsx(c,{label:"Icon Emoji",children:e.jsx(f,{value:a.icon,onChange:r=>s({...a,icon:r.target.value})})})]}),e.jsx(c,{label:"Phone",children:e.jsx(f,{value:a.phone,onChange:r=>s({...a,phone:r.target.value}),placeholder:"Phone number"})}),e.jsx(c,{label:"Email",children:e.jsx(f,{value:a.email,onChange:r=>s({...a,email:r.target.value}),placeholder:"Email address"})}),e.jsx(G,{onCancel:n,submitLabel:t?"Save Changes":"Add Department Contact"})]}),Ei=({contactSub:t,setContactSub:a,keyPersons:s,setKeyPersonForm:n,contactDepartments:d,setContactDeptForm:o,contactInfo:i,setContactInfo:r,openModal:u,del:x,notify:k,axiosInstance:g})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(ve,{tabs:["Key Persons","Departments","College Info"],active:t,onChange:a}),t==="Key Persons"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:ue,title:"Key Administrative Contacts",subtitle:"Manage main contacts shown on the contact page",action:e.jsx(W,{onClick:()=>{n({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),u("keyPerson")},label:"Add Person"})}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:s.map(y=>e.jsx(ce,{icon:y.icon,title:y.name,sub:y.position,onEdit:()=>{n({...y,responsibilities:y.responsibilities?.join(`
`)||""}),u("keyPerson",y)},onDelete:()=>x(`/contact/key-persons/${y._id}`)},y._id))})]}),t==="Departments"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:oe,title:"Department Contact Directory",subtitle:"Manage specific departments on the contact page",action:e.jsx(W,{onClick:()=>{o({name:"",phone:"",email:"",icon:"📚"}),u("contactDept")},label:"Add Department"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:d.map(y=>e.jsx(ce,{icon:y.icon,title:y.name,sub:y.phone+" | "+y.email,onEdit:()=>{o({...y}),u("contactDept",y)},onDelete:()=>x(`/contact/departments/${y._id}`)},y._id))})]}),t==="College Info"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(Y,{icon:Et,title:"College Contact Information",subtitle:"Address, phone, and general emails"}),e.jsxs("div",{className:"p-6 rounded-2xl space-y-4 shadow-sm",style:{background:l.surface,border:`1px solid ${l.border}`},children:[e.jsx(c,{label:"College Address",children:e.jsx("textarea",{required:!0,rows:4,value:i.address||"",onChange:y=>r({...i,address:y.target.value}),className:`${_} resize-none`,style:U})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(c,{label:"Reception Phone",children:e.jsx("input",{value:i.receptionPhone||"",onChange:y=>r({...i,receptionPhone:y.target.value}),className:_,style:U})}),e.jsx(c,{label:"Ambulance Phone",children:e.jsx("input",{value:i.ambulancePhone||"",onChange:y=>r({...i,ambulancePhone:y.target.value}),className:_,style:U})})]}),e.jsx(c,{label:"General Email",children:e.jsx("input",{value:i.generalEmail||"",onChange:y=>r({...i,generalEmail:y.target.value}),className:_,style:U})}),e.jsx("button",{onClick:async()=>{try{await g.put("/contact/info",i),k("Contact Info Saved")}catch{k("Failed to save","error")}},className:"px-6 py-2.5 rounded-xl text-sm font-bold text-white shadow-md hover:opacity-90",style:{background:l.brand},children:"Save College Info"})]})]})]}),Si=({notify:t})=>{const{sectionsList:a,loading:s,toggleSection:n,togglePageSections:d}=Ct(),[o,i]=h.useState("Home Page"),[r,u]=h.useState(""),x=["Home Page","About Us","Admission","Departments","Gallery","Institutes","Student Corner","Contact Us","All Pages"],k=x.reduce((v,b)=>(v[b]=b==="All Pages"?a.length:a.filter(w=>w.page===b).length,v),{}),y=a.filter(v=>{const b=o==="All Pages"||v.page===o,w=(v.sectionName||"").toLowerCase().includes(r.toLowerCase())||(v.description||"").toLowerCase().includes(r.toLowerCase())||(v.sectionKey||"").toLowerCase().includes(r.toLowerCase());return b&&w}).reduce((v,b)=>(v[b.page]=v[b.page]||[],v[b.page].push(b),v),{}),P=a.length,D=a.filter(v=>v.isVisible!==!1).length,S=P-D,F=P?Math.round(D/P*100):0;return e.jsxs("div",{className:"section-control-shell",children:[e.jsx("style",{children:`
        .section-control-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .section-control-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: stretch;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.96), rgba(255,250,246,0.92)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .section-control-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .section-control-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .section-control-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .section-control-subtitle {
          margin: 8px 0 0;
          max-width: 660px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .section-control-metrics {
          display: grid;
          grid-template-columns: repeat(3, minmax(92px, 1fr));
          gap: 10px;
          min-width: 340px;
        }
        .section-control-metric {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .section-control-metric strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .section-control-metric span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .section-control-progress {
          grid-column: 1 / -1;
          height: 8px;
          overflow: hidden;
          border-radius: 99px;
          background: #EFE7DF;
        }
        .section-control-progress > span {
          display: block;
          height: 100%;
          width: var(--section-progress, 0%);
          border-radius: inherit;
          background: linear-gradient(90deg, #16A34A, #E07B39);
        }
        .section-control-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(260px, 360px);
          gap: 16px;
          align-items: start;
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .section-control-tabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          min-width: 0;
        }
        .section-control-tab {
          min-height: 36px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 7px 12px;
          color: #655646;
          background: #FBFAF8;
          font-size: 12px;
          font-weight: 800;
          line-height: 1;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .section-control-tab:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .section-control-tab.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        .section-control-count {
          min-width: 22px;
          height: 22px;
          padding: 0 7px;
          border-radius: 999px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: inherit;
          background: rgba(255,255,255,0.65);
          font-size: 11px;
          font-weight: 900;
        }
        .section-control-tab.is-active .section-control-count {
          background: rgba(255,255,255,0.18);
        }
        .section-control-search {
          position: relative;
          min-width: 0;
        }
        .section-control-search input {
          width: 100%;
          height: 42px;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 0 38px 0 40px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-search input:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .section-control-search svg {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #9A806B;
        }
        .section-control-clear {
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 26px;
          height: 26px;
          border-radius: 8px;
          color: #8A7A6A;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .section-control-clear:hover {
          background: #EFE7DF;
          color: #1A1208;
        }
        .section-control-loading {
          min-height: 280px;
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          color: #8A7A6A;
          font-size: 14px;
          font-weight: 800;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
        }
        .section-control-spinner {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          border: 3px solid #E8E0D8;
          border-top-color: #6B3F1D;
          animation: section-spin 800ms linear infinite;
        }
        @keyframes section-spin {
          to { transform: rotate(360deg); }
        }
        .section-control-groups {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        .section-control-group {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .section-control-group-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .section-control-group-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-group-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .section-control-group-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 16px;
          line-height: 1.2;
          font-weight: 900;
        }
        .section-control-group-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .section-control-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 0 0 auto;
        }
        .section-control-action {
          height: 34px;
          border: 1px solid transparent;
          border-radius: 10px;
          padding: 0 12px;
          font-size: 12px;
          font-weight: 900;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
        }
        .section-control-action:hover {
          transform: translateY(-1px);
        }
        .section-control-action.on {
          color: #146C3E;
          background: #ECFDF3;
          border-color: #B8E7CA;
        }
        .section-control-action.off {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-control-list {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          padding: 16px;
        }
        .section-control-card {
          position: relative;
          min-width: 0;
          min-height: 108px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 14px;
          align-items: center;
          padding: 16px 16px 16px 18px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          transition: transform 160ms ease, border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-card::before {
          content: "";
          position: absolute;
          left: 0;
          top: 12px;
          bottom: 12px;
          width: 4px;
          border-radius: 0 999px 999px 0;
          background: #16A34A;
        }
        .section-control-card:hover {
          transform: translateY(-1px);
          border-color: #D8C8B7;
          box-shadow: 0 14px 28px rgba(65, 42, 22, 0.08);
        }
        .section-control-card.is-hidden {
          background: #FBFAF8;
        }
        .section-control-card.is-hidden::before {
          background: #D94B4B;
        }
        .section-control-card-copy {
          min-width: 0;
        }
        .section-control-status-row {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
          margin-bottom: 9px;
        }
        .section-control-status {
          min-width: 72px;
          border-radius: 999px;
          padding: 5px 9px;
          color: #146C3E;
          background: #ECFDF3;
          border: 1px solid #B8E7CA;
          font-size: 10px;
          font-weight: 950;
          line-height: 1;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-align: center;
          flex: 0 0 auto;
        }
        .section-control-card.is-hidden .section-control-status {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-control-key {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          border: 1px solid #E7DDD2;
          border-radius: 8px;
          padding: 4px 8px;
          color: #725B45;
          background: #FFF8F1;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
          font-size: 11px;
          line-height: 1.2;
        }
        .section-control-card h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .section-control-card p {
          margin: 5px 0 0;
          color: #756657;
          font-size: 12px;
          line-height: 1.45;
          font-weight: 600;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .section-toggle {
          width: 58px;
          height: 32px;
          border: 0;
          border-radius: 999px;
          background: #16A34A;
          padding: 3px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: flex-end;
          box-shadow: inset 0 0 0 1px rgba(0,0,0,0.08);
          transition: background 180ms ease;
        }
        .section-toggle.is-off {
          justify-content: flex-start;
          background: #CBD5E1;
        }
        .section-toggle span {
          width: 26px;
          height: 26px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #16A34A;
          background: #FFFFFF;
          box-shadow: 0 3px 8px rgba(0,0,0,0.18);
        }
        .section-toggle.is-off span {
          color: #64748B;
        }
        @media (max-width: 1180px) {
          .section-control-hero,
          .section-control-toolbar {
            grid-template-columns: 1fr;
          }
          .section-control-metrics {
            min-width: 0;
          }
        }
        @media (max-width: 860px) {
          .section-control-list {
            grid-template-columns: 1fr;
          }
          .section-control-group-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .section-control-actions {
            width: 100%;
          }
          .section-control-action {
            flex: 1 1 0;
          }
        }
        @media (max-width: 560px) {
          .section-control-hero,
          .section-control-toolbar {
            padding: 14px;
            border-radius: 14px;
          }
          .section-control-title {
            font-size: 21px;
          }
          .section-control-title-row {
            align-items: flex-start;
          }
          .section-control-metrics {
            grid-template-columns: 1fr;
          }
          .section-control-card {
            grid-template-columns: 1fr;
          }
          .section-toggle {
            width: 100%;
            justify-content: flex-end;
          }
          .section-toggle.is-off {
            justify-content: flex-start;
          }
          .section-control-tabs {
            flex-wrap: nowrap;
            overflow-x: auto;
            padding-bottom: 2px;
          }
        }
      `}),e.jsxs("div",{className:"section-control-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"section-control-title-row",children:[e.jsx("div",{className:"section-control-icon",children:e.jsx(xa,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"section-control-kicker",children:"Site Content Manager"}),e.jsx("h2",{className:"section-control-title",children:"Section Visibility"})]})]}),e.jsx("p",{className:"section-control-subtitle",children:"Live control for public page sections, grouped by page with quick search and bulk status actions."})]}),e.jsxs("div",{className:"section-control-metrics",children:[e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{children:P}),e.jsx("span",{children:"Total"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#16A34A"},children:D}),e.jsx("span",{children:"Visible"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#D94B4B"},children:S}),e.jsx("span",{children:"Hidden"})]}),e.jsx("div",{className:"section-control-progress",style:{"--section-progress":`${F}%`},children:e.jsx("span",{})})]})]}),e.jsxs("div",{className:"section-control-toolbar",children:[e.jsx("div",{className:"section-control-tabs",children:x.map(v=>{const b=o===v;return e.jsxs("button",{type:"button",onClick:()=>i(v),className:`section-control-tab ${b?"is-active":""}`,children:[v,e.jsx("span",{className:"section-control-count",children:k[v]})]},v)})}),e.jsxs("div",{className:"section-control-search",children:[e.jsx(Yt,{size:16}),e.jsx("input",{type:"text",placeholder:"Search sections...",value:r,onChange:v=>u(v.target.value)}),r&&e.jsx("button",{type:"button",className:"section-control-clear",onClick:()=>u(""),"aria-label":"Clear search",children:e.jsx(de,{size:15})})]})]}),s?e.jsxs("div",{className:"section-control-loading",children:[e.jsx("span",{className:"section-control-spinner"}),"Loading visibility settings..."]}):Object.keys(y).length===0?e.jsx(xe,{icon:ke,text:"No sections found matching filter search."}):e.jsx("div",{className:"section-control-groups",children:Object.entries(y).map(([v,b])=>e.jsxs("div",{className:"section-control-group",children:[e.jsxs("div",{className:"section-control-group-head",children:[e.jsxs("div",{className:"section-control-group-title",children:[e.jsx("div",{className:"section-control-group-icon",children:e.jsx(Ee,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{children:v}),e.jsxs("p",{children:[b.length," sections configured"]})]})]}),e.jsxs("div",{className:"section-control-actions",children:[e.jsxs("button",{type:"button",onClick:async()=>{try{await d(v,!0),t(`Turned ALL sections ON for ${v}`)}catch{t("Update failed","error")}},className:"section-control-action on",children:[e.jsx(le,{size:14})," All ON"]}),e.jsxs("button",{type:"button",onClick:async()=>{try{await d(v,!1),t(`Turned ALL sections OFF for ${v}`)}catch{t("Update failed","error")}},className:"section-control-action off",children:[e.jsx(de,{size:14})," All OFF"]})]})]}),e.jsx("div",{className:"section-control-list",children:b.map(w=>{const C=w.isVisible!==!1;return e.jsxs("div",{className:`section-control-card ${C?"":"is-hidden"}`,children:[e.jsxs("div",{className:"section-control-card-copy",children:[e.jsxs("div",{className:"section-control-status-row",children:[e.jsx("span",{className:"section-control-status",children:C?"Visible":"Hidden"}),e.jsx("span",{className:"section-control-key",children:w.sectionKey})]}),e.jsx("h4",{children:w.sectionName}),w.description&&e.jsx("p",{children:w.description})]}),e.jsx("button",{type:"button","aria-pressed":C,"aria-label":`Toggle ${w.sectionName}`,onClick:async()=>{try{await n(w.sectionKey,!C),t(`${w.sectionName} is now ${C?"OFF (Hidden)":"ON (Visible)"}`)}catch{t("Update failed","error")}},className:`section-toggle ${C?"":"is-off"}`,children:e.jsx("span",{children:C?e.jsx(le,{size:15}):e.jsx(de,{size:15})})})]},w.sectionKey)})})]},v))})]})},Bi=({onLogout:t})=>{const[a,s]=h.useState("Home Page"),[n,d]=h.useState("Branding"),[o,i]=h.useState("Courses"),[r,u]=h.useState("Overview"),[x,k]=h.useState("Key Persons"),[g,y]=h.useState(!1),[P,D]=h.useState("null"),[S,F]=h.useState(null),[v,b]=h.useState(!1),[w,C]=h.useState(null),[O,X]=h.useState(!1),[$,K]=h.useState(!1),[z,m]=h.useState(""),[N,p]=h.useState(null),[E,Z]=h.useState(window.innerWidth<1024);h.useEffect(()=>{const A=()=>Z(window.innerWidth<1024);return window.addEventListener("resize",A),()=>window.removeEventListener("resize",A)},[]);const[me,I]=h.useState([]),[se,Se]=h.useState([]),[we,fa]=h.useState([]),[ja,Fe]=h.useState({title:"",description1:"",description2:""}),[ya,ze]=h.useState([]),[va,Be]=h.useState({name:"",title:"",greeting:"",paragraphs:[],highlight:"",photoUrl:"",stats:[]}),[wa,Pe]=h.useState({logoUrl:"",collegeName:"",tagline:""}),[Na,$e]=h.useState([]),[Ca,_e]=h.useState({heroTitle:"Our History",timelineTitle:"Institutional Timeline",timelineParagraphs:[],legacyTitle:"Legacy of Excellence",legacyParagraphs:[]}),[ka,Aa]=h.useState([]),[Da,Ea]=h.useState([]),[Sa,Fa]=h.useState([]),[za,Ba]=h.useState([]),[Pa,$a]=h.useState([]),[_a,Ua]=h.useState([]),[qa,Ta]=h.useState([]),[Ue,La]=h.useState([]),[Ha,Ra]=h.useState([]),[Ma,Ga]=h.useState([]),[Oa,Va]=h.useState([]),[Ya,qe]=h.useState({address:"",receptionPhone:"",ambulancePhone:"",generalEmail:""}),[Wa,Te]=h.useState({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),[Le,He]=h.useState({name:"",role:"",content:"",rating:5,image:null}),[Re,Me]=h.useState({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),[Ja,Ge]=h.useState({type:"vision",content:"",order:0}),[Qa,Oe]=h.useState({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),[Xa,Ve]=h.useState({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),[Za,Ye]=h.useState({step:1,title:"",description:"",details:"",icon:"Calendar"}),[Ka,We]=h.useState({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),[Ia,Je]=h.useState({type:"student",title:"",content:"",order:0}),[et,Qe]=h.useState({category:"General Guidelines",subCategory:"",points:"",order:0}),[Xe,Ze]=h.useState({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],icon:"🏥"}),[at,tt]=h.useState({name:"",designation:"",qualification:"",specialization:""}),[it,st]=h.useState(""),[rt,nt]=h.useState(""),[lt,ot]=h.useState(null),[dt,ct]=h.useState(null),[pt,xt]=h.useState({}),[mt,gt]=h.useState([]),[Ke,Ie]=h.useState({title:"",description:"",category:"college_campus_view",image:null}),[ht,ea]=h.useState({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),[ut,aa]=h.useState({name:"",phone:"",email:"",icon:"📚"}),[bt,ta]=h.useState([]),[ft,ia]=h.useState({title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0}),B=(A,ie="success")=>{C({message:A,type:ie}),setTimeout(()=>C(null),3e3)};h.useEffect(()=>{T()},[]);const T=async()=>{b(!0);try{const A=await Promise.all([j.get("/programs"),j.get("/testimonials"),j.get("/content/academic"),j.get("/about/milestones"),j.get("/about/dean"),j.get("/about/college-logo"),j.get("/about/images"),j.get("/about/vision-mission"),j.get("/about/core-values"),j.get("/courses"),j.get("/admission-steps"),j.get("/admission-rules"),j.get("/bonds"),j.get("/guidelines"),j.get("/departments"),j.get("/sliders?department=all"),j.get("/gallery"),j.get("/institutes"),j.get("/contact/key-persons"),j.get("/contact/departments"),j.get("/contact/info"),j.get("/about/history-content")]);Se(A[0].data),fa(A[1].data),Fe(A[2].data),ze(A[3].data),Be(A[4].data),Pe(A[5].data),$e(A[6].data),Aa(A[7].data),Ea(A[8].data),Fa(A[9].data),Ba(A[10].data),$a(A[11].data),Ua(A[12].data),Ta(A[13].data),La(A[14].data),I(A[15].data),gt(A[16].data),Ra(A[17].data),Ga(A[18].data),Va(A[19].data),qe(A[20].data),A[21]?.data&&_e(A[21].data)}catch{B("Error fetching data","error")}finally{try{const{data:A}=await j.get("/student-corner");ta(Array.isArray(A)?A:[])}catch{ta([]),B("Unable to load Student Corner data","error")}b(!1)}},ae=async(A,ie=!0)=>{if(window.confirm("Are you sure?"))try{await j.delete(A),B("Deleted"),ie&&T()}catch{B("Delete failed","error")}},sa=async(A,ie)=>{const ge=Array.from(A.target?.files||[A]);if(!ge.length)return;const Ne=new FormData;ge.forEach(vt=>Ne.append("images",vt));const na=ie||P;na!=="null"&&Ne.append("department",na);try{await j.post("/sliders/upload",Ne),B("Uploaded"),T()}catch{B("Upload failed","error")}},jt=async(A,ie)=>{const ge=new FormData;ge.append("image",ie);try{await j.put(`/sliders/${A}`,ge),B("Updated"),T()}catch{B("Update failed","error")}},te=(A,ie=null)=>{m(A),p(ie),X(!0)},H=()=>{X(!1),p(null)},yt=[{name:"Section Control",icon:xa},{name:"Home Page",icon:Q},{name:"Academic",icon:Ce},{name:"Testimonials",icon:ue},{name:"About Us",icon:Ae},{name:"Admission",icon:Ee},{name:"Departments",icon:oe},{name:"Institutes",icon:oe},{name:"Gallery",icon:Q},{name:"Student Corner",icon:ye},{name:"Contact Us",icon:wt},{name:"Settings",icon:oa}],ra={program:{title:N?"Edit Program":"Add Program",subtitle:"Academic program details"},testimonial:{title:N?"Edit Testimonial":"Add Testimonial",subtitle:"Student review"},milestone:{title:N?"Edit Milestone":"Add Milestone",subtitle:"Timeline entry"},visionMission:{title:N?"Edit Point":"Add Point",subtitle:"Vision or Mission statement"},coreValue:{title:N?"Edit Value":"Add Core Value",subtitle:"Institutional value"},course:{title:N?"Edit Course":"Add Course",subtitle:"Admission course"},step:{title:N?"Edit Step":"Add Step",subtitle:"Admission procedure step"},rule:{title:N?"Edit Rule":"Add Rule",subtitle:"Eligibility rule"},bond:{title:N?"Edit Bond":"Add Bond Point",subtitle:"Student bond"},guideline:{title:N?"Edit Guidelines":"Add Guidelines",subtitle:"Student / parent guidance"},department:{title:N?"Edit Dept":"Add Department",subtitle:"Create a new department"},gallery:{title:N?"Edit Photo":"Add Photo",subtitle:"Gallery image"},institute:{title:N?"Edit Institute":"Add Institute",subtitle:"Affiliated institute details"},keyPerson:{title:N?"Edit Contact":"Add Contact",subtitle:"Key administrative contact"},contactDept:{title:N?"Edit Dept":"Add Dept",subtitle:"Contact department"},studentCorner:{title:N?"Edit Section":"Add Section",subtitle:"Student Corner document section"}}[z]||{};return e.jsxs("div",{className:"admin-shell flex flex-1 h-full w-full min-h-0 bg-gray-50 text-gray-900 font-sans overflow-hidden relative items-stretch",style:{display:"flex",height:"100dvh",minHeight:"100dvh",maxHeight:"100dvh",width:"100%",overflow:"hidden"},children:[e.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
        * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
        html, body, #root {
          height: 100%;
        }
        body:has(.admin-shell) {
          overflow: hidden;
        }
        .admin-shell {
          display: flex !important;
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-sidebar {
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
          background:
            linear-gradient(180deg, #6B3F1D 0%, #633815 46%, #4E2B12 100%) !important;
          box-shadow: inset -1px 0 0 rgba(255,255,255,0.07);
        }
        .admin-sidebar nav button {
          min-height: 46px;
          border: 1px solid transparent;
        }
        .admin-sidebar nav button:hover {
          background: rgba(255,255,255,0.09) !important;
          color: rgba(255,255,255,0.9) !important;
          border-color: rgba(255,255,255,0.08);
        }
        .admin-sidebar nav button[style*="rgba(255,255,255,0.12)"] {
          background: rgba(255,255,255,0.15) !important;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 12px 24px rgba(37, 22, 10, 0.16);
        }
        .admin-main {
          display: flex !important;
          flex-direction: column !important;
          flex: 1 1 auto !important;
          min-width: 0 !important;
          min-height: 0 !important;
          height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-header {
          height: 64px !important;
          min-height: 64px !important;
        }
        .admin-content-scroll {
          flex: 1 1 auto !important;
          min-height: 0 !important;
          height: calc(100dvh - 64px) !important;
          overflow-y: auto !important;
          overflow-x: hidden !important;
          overscroll-behavior: contain;
        }
        .admin-page-inner {
          width: 100%;
          max-width: 1580px !important;
        }
        @media (max-width: 1023px) {
          .admin-header {
            height: 56px !important;
            min-height: 56px !important;
          }
          .admin-content-scroll {
            height: calc(100dvh - 56px) !important;
          }
        }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        /* Premium admin scrollbar */
        .admin-scroll::-webkit-scrollbar { width: 8px; }
        .admin-scroll::-webkit-scrollbar-track { background: #F4F1EE; border-radius: 10px; }
        .admin-scroll::-webkit-scrollbar-thumb { background: #C4A882; border-radius: 10px; border: 2px solid #F4F1EE; }
        .admin-scroll::-webkit-scrollbar-thumb:hover { background: #6B3F1D; }
        .admin-scroll { scrollbar-width: thin; scrollbar-color: #C4A882 #F4F1EE; -webkit-overflow-scrolling: touch; }
        .admin-header {
          background:
            linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,252,249,0.96)) !important;
          box-shadow: 0 1px 0 rgba(232, 224, 216, 0.78), 0 10px 30px rgba(65, 42, 22, 0.04);
        }
        .admin-header h2 {
          letter-spacing: 0;
        }
        .admin-header-chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          height: 32px;
          padding: 0 12px;
          border: 1px solid #EEE2D6;
          border-radius: 999px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 800;
        }
        .admin-header-dot {
          width: 8px;
          height: 8px;
          border-radius: 999px;
          background: #16A34A;
          box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.12);
        }
        .admin-content-scroll {
          background:
            radial-gradient(circle at top right, rgba(224, 123, 57, 0.07), transparent 34%),
            linear-gradient(180deg, #F8F6F3 0%, #F4F1EE 100%);
        }
        .admin-section-header,
        .admin-row-item,
        .admin-department-card {
          border-radius: 18px !important;
          box-shadow: 0 14px 32px rgba(65, 42, 22, 0.055);
        }
        .admin-section-header {
          min-height: 76px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.98), rgba(255,248,241,0.88)) !important;
        }
        .admin-section-icon,
        .admin-row-icon {
          box-shadow: inset 0 0 0 1px rgba(224, 123, 57, 0.12);
        }
        .admin-section-title,
        .admin-row-title,
        .admin-department-title {
          letter-spacing: 0;
        }
        .admin-section-subtitle,
        .admin-row-subtitle {
          font-weight: 600;
        }
        .admin-add-btn {
          min-height: 38px;
          border-radius: 999px !important;
          padding-inline: 16px !important;
          background: linear-gradient(135deg, #6B3F1D 0%, #8A4E23 100%) !important;
          box-shadow: 0 12px 22px rgba(107, 63, 29, 0.18);
          white-space: nowrap;
        }
        .admin-icon-btn {
          width: 36px;
          height: 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(226, 217, 208, 0.82);
          border-radius: 12px !important;
          box-shadow: 0 6px 14px rgba(17, 24, 39, 0.04);
        }
        .admin-icon-btn.is-danger {
          border-color: rgba(254, 226, 226, 0.95);
        }
        .admin-row-item {
          min-height: 82px;
          background: rgba(255,255,255,0.96) !important;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-row-item:hover {
          transform: translateY(-2px);
          border-color: #D8C6B4 !important;
          box-shadow: 0 18px 38px rgba(65, 42, 22, 0.085);
        }
        .admin-row-actions {
          padding-left: 12px;
        }
        .admin-pill {
          border-radius: 999px !important;
          text-transform: none !important;
          letter-spacing: 0 !important;
          font-size: 12px !important;
          line-height: 1.15;
          padding: 5px 10px !important;
        }
        .admin-department-grid {
          align-items: stretch;
        }
        .admin-department-card {
          min-height: 178px;
          background: rgba(255,255,255,0.96) !important;
          cursor: default;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-department-card:hover {
          border-color: #D8C6B4 !important;
          box-shadow: 0 20px 44px rgba(65, 42, 22, 0.1);
        }
        .admin-department-body {
          align-items: flex-start;
        }
        .admin-department-body > :first-child,
        .admin-media-thumb {
          box-shadow: 0 8px 18px rgba(65, 42, 22, 0.08);
        }
        .admin-department-title {
          white-space: normal !important;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
          min-height: 38px;
          font-size: 15px !important;
          line-height: 1.28 !important;
        }
        .admin-department-meta {
          margin-top: auto;
          padding-top: 14px;
          border-top: 1px solid #F0E7DF;
          letter-spacing: 0 !important;
          text-transform: none !important;
          font-size: 13px !important;
        }
        .admin-department-meta span {
          display: inline-flex;
          align-items: center;
          min-height: 24px;
          padding: 4px 9px;
          border-radius: 999px;
          color: #6F6254;
          background: #F7F2ED;
        }
        .admin-media-thumb {
          width: 72px !important;
          height: 52px !important;
          border-width: 1px !important;
        }
        .admin-subtabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding: 10px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .admin-subtabs button {
          min-height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 8px 15px;
          color: #655646;
          background: #FBFAF8;
          font-size: 13px;
          font-weight: 850;
          line-height: 1;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .admin-subtabs button:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .admin-subtabs button.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        @media (max-width: 640px) {
          .admin-section-header {
            padding: 16px !important;
          }
          .admin-add-btn {
            width: 100%;
            justify-content: center;
          }
          .admin-row-item {
            align-items: flex-start;
            gap: 12px;
            padding: 14px !important;
          }
          .admin-row-actions {
            opacity: 1 !important;
            padding-left: 0;
          }
          .admin-icon-btn {
            width: 34px;
            height: 34px;
          }
          .admin-subtabs {
            flex-wrap: nowrap;
            overflow-x: auto;
          }
        }
      `}),e.jsx(mi,{isMobile:E,sidebarOpen:g,setSidebarOpen:y,activeTab:a,setActiveTab:s,selectedDept:S,setSelectedDept:F,navItems:yt,onLogout:t}),e.jsxs("main",{className:"admin-main flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-gray-50",style:{height:"100dvh",minHeight:0,overflow:"hidden"},children:[e.jsx(hi,{setSidebarOpen:y,selectedDept:S,activeTab:a,onOpenResetPassword:()=>K(!0)}),e.jsx(It,{note:w,onDismiss:()=>C(null)}),e.jsx("div",{className:"admin-content-scroll flex-1 min-h-0 overflow-y-auto admin-scroll p-4 md:p-6 lg:p-8",children:e.jsxs("div",{className:"admin-page-inner max-w-7xl mx-auto pb-24",children:[v&&e.jsx("div",{className:"absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm",children:e.jsx("div",{className:"w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"})}),e.jsx(pe,{mode:"wait",children:e.jsxs(ee.div,{initial:{opacity:0,y:12},animate:{opacity:1,y:0},exit:{opacity:0,y:-12},transition:{duration:.25},children:[a==="Section Control"&&e.jsx(Si,{notify:B}),a==="Home Page"&&e.jsx(ui,{selectedDeptForSlider:P,setSelectedDeptForSlider:D,departments:Ue,sliders:me,handleSliderUpload:sa,updateSliderImage:jt,del:ae}),a==="Academic"&&e.jsx(bi,{programs:se,academicContent:ja,setAcademicContent:Fe,axiosInstance:j,notify:B,openModal:te,setProgramForm:Te,del:ae}),a==="Testimonials"&&e.jsx(fi,{testimonials:we,testimonialForm:Le,setTestimonialForm:He,openModal:te,del:ae}),a==="About Us"&&e.jsx(ji,{aboutSub:n,setAboutSub:d,collegeLogo:wa,setCollegeLogo:Pe,logoFile:dt,setLogoFile:ct,deanMessage:va,setDeanMessage:Be,deanPhotoFile:lt,setDeanPhotoFile:ot,milestones:ya,milestoneForm:Re,setMilestoneForm:Me,openModal:te,setMilestones:ze,visionMission:ka,setVmForm:Ge,coreValues:Da,setCvForm:Oe,aboutImages:Na,setAboutImages:$e,aboutImageFiles:pt,setAboutImageFiles:xt,historyContent:Ca,setHistoryContent:_e,axiosInstance:j,notify:B,del:ae}),a==="Admission"&&e.jsx(yi,{admSub:o,setAdmSub:i,courses:Sa,openModal:te,setCourseForm:Ve,del:ae,admissionSteps:za,setStepForm:Ye,admissionRules:Pa,setRuleForm:We,bonds:_a,setBondForm:Je,guidelines:qa,setGuidelineForm:Qe}),a==="Departments"&&e.jsx(vi,{selectedDept:S,setSelectedDept:F,departments:Ue,deptForm:Xe,setDeptForm:Ze,deptSub:r,setDeptSub:u,deptFacultyForm:at,setDeptFacultyForm:tt,deptFacilityInput:it,setDeptFacilityInput:st,deptActivityInput:rt,setDeptActivityInput:nt,sliders:me,axiosInstance:j,fetchData:T,notify:B,openModal:te,del:ae,handleSliderUpload:sa}),a==="Gallery"&&e.jsx(Ni,{galleryImages:mt,galleryForm:Ke,setGalleryForm:Ie,openModal:te,del:ae}),a==="Institutes"&&e.jsx(Ci,{institutes:Ha,openModal:te,del:ae}),a==="Student Corner"&&e.jsx(xi,{sections:bt,openModal:te,setScForm:ia,del:ae}),a==="Contact Us"&&e.jsx(Ei,{contactSub:x,setContactSub:k,keyPersons:Ma,setKeyPersonForm:ea,contactDepartments:Oa,setContactDeptForm:aa,contactInfo:Ya,setContactInfo:qe,openModal:te,del:ae,notify:B,axiosInstance:j}),a==="Settings"&&e.jsxs("div",{className:"flex flex-col items-center justify-center py-32 text-center text-slate-400",children:[e.jsx(oa,{size:48,className:"mb-4 opacity-30"}),e.jsx("p",{className:"font-semibold",children:"Settings Console — feature coming soon"})]})]},a+(S?._id||""))})]})})]}),e.jsxs(ua,{show:O,onClose:H,title:ra.title,subtitle:ra.subtitle,children:[z==="program"&&e.jsx(ei,{editItem:N,programForm:Wa,setProgramForm:Te,closeModal:H,fetchData:T,notify:B}),z==="testimonial"&&e.jsx(ai,{editItem:N,testimonialForm:Le,setTestimonialForm:He,closeModal:H,fetchData:T,notify:B}),z==="milestone"&&e.jsx(ti,{editItem:N,milestoneForm:Re,setMilestoneForm:Me,closeModal:H,fetchData:T,notify:B}),z==="visionMission"&&e.jsx(ii,{editItem:N,vmForm:Ja,setVmForm:Ge,closeModal:H,fetchData:T,notify:B}),z==="coreValue"&&e.jsx(si,{editItem:N,cvForm:Qa,setCvForm:Oe,closeModal:H,fetchData:T,notify:B}),z==="course"&&e.jsx(ri,{editItem:N,courseForm:Xa,setCourseForm:Ve,closeModal:H,fetchData:T,notify:B}),z==="step"&&e.jsx(ni,{editItem:N,stepForm:Za,setStepForm:Ye,closeModal:H,fetchData:T,notify:B}),z==="rule"&&e.jsx(li,{editItem:N,ruleForm:Ka,setRuleForm:We,closeModal:H,fetchData:T,notify:B}),z==="bond"&&e.jsx(oi,{editItem:N,bondForm:Ia,setBondForm:Je,closeModal:H,fetchData:T,notify:B}),z==="guideline"&&e.jsx(di,{editItem:N,guidelineForm:et,setGuidelineForm:Qe,closeModal:H,fetchData:T,notify:B}),z==="department"&&e.jsx(ci,{editItem:N,deptForm:Xe,setDeptForm:Ze,closeModal:H,fetchData:T,notify:B}),z==="gallery"&&e.jsx(wi,{editItem:N,formState:Ke,setFormState:Ie,closeModal:H,fetchData:T,notify:B,axiosInstance:j}),z==="institute"&&e.jsx(ki,{editItem:N,closeModal:H,fetchData:T,notify:B}),z==="keyPerson"&&e.jsx(Ai,{editItem:N,keyPersonForm:ht,setKeyPersonForm:ea,closeModal:H,fetchData:T,notify:B,axiosInstance:j}),z==="contactDept"&&e.jsx(Di,{editItem:N,contactDeptForm:ut,setContactDeptForm:aa,closeModal:H,fetchData:T,notify:B,axiosInstance:j}),z==="studentCorner"&&e.jsx(pi,{editItem:N,scForm:ft,setScForm:ia,closeModal:H,fetchData:T,notify:B})]}),e.jsx(gi,{show:$,onClose:()=>K(!1),notify:B})]})};export{Bi as default};
