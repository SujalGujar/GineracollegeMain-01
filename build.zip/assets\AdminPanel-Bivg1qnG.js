import{c as ee,r as u,a as N,j as e,B as Ee,U as he,I as $e,b as De,d as ce,G as ge,P as Ft,A as fe,m as re,e as ya,M as zt,X as oe,u as Bt,E as Se,C as Pt,F as Ce,f as Ut,g as _e,h as va,i as $t,S as _t}from"./index-BzdoMeB3.js";import{K as Tt,C as Fe,E as Ue}from"./key-round-BE32iBiu.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qt=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],Lt=ee("arrow-left",qt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],de=ee("circle-check",Gt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rt=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],Z=ee("image",Rt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],we=ee("layers",Ot);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mt=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],Ht=ee("layout-dashboard",Mt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vt=[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]],Wt=ee("log-out",Vt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]],Q=ee("pen-line",Kt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yt=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],ke=ee("plus",Yt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const It=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],je=ee("save",It);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],Qt=ee("search",Jt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xt=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],fa=ee("settings",Xt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zt=[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]],wa=ee("sliders-vertical",Zt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ei=[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]],H=ee("trash-2",ei);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ai=[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]],se=ee("upload",ai),n={brand:"#6B3F1D",accent:"#E07B39",accentSoft:"#FDF0E6",surface:"#FFFFFF",bg:"#F4F1EE",panel:"#FBFAF8",border:"#E8E0D8",text:"#1A1208",muted:"#8A7A6A",danger:"#DC2626",dangerSoft:"#FEF2F2",success:"#16A34A",successSoft:"#F0FDF4"},K=t=>_e(t),Na=({children:t,color:a=n.accent})=>e.jsx("span",{style:{background:a+"20",color:a},className:"admin-pill text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",children:t}),M=({onClick:t,danger:a,children:r,className:l="",title:d})=>e.jsx("button",{onClick:t,type:"button",title:d,"aria-label":d,className:`admin-icon-btn p-2 rounded-lg transition-all hover:scale-105 active:scale-95 ${a?"is-danger bg-red-50 text-red-500 hover:bg-red-100":"bg-gray-100 text-gray-600 hover:bg-gray-200"} ${l}`,children:r}),ti=({note:t,onDismiss:a})=>e.jsx(fe,{children:t&&e.jsxs(re.div,{role:"status","aria-live":"polite",initial:{opacity:0,y:-18,scale:.97},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-18,scale:.97},transition:{type:"spring",stiffness:420,damping:28},className:"mx-4 mt-4 flex max-w-2xl items-center gap-3 rounded-2xl border p-3 shadow-lg md:mx-6 lg:mx-8",style:{background:"#FFFFFF",borderColor:t.type==="error"?"#FECACA":"#BBF7D0",boxShadow:"0 18px 40px rgba(26, 18, 8, 0.18)"},children:[e.jsx("div",{className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",style:{background:t.type==="error"?n.dangerSoft:n.successSoft,color:t.type==="error"?n.danger:n.success},children:t.type==="error"?e.jsx(Fe,{size:21}):e.jsx(de,{size:21})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-[0.12em]",style:{color:t.type==="error"?n.danger:n.success},children:t.type==="error"?"Action needs attention":"Saved successfully"}),e.jsx("p",{className:"mt-0.5 break-words text-sm font-semibold leading-snug",style:{color:n.text},children:t.message})]}),e.jsx("button",{onClick:a,type:"button","aria-label":"Dismiss notification",className:"shrink-0 rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700",children:e.jsx(oe,{size:17})})]})}),x=({label:t,hint:a,required:r,children:l})=>e.jsxs("div",{className:"admin-field flex flex-col gap-1.5",children:[e.jsxs("div",{className:"admin-field-label flex items-center gap-1.5",children:[e.jsx("label",{className:"text-[13px] font-bold tracking-wide",style:{color:n.text},children:t}),r&&e.jsx("span",{className:"text-red-500 text-xs font-bold",children:"*"})]}),a&&e.jsx("p",{className:"text-[11px] leading-relaxed",style:{color:n.muted},children:a}),l]}),Ne=({title:t,children:a})=>e.jsxs("div",{className:"space-y-4",children:[t&&e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"h-px flex-1",style:{background:n.border}}),e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.18em]",style:{color:n.muted},children:t}),e.jsx("div",{className:"h-px flex-1",style:{background:n.border}})]}),a]}),q="w-full px-4 py-3 rounded-xl border-2 bg-white text-sm text-gray-800 outline-none transition-all placeholder:text-gray-400",L={borderColor:"#E8E4DF"},Te="w-full py-3.5 rounded-xl text-sm font-bold text-white tracking-wide shadow-lg hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2",qe="flex-1 py-3.5 rounded-xl border-2 text-sm font-semibold text-gray-600 bg-white hover:bg-gray-50 transition-all",y=({className:t="",style:a={},...r})=>e.jsx("input",{...r,className:`${q} ${t} focus:border-amber-500 focus:ring-0`,style:{...L,...a}}),R=({className:t="",style:a={},...r})=>e.jsx("textarea",{...r,className:`${q} resize-none ${t} focus:border-amber-500 focus:ring-0`,style:{...L,...a}}),xe=({className:t="",style:a={},...r})=>e.jsx("select",{...r,className:`${q} ${t} focus:border-amber-500 focus:ring-0 cursor-pointer`,style:{...L,...a}}),Ca=({show:t,onClose:a,title:r,subtitle:l,children:d})=>(u.useEffect(()=>{if(t){const o=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=o}}},[t]),typeof document>"u"?null:ya.createPortal(e.jsx(fe,{children:t&&e.jsxs("div",{className:"admin-modal-overlay fixed inset-0 flex items-center justify-center p-3 sm:p-5",style:{fontFamily:"'DM Sans', sans-serif",zIndex:9999},children:[e.jsx("style",{children:`
            .form-scroll-container::-webkit-scrollbar {
              width: 8px !important;
              display: block !important;
            }
            .form-scroll-container::-webkit-scrollbar-track {
              background: #F0ECE7 !important;
              border-radius: 8px !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb {
              background: #6B3F1D !important;
              border-radius: 8px !important;
              border: 2px solid #F0ECE7 !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb:hover {
              background: #4A2B14 !important;
            }
            .form-scroll-container {
              overflow-y: auto !important;
              scrollbar-width: thin !important;
              scrollbar-color: #6B3F1D #F0ECE7 !important;
              -webkit-overflow-scrolling: touch;
              overscroll-behavior: contain;
              min-height: 0;
            }
            .admin-modal-overlay {
              position: fixed !important;
              inset: 0 !important;
              width: 100vw !important;
              height: 100vh !important;
              height: 100dvh !important;
              display: flex !important;
              align-items: center !important;
              justify-content: center !important;
              overflow-y: auto !important;
              -webkit-overflow-scrolling: touch !important;
              padding: clamp(14px, 2.5vh, 28px) clamp(12px, 2vw, 24px) !important;
            }
            .admin-modal-card {
              margin: auto !important;
              width: min(720px, calc(100vw - 32px)) !important;
              max-height: calc(100dvh - 36px) !important;
              height: auto !important;
              border-radius: 18px !important;
              box-shadow: 0 30px 80px rgba(26, 18, 8, 0.32) !important;
              display: flex !important;
              flex-direction: column !important;
              flex-shrink: 0 !important;
              position: relative !important;
            }
            .admin-modal-header {
              padding: 20px 24px !important;
              min-height: 72px;
              gap: 18px;
            }
            .admin-modal-header h3,
            .admin-modal-header p {
              margin: 0;
            }
            .admin-modal-header h3 {
              font-size: 18px !important;
              line-height: 1.2 !important;
            }
            .admin-modal-header p {
              margin-top: 6px !important;
              line-height: 1.35 !important;
            }
            .admin-modal-body {
              padding: 24px !important;
              max-height: calc(100dvh - 120px) !important;
              background: #FAFAF9 !important;
              min-height: 0;
            }
            .admin-modal-body form .grid {
              display: grid !important;
              grid-template-columns: minmax(0, 1fr) !important;
              gap: 16px !important;
            }
            .admin-modal-body form {
              display: flex;
              flex-direction: column;
              gap: 22px;
            }
            .admin-modal-body form > * {
              margin-top: 0 !important;
              margin-bottom: 0 !important;
            }
            .admin-field {
              gap: 9px !important;
              min-width: 0;
            }
            .admin-field-label {
              min-height: 20px;
              align-items: center;
            }
            .admin-field-label label {
              line-height: 1.35 !important;
            }
            .admin-modal-body input,
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body label {
              max-width: 100%;
            }
            .admin-modal-body input:not([type="file"]):not([type="checkbox"]):not([type="radio"]),
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body .admin-field > label {
              min-height: 46px;
            }
            .admin-modal-body input[type="file"] {
              display: none !important;
              height: 0 !important;
              width: 0 !important;
              opacity: 0 !important;
              position: absolute !important;
            }
            .admin-form-actions {
              position: sticky;
              bottom: -24px;
              z-index: 2;
              background: linear-gradient(180deg, rgba(250,250,249,0.88), #FAFAF9 35%);
              padding-top: 18px !important;
              padding-bottom: 2px;
            }
            .admin-form-actions button {
              min-height: 46px;
            }
            @media (min-width: 760px) {
              .admin-modal-body form .grid {
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
              }
              .admin-modal-body form .grid-cols-1 {
                grid-template-columns: minmax(0, 1fr) !important;
              }
            }
            @media (min-width: 1024px) {
              .admin-modal-overlay {
                padding: 28px !important;
              }
            }
            @media (max-width: 640px) {
              .admin-modal-card {
                border-radius: 14px !important;
                width: calc(100vw - 24px) !important;
                max-height: calc(100dvh - 24px) !important;
              }
              .admin-modal-header {
                padding: 16px !important;
                min-height: auto;
              }
              .admin-modal-body {
                padding: 16px !important;
                max-height: calc(100dvh - 88px) !important;
              }
              .admin-form-actions {
                flex-direction: column;
                bottom: -16px;
              }
              .admin-form-actions button {
                width: 100%;
                min-width: 0 !important;
              }
            }
          `}),e.jsx(re.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:a,className:"fixed inset-0 bg-black/60 backdrop-blur-[3px]",style:{zIndex:0}}),e.jsxs(re.div,{initial:{opacity:0,scale:.94,y:-20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.94,y:-20},transition:{duration:.22,ease:[.16,1,.3,1]},className:"admin-modal-card relative w-full rounded-2xl shadow-2xl overflow-hidden flex flex-col",style:{background:"#fff",zIndex:1,width:"min(720px, calc(100vw - 32px))",maxWidth:"720px",maxHeight:"calc(100dvh - 32px)",height:"auto",minHeight:0},children:[e.jsxs("div",{className:"admin-modal-header flex items-start justify-between px-7 py-5 border-b shrink-0",style:{borderColor:"#EDE9E4",background:"linear-gradient(135deg, #6B3F1D 0%, #8B5E3C 100%)"},children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-[17px] font-bold text-white leading-tight",children:r}),l&&e.jsx("p",{className:"text-sm mt-1 text-white/70",children:l})]}),e.jsx("button",{type:"button",onClick:a,className:"p-2 rounded-xl border border-white/20 hover:bg-white/10 transition shrink-0 ml-4 mt-0.5",children:e.jsx(oe,{size:18,className:"text-white"})})]}),e.jsx("div",{className:"admin-modal-body px-6 sm:px-7 py-6 overflow-y-auto form-scroll-container flex-1",style:{background:"#FAFAF9",minHeight:0},children:d})]})]})}),document.body)),ka="flex items-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed bg-white cursor-pointer hover:bg-amber-50 hover:border-amber-400 transition-all text-sm font-medium",J=({onCancel:t,submitLabel:a="Save Changes"})=>e.jsxs("div",{className:"admin-form-actions flex flex-col-reverse gap-3 pt-5 mt-2 border-t sm:flex-row sm:items-center sm:justify-end",style:{borderColor:"#EDE9E4"},children:[e.jsx("button",{type:"button",onClick:t,className:`${qe} w-full sm:w-auto`,style:{borderColor:"#D1C7BC",minWidth:"120px"},children:"Cancel"}),e.jsxs("button",{type:"submit",className:`${Te} w-full sm:w-auto sm:min-w-[180px]`,style:{background:"linear-gradient(135deg, #6B3F1D 0%, #9B6A43 100%)",justifyContent:"center"},children:[e.jsx(je,{size:16}),a]})]}),ii=({editItem:t,programForm:a,setProgramForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a cover image","error");const s=new FormData;s.append("title",a.title||""),s.append("description",a.description||""),s.append("duration",a.duration||""),s.append("category",a.category||"Undergraduate"),s.append("courses",JSON.stringify(typeof a.courses=="string"?a.courses.split(",").map(m=>m.trim()).filter(Boolean):a.courses||[])),a.image instanceof File&&s.append("image",a.image);const b=t?`/programs/${t._id}`:"/programs";try{t?await N.put(b,s):await N.post(b,s),o(t?"Updated":"Created"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Program Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})}),e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate"}),e.jsx("option",{children:"Postgraduate"}),e.jsx("option",{children:"Diploma"})]})})]}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(R,{required:!0,rows:3,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Describe the program objectives, curriculum overview…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Duration",children:e.jsx(y,{value:a.duration,onChange:i=>r({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsxs(x,{label:"Cover Image",children:[e.jsxs("label",{className:ka,style:{color:"#6B7280"},children:[e.jsx(Z,{size:16,style:{color:n.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose image file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>r({...a,image:i.target.files[0]})})]}),a.image instanceof File?e.jsx("img",{src:URL.createObjectURL(a.image),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"preview"}):t?.imageUrl?e.jsx("img",{src:K(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"current"}):null]})]}),e.jsx(x,{label:"Courses (comma separated)",hint:"e.g.  Anatomy, Physiology, Microbiology",children:e.jsx(R,{rows:2,value:a.courses,onChange:i=>r({...a,courses:i.target.value})})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Create Program"})]}),si=({editItem:t,testimonialForm:a,setTestimonialForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a photo","error");const s=new FormData;Object.entries(a).forEach(([m,k])=>{m==="image"&&k instanceof File?s.append("image",k):m!=="image"&&s.append(m,k)});const b=t?`/testimonials/${t._id}`:"/testimonials";try{t?await N.put(b,s):await N.post(b,s),o(t?"Updated":"Created"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Student Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"Full name"})}),e.jsx(x,{label:"Role / Batch",required:!0,children:e.jsx(y,{required:!0,value:a.role,onChange:i=>r({...a,role:i.target.value}),placeholder:"e.g. B.Sc. Nursing 2023"})})]}),e.jsx(x,{label:"Testimonial",required:!0,children:e.jsx(R,{required:!0,rows:4,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Student's review about the college…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Rating (1–5)",children:e.jsx(y,{type:"number",min:1,max:5,value:a.rating,onChange:i=>r({...a,rating:parseInt(i.target.value)})})}),e.jsx(x,{label:"Student Photo",children:e.jsxs("label",{className:ka,style:{color:"#6B7280"},children:[e.jsx(Z,{size:16,style:{color:n.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose photo file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>r({...a,image:i.target.files[0]})})]})})]}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Testimonial"})]}),ri=({editItem:t,milestoneForm:a,setMilestoneForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/milestones/${t._id}`:"/about/milestones";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[e.jsx(x,{label:"Year",required:!0,children:e.jsx(y,{required:!0,value:a.year,onChange:i=>r({...a,year:i.target.value}),placeholder:"1963"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",min:"0",step:"1",value:a.order,onChange:i=>r({...a,order:Math.max(0,parseInt(i.target.value,10)||0)})})})]}),e.jsx(x,{label:"Event Title",required:!0,children:e.jsx(y,{required:!0,value:a.event,onChange:i=>r({...a,event:i.target.value}),placeholder:"e.g. College Established"})}),e.jsx(x,{label:"Accent Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:i=>r({...a,color:i.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.color,onChange:i=>r({...a,color:i.target.value})})]})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(R,{required:!0,rows:3,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of this milestone…"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Milestone"})]}),ni=({editItem:t,vmForm:a,setVmForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/vision-mission/${t._id}`:"/about/vision-mission";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Statement Type",children:e.jsxs(xe,{value:a.type,onChange:i=>r({...a,type:i.target.value}),children:[e.jsx("option",{value:"vision",children:"🔭 Vision"}),e.jsx("option",{value:"mission",children:"🎯 Mission"})]})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",value:a.order||0,onChange:i=>r({...a,order:parseInt(i.target.value)||0})})})]}),e.jsx(x,{label:"Content",required:!0,children:e.jsx(R,{required:!0,rows:5,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Enter the statement content…"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Statement"})]}),li=({editItem:t,cvForm:a,setCvForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/core-values/${t._id}`:"/about/core-values";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Value Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Excellence"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})})]}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(R,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of this value…"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Core Value"})]}),oi=({editItem:t,courseForm:a,setCourseForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/courses/${t._id}`:"/courses",b={...a,highlights:typeof a.highlights=="string"?a.highlights.split(",").map(m=>m.trim()).filter(Boolean):a.highlights};try{t?await N.put(s,b):await N.post(s,b),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx("div",{className:"sm:col-span-2",children:e.jsx(x,{label:"Course Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})})}),e.jsx(x,{label:"Icon",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate Programs"}),e.jsx("option",{children:"Postgraduate Programs"}),e.jsx("option",{children:"Diploma Programs"})]})}),e.jsx(x,{label:"Duration",children:e.jsx(y,{value:a.duration,onChange:i=>r({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsx(x,{label:"Seats",children:e.jsx(y,{value:a.seats,onChange:i=>r({...a,seats:i.target.value}),placeholder:"e.g. 60"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Annual Fees",children:e.jsx(y,{value:a.fees,onChange:i=>r({...a,fees:i.target.value}),placeholder:"e.g. ₹50,000"})}),e.jsx(x,{label:"Official Website Link",children:e.jsx(y,{value:a.websiteLink,onChange:i=>r({...a,websiteLink:i.target.value}),placeholder:"https://…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Brief Description",children:e.jsx(R,{rows:3,value:a.description||"",onChange:i=>r({...a,description:i.target.value}),placeholder:"Short overview of the course…"})}),e.jsx(x,{label:"Eligibility",children:e.jsx(R,{rows:3,value:a.eligibility,onChange:i=>r({...a,eligibility:i.target.value}),placeholder:"Who can apply…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Highlights",hint:"Comma separated",children:e.jsx(R,{rows:2,value:a.highlights,onChange:i=>r({...a,highlights:i.target.value})})}),e.jsx(x,{label:"Admission Method",children:e.jsx(R,{rows:2,value:a.admission||"",onChange:i=>r({...a,admission:i.target.value})})})]}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Course"})]}),di=({editItem:t,stepForm:a,setStepForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/admission-steps/${t._id}`:"/admission-steps";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Step Number",required:!0,children:e.jsx(y,{type:"number",required:!0,value:a.step,onChange:i=>r({...a,step:parseInt(i.target.value)})})}),e.jsx(x,{label:"Icon",children:e.jsx(xe,{value:a.icon,onChange:i=>r({...a,icon:i.target.value}),children:["Calendar","Users","CheckCircle","GraduationCap","FileText","Download"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(x,{label:"Step Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Submit Application Form"})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(R,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Explain what the applicant needs to do in this step…"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Step"})]}),ci=({editItem:t,ruleForm:a,setRuleForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/admission-rules/${t._id}`:"/admission-rules";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"UnderGraduated Programs"}),e.jsx("option",{children:"PostGraduated Programs"}),e.jsx("option",{children:"General Rules"})]})}),e.jsx(x,{label:"Icon",children:e.jsx(xe,{value:a.icon,onChange:i=>r({...a,icon:i.target.value}),children:["CheckCircle","Calendar","Stethoscope","GraduationCap","Info"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(x,{label:"Rule Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Minimum Percentage Required"})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(R,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Full explanation of this rule…"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Rule"})]}),pi=({editItem:t,bondForm:a,setBondForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/bonds/${t._id}`:"/bonds";try{t?await N.put(s,a):await N.post(s,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsx(x,{label:"Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Government Bond Agreement"})}),e.jsx(x,{label:"Content",required:!0,children:e.jsx(R,{required:!0,rows:5,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Bond details and conditions…"})}),e.jsx(x,{label:"Display Order",children:e.jsx(y,{type:"number",value:a.order,onChange:i=>r({...a,order:parseInt(i.target.value)||0})})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Bond"})]}),xi=({editItem:t,guidelineForm:a,setGuidelineForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s={...a,points:typeof a.points=="string"?a.points.split(`
`).map(m=>m.trim()).filter(Boolean):a.points},b=t?`/guidelines/${t._id}`:"/guidelines";try{t?await N.put(b,s):await N.post(b,s),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsx(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(i=>e.jsx("option",{children:i},i))})}),e.jsx(x,{label:"Sub-Category / Title",required:!0,children:e.jsx(y,{required:!0,value:a.subCategory,onChange:i=>r({...a,subCategory:i.target.value}),placeholder:"e.g. Dress Code Policy"})})]}),e.jsx(x,{label:"Points",hint:"Enter one point per line — each line becomes a separate bullet",children:e.jsx(R,{required:!0,rows:7,value:a.points,onChange:i=>r({...a,points:i.target.value}),placeholder:`Guideline point 1
Guideline point 2
Guideline point 3`})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Guideline"})]}),mi=({editItem:t,deptForm:a,setDeptForm:r,closeModal:l,fetchData:d,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=new FormData;s.append("name",a.name||""),s.append("slug",a.slug||""),s.append("category",a.category||"Nursing Department"),s.append("description",a.description||""),a.logo instanceof File&&s.append("logo",a.logo);const b=t?`/departments/${t._id}`:"/departments";try{t?await N.put(b,s):await N.post(b,s),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"flex flex-col items-center gap-3 py-5 px-6 rounded-2xl border-2 border-dashed",style:{borderColor:"#D1C7BC",background:"#FDFCFB"},children:[a.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(a.logo),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"preview"}):t?.logoUrl?e.jsx("img",{src:K(t.logoUrl),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"logo"}):e.jsx("div",{className:"w-20 h-20 rounded-2xl flex items-center justify-center text-4xl",style:{background:n.accentSoft},children:"🏥"}),e.jsxs("label",{className:"flex items-center gap-2 px-5 py-2.5 rounded-xl cursor-pointer text-sm font-semibold text-white shadow hover:opacity-90 transition-all",style:{background:n.brand},children:[e.jsx(se,{size:15}),a.logo instanceof File?"Change Logo":t?.logoUrl?"Replace Logo":"Upload Department Logo",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:i=>r({...a,logo:i.target.files[0]})})]}),e.jsx("p",{className:"text-xs",style:{color:n.muted},children:"PNG, JPG or WEBP · Recommended 200×200px"})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Department Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"e.g. Fundamentals of Nursing"})}),e.jsx(x,{label:"URL Slug",hint:"Unique ID — no spaces",children:e.jsx(y,{required:!0,value:a.slug,onChange:i=>r({...a,slug:i.target.value.toLowerCase().replace(/\s+/g,"-")}),placeholder:"e.g. fundamentals"})})]}),e.jsx(x,{label:"Category",children:e.jsx(y,{required:!0,value:a.category,onChange:i=>r({...a,category:i.target.value}),placeholder:"e.g. Nursing Department"})}),e.jsx(x,{label:"Short Description",children:e.jsx(y,{value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of the department"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Update Department":"Create Department"})]}),gi=({editItem:t,scForm:a,setScForm:r,closeModal:l,fetchData:d,notify:o})=>{const i=()=>r(m=>({...m,items:[...m.items||[],""]})),s=m=>r(k=>({...k,items:k.items.filter((h,f)=>f!==m)})),b=(m,k)=>r(h=>{const f=[...h.items||[]];return f[m]=k,{...h,items:f}});return e.jsxs("form",{onSubmit:async m=>{m.preventDefault();const k=t?`/student-corner/${t._id}`:"/student-corner";try{t?await N.put(k,a):await N.post(k,a),o(t?"Section updated":"Section created"),l(),d()}catch{o("Failed to save section","error")}},className:"space-y-5",children:[e.jsxs(Ne,{title:"Section Details",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Section Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:m=>r({...a,title:m.target.value}),placeholder:"e.g. Documents for Transcript"})}),e.jsx(x,{label:"Subtitle",children:e.jsx(y,{value:a.subtitle,onChange:m=>r({...a,subtitle:m.target.value}),placeholder:"e.g. All Xerox Copies Required"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Tag / Badge Label",children:e.jsx(y,{value:a.tag,onChange:m=>r({...a,tag:m.target.value}),placeholder:"e.g. GNM Students"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:m=>r({...a,icon:m.target.value}),placeholder:"📄"})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",value:a.order,onChange:m=>r({...a,order:parseInt(m.target.value)||0})})})]}),e.jsx(x,{label:"Extra Description / Note",hint:"Optional note shown below the badge on the public page",children:e.jsx(R,{rows:2,value:a.description,onChange:m=>r({...a,description:m.target.value}),placeholder:"e.g. For GNM students completing their final year only"})})]}),e.jsx(Ne,{title:"Colors",children:e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Main Color",hint:"Card accent & icon background",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:m=>r({...a,color:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.color,onChange:m=>r({...a,color:m.target.value})})]})}),e.jsx(x,{label:"Border Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.borderColor,onChange:m=>r({...a,borderColor:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.borderColor,onChange:m=>r({...a,borderColor:m.target.value})})]})}),e.jsx(x,{label:"Badge Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.badgeColor,onChange:m=>r({...a,badgeColor:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.badgeColor,onChange:m=>r({...a,badgeColor:m.target.value})})]})})]})}),e.jsx(Ne,{title:"Document Items",children:e.jsxs("div",{className:"space-y-2",children:[(a.items||[]).map((m,k)=>e.jsxs("div",{className:"flex gap-2 items-center",children:[e.jsx("span",{className:"w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0",style:{background:a.color||"#F59E0B"},children:k+1}),e.jsx(y,{value:m,onChange:h=>b(k,h.target.value),placeholder:`Document item ${k+1}`,className:"flex-1"}),e.jsx("button",{type:"button",onClick:()=>s(k),className:"p-2 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition-all shrink-0",children:e.jsx(H,{size:15})})]},k)),e.jsxs("button",{type:"button",onClick:i,className:"w-full py-2.5 rounded-xl border-2 border-dashed text-sm font-semibold transition-all hover:bg-amber-50",style:{borderColor:"#D1C7BC",color:"#8A7A6A"},children:[e.jsx(ke,{size:15,className:"inline mr-1"})," Add Document Item"]})]})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Create Section"})]})},hi=({sections:t,openModal:a,setScForm:r,del:l})=>{const d={title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0};return e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:ge,title:"Student Corner — Document Sections",subtitle:"Manage document requirement notices shown on the Student Corner page",action:e.jsx(X,{label:"Add Section",onClick:()=>{r({...d,order:t.length+1}),a("studentCorner")}})}),t.length===0?e.jsx(me,{icon:ge,text:"No document sections yet — click 'Add Section' to create one"}):e.jsx("div",{className:"space-y-3",children:t.map((o,i)=>e.jsxs("div",{className:"flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:"#FFFFFF",border:"1px solid #E8E0D8"},children:[e.jsx("div",{style:{width:"48px",height:"48px",borderRadius:"14px",background:o.color||"#F59E0B",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"22px",flexShrink:0,boxShadow:`0 4px 12px ${o.color||"#F59E0B"}44`},children:o.icon||"📄"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap mb-0.5",children:[o.tag&&e.jsx("span",{className:"text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",style:{background:(o.badgeColor||"#D97706")+"22",color:o.badgeColor||"#D97706"},children:o.tag}),e.jsxs("span",{className:"text-[11px] font-semibold text-gray-400",children:["#",i+1," · ",(o.items||[]).length," items"]})]}),e.jsx("p",{className:"font-bold text-sm truncate",style:{color:"#1A1208"},children:o.title}),o.subtitle&&e.jsx("p",{className:"text-xs truncate mt-0.5",style:{color:"#8A7A6A"},children:o.subtitle})]}),e.jsx("div",{className:"hidden sm:flex gap-1.5 shrink-0",children:["color","borderColor","badgeColor"].map(s=>e.jsx("div",{style:{width:16,height:16,borderRadius:"50%",background:o[s]||"#ccc",border:"2px solid #F4F1EE"},title:s},s))}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[e.jsx(M,{title:"Edit",onClick:()=>{r({title:o.title||"",subtitle:o.subtitle||"",tag:o.tag||"",icon:o.icon||"📄",color:o.color||"#F59E0B",borderColor:o.borderColor||"#FCD34D",badgeColor:o.badgeColor||"#D97706",items:Array.isArray(o.items)?[...o.items]:[],description:o.description||"",order:o.order||0}),a("studentCorner",o)},children:e.jsx(Q,{size:15})}),e.jsx(M,{danger:!0,title:"Delete",onClick:()=>l(`/student-corner/${o._id}`),children:e.jsx(H,{size:15})})]})]},o._id))}),e.jsxs("div",{className:"p-4 rounded-2xl flex items-start gap-3",style:{background:"#FFF7ED",border:"1.5px solid #FDE68A"},children:[e.jsx("span",{className:"text-xl shrink-0",children:"💡"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-bold",style:{color:"#92400e"},children:"Tips"}),e.jsxs("ul",{className:"text-xs mt-1 space-y-1",style:{color:"#78350f"},children:[e.jsxs("li",{children:["• Use ",e.jsx("strong",{children:"Sort Order"})," when editing to control display order on the public page."]}),e.jsxs("li",{children:["• To hide Student Corner from the site, go to ",e.jsx("strong",{children:"Section Control"})," and toggle it off."]}),e.jsx("li",{children:"• Each section supports its own emoji icon, custom colors, badge label, and unlimited document items."})]})]})]})]})},ui=({editItem:t,announcementForm:a,setAnnouncementForm:r,closeModal:l,fetchData:d,notify:o})=>{const[i,s]=u.useState(!1),[b,m]=u.useState(""),k=f=>{const C=f.target.files?.[0];if(!C)return;if(m(""),!(C.type==="application/pdf"||C.name.toLowerCase().endsWith(".pdf"))){m("Only PDF files (.pdf) are allowed."),f.target.value="";return}if(C.size>500*1024){m(`File size is ${(C.size/1024).toFixed(1)} KB. Maximum allowed is 500 KB.`),f.target.value="";return}r(D=>({...D,pdf:C,formName:C.name,formSize:C.size,removeFile:!1}))},h=async f=>{if(f.preventDefault(),b)return;s(!0);const C=new FormData;C.append("title",a.title||""),C.append("subtitle",a.subtitle||""),C.append("badge",a.badge||""),C.append("description",a.description||"");const F=typeof a.points=="string"?a.points.split(`
`).map(D=>D.trim()).filter(Boolean):a.points||[];C.append("points",JSON.stringify(F)),C.append("isActive",a.isActive!==!1?"true":"false"),C.append("order",a.order||0),a.pdf&&C.append("pdf",a.pdf),a.removeFile&&C.append("removeFile","true");try{t?await N.put(`/announcements/${t._id}`,C):await N.post("/announcements",C),o("Announcement saved successfully"),l(),d()}catch(D){const E=D.response?.data?.message||"Failed to save announcement";o(E,"error")}finally{s(!1)}};return e.jsxs("form",{onSubmit:h,className:"space-y-5",children:[e.jsx(x,{label:"Announcement Title",required:!0,hint:"Main heading displayed on the card",children:e.jsx(y,{required:!0,value:a.title||"",onChange:f=>r({...a,title:f.target.value}),placeholder:"e.g. Admission Announcements Will Be Available Soon"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Status Badge",hint:"Badge shown above title",children:e.jsx(y,{value:a.badge||"",onChange:f=>r({...a,badge:f.target.value}),placeholder:"e.g. Will Be Updated Soon, New Notice, Admission Open"})}),e.jsx(x,{label:"Sort Order",hint:"Order of display (0 = top)",children:e.jsx(y,{type:"number",value:a.order!==void 0?a.order:0,onChange:f=>r({...a,order:f.target.value})})})]}),e.jsx(x,{label:"Announcement Description",required:!0,hint:"Context text (Post Basic Diploma Course details)",children:e.jsx(R,{rows:3,required:!0,value:a.description||"",onChange:f=>r({...a,description:f.target.value}),placeholder:"The official admission notices, circulars, and application schedules for Post Basic Diploma Course in Nursing at Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad) will be published here."})}),e.jsx(x,{label:"Key Points / Bullet Points",hint:"Enter one bullet point per line",children:e.jsx(R,{rows:3,value:a.points||"",onChange:f=>r({...a,points:f.target.value}),placeholder:`Official admission notifications and merit lists will be published here as soon as released.
Post Basic Diploma Course in Nursing admissions are conducted for Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad).`})}),e.jsx(Ne,{title:"Downloadable Form (PDF Max 500 KB)",children:e.jsxs("div",{className:"p-5 rounded-2xl border-2 space-y-4",style:{background:"#FFFDF9",borderColor:"#F3E5D8"},children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center",children:e.jsx(Ce,{size:18})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-extrabold text-gray-900",children:"Application / Notice Form (PDF)"}),e.jsx("p",{className:"text-[11px] text-gray-500",children:'Strict limit: 500 KB. Once uploaded, a "Download Form" button automatically appears for students.'})]})]}),a.existingPdf&&!a.removeFile&&e.jsx("span",{className:"text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300",children:"PDF Active on Website"})]}),a.existingPdf&&!a.removeFile&&e.jsxs("div",{className:"p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0",children:[e.jsx("div",{className:"w-9 h-9 rounded-lg bg-red-100 text-red-600 flex items-center justify-center font-black text-xs shrink-0",children:"PDF"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs font-bold text-gray-900 truncate",children:a.formName||"attached-announcement-form.pdf"}),a.formSize>0&&e.jsxs("p",{className:"text-[11px] text-gray-500",children:["Size: ",(a.formSize/1024).toFixed(1)," KB · Currently visible on announcement page"]})]})]}),e.jsxs("div",{className:"flex items-center gap-2 shrink-0",children:[e.jsxs("a",{href:_e(a.existingPdf),target:"_blank",rel:"noopener noreferrer",className:"px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-amber-700 hover:bg-amber-50 text-xs font-bold shadow-xs cursor-pointer inline-flex items-center gap-1",children:[e.jsx(Ue,{size:13})," View PDF"]}),e.jsxs("button",{type:"button",onClick:()=>r(f=>({...f,removeFile:!0,pdf:null})),className:"px-3 py-1.5 rounded-lg bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 text-xs font-bold cursor-pointer inline-flex items-center gap-1",children:[e.jsx(H,{size:13})," Remove"]})]})]}),a.removeFile&&e.jsxs("div",{className:"p-3 rounded-xl bg-red-50 border border-red-200 flex items-center justify-between",children:[e.jsx("span",{className:"text-xs text-red-700 font-semibold",children:'⚠️ Current PDF marked for deletion upon clicking "Update Announcement".'}),e.jsx("button",{type:"button",onClick:()=>r(f=>({...f,removeFile:!1})),className:"text-xs text-gray-800 underline font-bold cursor-pointer px-2 py-1 hover:text-gray-950",children:"Undo (Keep PDF)"})]}),a.pdf&&e.jsxs("div",{className:"p-3.5 rounded-xl bg-emerald-50 border-2 border-emerald-300 flex items-center justify-between gap-3",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0",children:[e.jsx("div",{className:"w-9 h-9 rounded-lg bg-emerald-200 text-emerald-800 flex items-center justify-center font-black text-xs shrink-0",children:"NEW"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs font-extrabold text-emerald-950 truncate",children:a.pdf.name}),e.jsxs("p",{className:"text-[11px] text-emerald-700 font-medium",children:[(a.pdf.size/1024).toFixed(1)," KB · Ready to upload"]})]})]}),e.jsx("button",{type:"button",onClick:()=>r(f=>({...f,pdf:null})),className:"px-2.5 py-1 rounded-lg bg-white border border-emerald-300 text-emerald-800 text-xs font-bold cursor-pointer hover:bg-emerald-100",children:"Cancel"})]}),e.jsxs("div",{children:[e.jsxs("label",{htmlFor:"announcement-pdf-upload",className:"group flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-2xl transition-all cursor-pointer hover:border-amber-500 hover:bg-amber-50/50",style:{borderColor:a.pdf?"#10B981":"#D97706",background:a.pdf?"#F0FDF4":"#FFFBF5"},children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3 shadow-xs group-hover:scale-110 transition-transform",children:e.jsx(se,{size:22,className:"text-amber-700"})}),e.jsx("p",{className:"text-sm font-extrabold text-gray-900 text-center",children:a.pdf?"Click to choose a different PDF file":a.existingPdf&&!a.removeFile?"Click to Replace Current PDF Document":"Click or Drag & Drop PDF Form Here"}),e.jsxs("p",{className:"text-xs text-gray-500 mt-1 text-center",children:["Only PDF files (.pdf) up to ",e.jsx("strong",{className:"text-amber-800 font-bold",children:"500 KB"})," are accepted"]}),e.jsxs("span",{className:"mt-3.5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-md transition-all group-hover:opacity-95",style:{background:"linear-gradient(135deg, #B45309 0%, #D97706 100%)"},children:[e.jsx(Ce,{size:14}),e.jsx("span",{children:a.pdf?"Choose Another PDF":"Browse & Select PDF (Max 500 KB)"})]}),e.jsx("input",{id:"announcement-pdf-upload",type:"file",accept:".pdf,application/pdf",onChange:k,className:"hidden"})]}),b&&e.jsxs("div",{className:"mt-2.5 p-3 rounded-xl bg-red-50 border border-red-300 flex items-center gap-2 text-xs font-bold text-red-700",children:[e.jsx(Fe,{size:16,className:"shrink-0"}),e.jsx("span",{children:b})]})]})]})}),e.jsxs("div",{className:"admin-form-actions flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-3 pt-5 mt-2 border-t",style:{borderColor:"#EDE9E4"},children:[e.jsx("button",{type:"button",onClick:l,className:`${qe} w-full sm:w-auto`,style:{borderColor:"#D1C7BC",minWidth:"120px"},children:"Cancel"}),e.jsxs("button",{type:"submit",disabled:i,className:`${Te} w-full sm:w-auto sm:min-w-[190px]`,style:{background:"linear-gradient(135deg, #6B3F1D 0%, #9B6A43 100%)",justifyContent:"center"},children:[e.jsx(je,{size:16}),i?"Saving...":t?"Update Announcement":"Create Announcement"]})]})]})},ze=({tabs:t,active:a,onChange:r})=>e.jsx("div",{className:"admin-subtabs",children:t.map(l=>e.jsx("button",{onClick:()=>r(l),type:"button",className:a===l?"is-active":"",children:l},l))}),I=({icon:t,title:a,subtitle:r,action:l})=>e.jsxs("div",{className:"admin-section-header flex flex-col sm:flex-row sm:items-center gap-4 p-5 rounded-2xl",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0",children:[e.jsx("div",{className:"admin-section-icon w-10 h-10 rounded-xl flex items-center justify-center shrink-0",style:{background:n.accentSoft},children:e.jsx(t,{size:20,style:{color:n.accent}})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h3",{className:"admin-section-title font-bold text-base truncate",style:{color:n.text},children:a}),r&&e.jsx("p",{className:"admin-section-subtitle text-xs mt-0.5 truncate",style:{color:n.muted},children:r})]})]}),l]}),X=({onClick:t,label:a="Add New"})=>e.jsxs("button",{onClick:t,className:"admin-add-btn shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition-all shadow hover:opacity-90 active:scale-95",style:{background:n.brand},children:[e.jsx(ke,{size:16}),a]}),be=({icon:t,badge:a,title:r,sub:l,onEdit:d,onDelete:o,left:i})=>e.jsxs("div",{className:"admin-row-item flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[i||e.jsx("div",{className:"admin-row-icon w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0",style:{background:n.accentSoft},children:t||"📌"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[a&&e.jsx("div",{className:"mb-0.5",children:e.jsx(Na,{children:a})}),e.jsx("p",{className:"admin-row-title font-bold text-sm truncate",style:{color:n.text},children:r}),l&&e.jsx("p",{className:"admin-row-subtitle text-xs truncate mt-0.5",style:{color:n.muted},children:l})]}),e.jsxs("div",{className:"admin-row-actions flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[d&&e.jsx(M,{onClick:d,title:"Edit",children:e.jsx(Q,{size:15})}),o&&e.jsx(M,{onClick:o,danger:!0,title:"Delete",children:e.jsx(H,{size:15})})]})]}),me=({icon:t,text:a})=>e.jsxs("div",{className:"flex flex-col items-center justify-center py-20 rounded-3xl border-2 border-dashed shadow-inner",style:{borderColor:n.border,background:n.surface},children:[e.jsx(t,{size:48,style:{color:n.muted},className:"mb-4 opacity-10"}),e.jsx("p",{className:"text-sm font-bold tracking-tight",style:{color:n.muted},children:a})]}),ja=({onClose:t,activeTab:a,setActiveTab:r,selectedDept:l,setSelectedDept:d,navItems:o,onLogout:i})=>e.jsxs("div",{className:"flex flex-col min-h-0",style:{height:"100dvh",maxHeight:"100dvh"},children:[e.jsxs("div",{className:"flex items-center gap-3 p-6 border-b border-white/10 shrink-0",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shadow-inner",children:e.jsx(Ht,{size:20,className:"text-white"})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-white font-bold text-sm leading-tight truncate",children:"Ginera Admin"}),e.jsx("p",{className:"text-white/40 text-[10px] uppercase tracking-widest mt-0.5 font-medium",children:"Dashboard Console"})]}),t&&e.jsx("button",{onClick:t,className:"lg:hidden p-2 text-white/40 hover:text-white transition-colors",children:e.jsx(oe,{size:20})})]}),e.jsxs("nav",{className:"flex-1 min-h-0 overflow-y-auto py-6 px-4 space-y-1 scrollbar-hide",style:{overscrollBehavior:"contain"},children:[o.map(({name:s,icon:b})=>{const m=a===s&&!l;return e.jsxs("button",{onClick:()=>{r(s),d(null),t&&t()},className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all group",style:{background:m?"rgba(255,255,255,0.12)":"transparent",color:m?"#fff":"rgba(255,255,255,0.55)"},children:[e.jsx(b,{size:18,className:`transition-transform ${m?"scale-110":"group-hover:scale-110"}`}),e.jsx("span",{className:"truncate",children:s}),m&&e.jsx(va,{size:14,className:"ml-auto opacity-60"})]},s)}),l&&e.jsxs("div",{className:"mt-8 pt-6 border-t border-white/5 px-2",children:[e.jsx("p",{className:"text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-3 px-2",children:"Active Editor"}),e.jsxs("div",{className:"p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx("div",{className:"w-2 h-2 rounded-full bg-amber-400 animate-pulse"}),e.jsx("p",{className:"text-white text-xs font-bold truncate",children:l.name})]}),e.jsx("button",{onClick:()=>d(null),className:"w-full py-2.5 rounded-lg bg-white/10 text-[10px] font-bold text-white/70 hover:bg-white/20 transition-all border border-white/5 uppercase tracking-wider",children:"Exit Management"})]})]})]}),e.jsx("div",{className:"p-5 border-t border-white/10 shrink-0",children:e.jsxs("button",{onClick:i,className:"w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold text-red-300 hover:bg-red-500/20 transition-all active:scale-95",children:[e.jsx(Wt,{size:18})," Sign Out"]})})]}),bi=({isMobile:t,sidebarOpen:a,setSidebarOpen:r,...l})=>e.jsxs(e.Fragment,{children:[!t&&e.jsx("aside",{className:"admin-sidebar flex flex-col w-80 shrink-0 self-stretch border-r border-black/10",style:{background:n.brand,width:"320px",height:"100%",minHeight:"100dvh",maxHeight:"100dvh"},children:e.jsx(ja,{onClose:null,...l})}),t&&typeof document<"u"&&ya.createPortal(e.jsx(fe,{children:a&&e.jsxs(e.Fragment,{children:[e.jsx(re.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>r(!1),className:"fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm",style:{position:"fixed",top:0,right:0,bottom:0,left:0}}),e.jsx(re.aside,{initial:{x:-340},animate:{x:0},exit:{x:-340},transition:{type:"tween",duration:.3},className:"admin-sidebar fixed inset-y-0 left-0 z-[10000] w-80 flex flex-col shadow-2xl",style:{background:n.brand,position:"fixed",top:0,bottom:0,left:0,width:"min(320px, 86vw)",height:"100dvh",maxHeight:"100dvh",zIndex:1e4},children:e.jsx(ja,{onClose:()=>r(!1),...l})})]})}),document.body)]}),fi=({show:t,onClose:a,notify:r})=>{const[l,d]=u.useState(""),[o,i]=u.useState(""),[s,b]=u.useState(!1),[m,k]=u.useState(!1),[h,f]=u.useState(""),C=l.length>8,F=/[!@#$%^&*(),.?":{}|<>_\-+=\\/[\]~`]/.test(l),D=l.length>0&&l===o,E=C&&F&&D,$=()=>{d(""),i(""),b(!1),k(!1),f(""),a()},V=z=>{if(z.preventDefault(),!C){f("New password must be greater than 8 characters (at least 9 characters).");return}if(!F){f("New password must contain at least one unique special character (e.g., @, #, $, %, !).");return}if(l!==o){f("Passwords do not match. Please ensure both fields are identical.");return}localStorage.setItem("adminPassword",l),r("Admin password successfully updated!"),$()};return e.jsx(Ca,{show:t,onClose:$,title:"Reset Admin Password",subtitle:"Update credentials to maintain secure administrative access",children:e.jsxs("form",{onSubmit:V,className:"space-y-4",children:[h&&e.jsxs("div",{className:"flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-semibold",children:[e.jsx(Fe,{size:16,className:"shrink-0"}),e.jsx("span",{children:h})]}),e.jsx(x,{label:"New Password",required:!0,hint:"Must be greater than 8 characters with at least one unique special character",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:s?"text":"password",value:l,onChange:z=>{d(z.target.value),h&&f("")},placeholder:"Enter new strong password",className:q,style:{...L,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>b(z=>!z),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:s?"Hide password":"Show password",children:s?e.jsx(Se,{size:18}):e.jsx(Ue,{size:18})})]})}),e.jsx(x,{label:"Confirm New Password",required:!0,hint:"Re-enter the exact same new password",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:m?"text":"password",value:o,onChange:z=>{i(z.target.value),h&&f("")},placeholder:"Re-enter new password",className:q,style:{...L,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>k(z=>!z),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:m?"Hide password":"Show password",children:m?e.jsx(Se,{size:18}):e.jsx(Ue,{size:18})})]})}),e.jsxs("div",{className:"p-3.5 rounded-xl border bg-amber-50/40 border-amber-200/60 space-y-2 text-xs",children:[e.jsx("p",{className:"font-bold text-gray-700 uppercase tracking-wider text-[11px]",children:"Password Security Requirements:"}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${C?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:C?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Greater than 8 characters (at least 9 characters long)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${F?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:F?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"At least 1 unique/special character (e.g. @, #, $, %, !, &, *)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${D?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:D?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Passwords match in both fields"})]})]}),e.jsxs("div",{className:"admin-form-actions flex gap-3 pt-3",children:[e.jsx("button",{type:"button",onClick:$,className:qe,children:"Cancel"}),e.jsxs("button",{type:"submit",disabled:!E,className:Te,style:{background:E?n.brand:"#B5ACA2",cursor:E?"pointer":"not-allowed"},children:[e.jsx(_t,{size:18}),"Reset Password"]})]})]})})},ji=({setSidebarOpen:t,selectedDept:a,activeTab:r,onOpenResetPassword:l})=>e.jsxs("header",{className:"admin-header h-14 lg:h-16 flex items-center px-4 lg:px-6 border-b shrink-0 z-10",style:{background:n.surface,borderColor:n.border},children:[e.jsx("button",{onClick:()=>t(!0),className:"p-2 rounded-xl hover:bg-gray-100 lg:hidden mr-3 transition",style:{color:n.muted},children:e.jsx(zt,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h2",{className:"font-bold text-base lg:text-lg truncate",style:{color:n.text},children:a?a.name:r}),e.jsx("p",{className:"text-xs hidden sm:block",style:{color:n.muted},children:a?"Department management console":`Manage ${r.toLowerCase()} system content`})]}),e.jsxs("div",{className:"ml-auto flex items-center gap-2 sm:gap-3",children:[e.jsxs("button",{type:"button",onClick:l,title:"Reset Admin Password",className:"flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 rounded-xl border transition-all text-xs font-semibold shadow-xs hover:shadow-sm hover:scale-[1.02] active:scale-[0.98]",style:{background:"#FFF8F3",borderColor:"#EAD5C5",color:n.brand},children:[e.jsx(Tt,{size:15,style:{color:n.accent}}),e.jsx("span",{className:"hidden sm:inline",children:"Reset Password"})]}),e.jsxs("span",{className:"admin-header-chip hidden md:inline-flex",children:[e.jsx("span",{className:"admin-header-dot"}),"Live Admin"]})]})]}),yi=({selectedDeptForSlider:t,setSelectedDeptForSlider:a,departments:r,sliders:l,handleSliderUpload:d,updateSliderImage:o,del:i})=>{const s=l.filter(h=>t==="null"?!h.department:h.department?._id===t),b=t==="null"?"Homepage Sliders":r.find(h=>h._id===t)?.name||"Department Sliders",m=(h,f)=>`${t==="null"?"Homepage Slider":`${r.find(F=>F._id===t)?.name||"Department"} Slider`} #${f+1}`,k=h=>h.createdAt?new Date(h.createdAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}):"Recent Upload";return e.jsxs("div",{className:"home-manager-shell",children:[e.jsx("style",{children:`
        .home-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .home-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .home-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .home-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .home-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .home-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .home-manager-subtitle {
          margin: 8px 0 0;
          max-width: 620px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .home-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .home-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .home-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .home-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .home-manager-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 16px;
          align-items: end;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .home-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .home-manager-select-wrap {
          position: relative;
        }
        .home-manager-select-wrap select {
          width: 100%;
          height: 46px;
          appearance: none;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 750;
          outline: none;
          padding: 0 42px 0 14px;
          cursor: pointer;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .home-manager-select-wrap select:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .home-manager-select-wrap svg {
          position: absolute;
          right: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #7A6A5B;
          pointer-events: none;
        }
        .home-manager-upload {
          height: 46px;
          min-width: 168px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .home-manager-upload:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .home-manager-upload input,
        .home-manager-action input {
          display: none;
        }
        .home-manager-content {
          padding: 18px;
        }
        .home-manager-section-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .home-manager-section-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .home-manager-section-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .home-manager-target-badge {
          max-width: 260px;
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 7px 11px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          flex: 0 0 auto;
        }
        .home-manager-empty {
          min-height: 320px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 36px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .home-manager-empty-icon {
          width: 64px;
          height: 64px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(107, 63, 29, 0.08);
          margin-bottom: 16px;
        }
        .home-manager-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .home-manager-empty p {
          margin: 8px 0 18px;
          max-width: 380px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: 16px;
        }
        .home-slider-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          overflow: hidden;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          display: flex;
          flex-direction: column;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .home-slider-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .home-slider-media {
          position: relative;
          aspect-ratio: 16 / 10;
          background: #F3EFEA;
          overflow: hidden;
        }
        .home-slider-media img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 260ms ease;
        }
        .home-slider-card:hover .home-slider-media img {
          transform: scale(1.035);
        }
        .home-slider-overlay {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: rgba(26, 18, 8, 0.18);
          opacity: 0;
          transition: opacity 180ms ease;
          pointer-events: none;
        }
        .home-slider-card:hover .home-slider-overlay {
          opacity: 1;
        }
        .home-slider-overlay span {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: rgba(255,255,255,0.18);
          backdrop-filter: blur(8px);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.18);
        }
        .home-slider-body {
          padding: 14px;
          display: flex;
          flex: 1 1 auto;
          flex-direction: column;
          justify-content: space-between;
          gap: 14px;
        }
        .home-slider-body h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .home-slider-body p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .home-manager-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 9px;
          padding-top: 12px;
          border-top: 1px solid #EFE7DF;
        }
        .home-manager-action {
          height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          font-size: 12px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .home-manager-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .home-manager-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        @media (max-width: 920px) {
          .home-manager-hero,
          .home-manager-toolbar {
            grid-template-columns: 1fr;
          }
          .home-manager-stats {
            min-width: 0;
          }
          .home-manager-upload {
            width: 100%;
          }
        }
        @media (max-width: 560px) {
          .home-manager-hero,
          .home-manager-toolbar,
          .home-manager-content {
            padding: 14px;
          }
          .home-manager-title {
            font-size: 21px;
          }
          .home-manager-title-row {
            align-items: flex-start;
          }
          .home-manager-stats {
            grid-template-columns: 1fr;
          }
          .home-manager-section-head {
            flex-direction: column;
          }
          .home-manager-target-badge {
            max-width: 100%;
          }
          .home-manager-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),e.jsxs("div",{className:"home-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"home-manager-title-row",children:[e.jsx("div",{className:"home-manager-icon",children:e.jsx(Z,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"home-manager-kicker",children:"Homepage Media"}),e.jsx("h1",{className:"home-manager-title",children:"Home Page Management"})]})]}),e.jsx("p",{className:"home-manager-subtitle",children:"Manage homepage banner and department slider images with a cleaner preview-first workflow."})]}),e.jsxs("div",{className:"home-manager-stats",children:[e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:s.length}),e.jsx("span",{children:"Shown Here"})]}),e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:l.length}),e.jsx("span",{children:"Total Images"})]})]})]}),e.jsxs("div",{className:"home-manager-panel",children:[e.jsxs("div",{className:"home-manager-toolbar",children:[e.jsxs("div",{className:"home-manager-field",children:[e.jsx("label",{children:"Target Section"}),e.jsxs("div",{className:"home-manager-select-wrap",children:[e.jsxs("select",{value:t,onChange:h=>a(h.target.value),children:[e.jsx("option",{value:"null",children:"Homepage Sliders"}),r.map(h=>e.jsx("option",{value:h._id,children:h.name},h._id))]}),e.jsx(Pt,{size:17})]})]}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(se,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:d})]})]}),e.jsxs("div",{className:"home-manager-content",children:[e.jsxs("div",{className:"home-manager-section-head",children:[e.jsxs("div",{children:[e.jsx("h3",{children:"Gallery Images"}),e.jsx("p",{children:"Replace or remove images currently attached to this slider group."})]}),e.jsx("span",{className:"home-manager-target-badge",children:b})]}),s.length===0?e.jsxs("div",{className:"home-manager-empty",children:[e.jsx("div",{className:"home-manager-empty-icon",children:e.jsx(se,{size:30})}),e.jsx("h4",{children:"No Images Uploaded"}),e.jsx("p",{children:"Upload images for this section. A 16:9 image works best for public slider banners."}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(se,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:d})]})]}):e.jsx("div",{className:"home-manager-grid",children:e.jsx(fe,{children:s.map((h,f)=>e.jsxs(re.div,{layout:!0,initial:{opacity:0,y:10},animate:{opacity:1,y:0},exit:{opacity:0,scale:.96},className:"home-slider-card",children:[e.jsxs("div",{className:"home-slider-media",children:[e.jsx("img",{src:K(h.imageUrl),alt:m(h,f)}),e.jsx("div",{className:"home-slider-overlay",children:e.jsx("span",{children:e.jsx(Z,{size:18})})})]}),e.jsxs("div",{className:"home-slider-body",children:[e.jsxs("div",{children:[e.jsx("h4",{title:m(h,f),children:m(h,f)}),e.jsxs("p",{children:["Uploaded: ",k(h)]})]}),e.jsxs("div",{className:"home-manager-actions",children:[e.jsxs("label",{className:"home-manager-action",children:[e.jsx(Q,{size:13}),"Replace",e.jsx("input",{type:"file",onChange:C=>{const F=C.target.files?.[0];F&&o(h._id,F)}})]}),e.jsxs("button",{type:"button",className:"home-manager-action danger",onClick:()=>i(`/sliders/${h._id}`),children:[e.jsx(H,{size:13}),"Delete"]})]})]})]},h._id))})})]})]})]})},vi=({programs:t,academicContent:a,setAcademicContent:r,axiosInstance:l,notify:d,openModal:o,setProgramForm:i,del:s})=>{const b=new Set(t.map(h=>h.category).filter(Boolean)).size,m=()=>{i({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),o("program")},k=h=>{i({title:h.title,description:h.description,duration:h.duration,category:h.category,courses:h.courses?.join(", ")||"",image:null}),o("program",h)};return e.jsxs("div",{className:"academic-manager-shell",children:[e.jsx("style",{children:`
        .academic-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .academic-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .academic-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .academic-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .academic-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .academic-manager-subtitle {
          margin: 8px 0 0;
          max-width: 650px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .academic-manager-top-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .academic-manager-add {
          height: 44px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-add:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .academic-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .academic-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .academic-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .academic-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .academic-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .academic-manager-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .academic-manager-panel-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-panel-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .academic-manager-panel-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 17px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-manager-panel-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .academic-manager-form {
          padding: 18px;
          display: grid;
          gap: 14px;
        }
        .academic-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .academic-manager-field input,
        .academic-manager-field textarea {
          width: 100%;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 12px 14px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .academic-manager-field input {
          height: 46px;
        }
        .academic-manager-field textarea {
          min-height: 94px;
          resize: vertical;
          line-height: 1.55;
        }
        .academic-manager-field input:focus,
        .academic-manager-field textarea:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .academic-manager-save {
          justify-self: start;
          height: 42px;
          border: 0;
          border-radius: 11px;
          padding: 0 16px;
          color: #FFFFFF;
          background: #6B3F1D;
          box-shadow: 0 10px 20px rgba(107, 63, 29, 0.18);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-save:hover {
          transform: translateY(-1px);
          box-shadow: 0 14px 26px rgba(107, 63, 29, 0.24);
        }
        .academic-programs-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .academic-programs-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-programs-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .academic-programs-wrap {
          padding: 18px;
        }
        .academic-programs-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(310px, 1fr));
          gap: 16px;
        }
        .academic-program-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .academic-program-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .academic-program-top {
          display: grid;
          grid-template-columns: 82px minmax(0, 1fr) auto;
          gap: 13px;
          align-items: start;
        }
        .academic-program-image {
          width: 82px;
          aspect-ratio: 1;
          border-radius: 14px;
          overflow: hidden;
          background: #F3EFEA;
          border: 1px solid #EFE7DF;
          flex: 0 0 auto;
        }
        .academic-program-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }
        .academic-program-main {
          min-width: 0;
        }
        .academic-program-main h4 {
          margin: 0;
          color: #1A1208;
          font-size: 15px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .academic-program-meta {
          display: flex;
          flex-wrap: wrap;
          gap: 7px;
          margin-top: 9px;
        }
        .academic-program-pill {
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-duration {
          border: 1px solid #DDE7F2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #536C8D;
          background: #F6FAFE;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-actions {
          display: flex;
          align-items: center;
          gap: 7px;
        }
        .academic-program-action {
          width: 34px;
          height: 34px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .academic-program-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .academic-program-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        .academic-program-desc {
          margin: 0;
          min-height: 42px;
          color: #786859;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.55;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .academic-program-empty {
          min-height: 260px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 34px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .academic-program-empty-icon {
          width: 60px;
          height: 60px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 15px;
        }
        .academic-program-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .academic-program-empty p {
          margin: 8px 0 18px;
          max-width: 360px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        @media (max-width: 980px) {
          .academic-manager-hero {
            grid-template-columns: 1fr;
          }
          .academic-manager-stats {
            min-width: 0;
          }
          .academic-manager-top-actions {
            align-items: stretch;
            flex-direction: column;
          }
          .academic-manager-add {
            width: 100%;
          }
        }
        @media (max-width: 640px) {
          .academic-manager-hero,
          .academic-manager-panel-head,
          .academic-manager-form,
          .academic-programs-wrap {
            padding: 14px;
          }
          .academic-manager-title {
            font-size: 21px;
          }
          .academic-manager-title-row {
            align-items: flex-start;
          }
          .academic-manager-stats {
            grid-template-columns: 1fr;
          }
          .academic-manager-panel-head,
          .academic-programs-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .academic-programs-grid {
            grid-template-columns: 1fr;
          }
          .academic-program-top {
            grid-template-columns: 68px minmax(0, 1fr);
          }
          .academic-program-image {
            width: 68px;
          }
          .academic-program-actions {
            grid-column: 1 / -1;
            width: 100%;
            justify-content: flex-end;
          }
        }
      `}),e.jsxs("div",{className:"academic-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"academic-manager-title-row",children:[e.jsx("div",{className:"academic-manager-icon",children:e.jsx(Ee,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"academic-manager-kicker",children:"Academic Content"}),e.jsx("h1",{className:"academic-manager-title",children:"Academic Programs"})]})]}),e.jsx("p",{className:"academic-manager-subtitle",children:"Manage the public academic section copy and program cards from one focused workspace."})]}),e.jsxs("div",{className:"academic-manager-top-actions",children:[e.jsxs("div",{className:"academic-manager-stats",children:[e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:t.length}),e.jsx("span",{children:"Programs"})]}),e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:b}),e.jsx("span",{children:"Categories"})]})]}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:m,children:[e.jsx(ke,{size:16}),"Add New Program"]})]})]}),e.jsxs("div",{className:"academic-manager-panel",children:[e.jsx("div",{className:"academic-manager-panel-head",children:e.jsxs("div",{className:"academic-manager-panel-title",children:[e.jsx("div",{className:"academic-manager-panel-icon",children:e.jsx(Ce,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Section Banner Content"}),e.jsx("p",{children:"Copy shown above academic programs on the public website"})]})]})}),e.jsxs("div",{className:"academic-manager-form",children:[e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Section Display Title"}),e.jsx("input",{value:a.title,onChange:h=>r({...a,title:h.target.value}),placeholder:"Academic Programs"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Primary Description"}),e.jsx("textarea",{rows:3,value:a.description1,onChange:h=>r({...a,description1:h.target.value}),placeholder:"Primary description paragraph"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Secondary Description"}),e.jsx("textarea",{rows:2,value:a.description2,onChange:h=>r({...a,description2:h.target.value}),placeholder:"Secondary description paragraph"})]}),e.jsxs("button",{type:"button",className:"academic-manager-save",onClick:async()=>{try{await l.put("/content/academic",a),d("Content Saved Successfully")}catch{d("Failed to save content","error")}},children:[e.jsx(je,{size:15}),"Update Content"]})]})]}),e.jsx("div",{className:"academic-manager-panel",children:e.jsxs("div",{className:"academic-programs-wrap",children:[e.jsx("div",{className:"academic-programs-head",children:e.jsxs("div",{children:[e.jsx("h3",{children:"Program Cards"}),e.jsx("p",{children:"These programs appear in the academic programs section."})]})}),t.length===0?e.jsxs("div",{className:"academic-program-empty",children:[e.jsx("div",{className:"academic-program-empty-icon",children:e.jsx(Ee,{size:28})}),e.jsx("h4",{children:"No programs registered yet"}),e.jsx("p",{children:"Add the first program to start building the academic page."}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:m,children:[e.jsx(ke,{size:16}),"Add New Program"]})]}):e.jsx("div",{className:"academic-programs-grid",children:t.map(h=>e.jsxs(re.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},className:"academic-program-card",children:[e.jsxs("div",{className:"academic-program-top",children:[e.jsx("div",{className:"academic-program-image",children:e.jsx("img",{src:K(h.imageUrl),alt:h.title})}),e.jsxs("div",{className:"academic-program-main",children:[e.jsx("h4",{title:h.title,children:h.title}),e.jsxs("div",{className:"academic-program-meta",children:[h.category&&e.jsx("span",{className:"academic-program-pill",children:h.category}),h.duration&&e.jsx("span",{className:"academic-program-duration",children:h.duration})]})]}),e.jsxs("div",{className:"academic-program-actions",children:[e.jsx("button",{type:"button",className:"academic-program-action",onClick:()=>k(h),"aria-label":`Edit ${h.title}`,children:e.jsx(Q,{size:14})}),e.jsx("button",{type:"button",className:"academic-program-action danger",onClick:()=>s(`/programs/${h._id}`),"aria-label":`Delete ${h.title}`,children:e.jsx(H,{size:14})})]})]}),h.description&&e.jsx("p",{className:"academic-program-desc",children:h.description})]},h._id))})]})})]})},wi=({testimonials:t,testimonialForm:a,setTestimonialForm:r,openModal:l,del:d})=>e.jsxs("div",{className:"testimonial-manager-shell",children:[e.jsx("style",{children:`
      .testimonial-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
      .testimonial-manager-shell > div:first-of-type {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 18px !important;
        padding: 22px !important;
        border: 1px solid #E7DDD2 !important;
        border-radius: 18px !important;
        background:
          linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
          linear-gradient(135deg, #6B3F1D, #E07B39) !important;
        box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08) !important;
      }
      .testimonial-manager-shell > div:first-of-type h3 {
        margin: 0 !important;
        color: #1A1208 !important;
        font-size: 24px !important;
        line-height: 1.15 !important;
        font-weight: 900 !important;
        letter-spacing: 0 !important;
      }
      .testimonial-manager-shell > div:first-of-type p {
        margin: 6px 0 0 !important;
        color: #786859 !important;
        font-size: 13px !important;
        font-weight: 650 !important;
      }
      .testimonial-manager-shell > div:first-of-type button {
        height: 44px !important;
        border: 0 !important;
        border-radius: 12px !important;
        padding: 0 16px !important;
        color: #FFFFFF !important;
        background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%) !important;
        box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2) !important;
        font-size: 13px !important;
        font-weight: 900 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) {
        display: grid !important;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)) !important;
        gap: 16px !important;
        padding: 18px !important;
        border: 1px solid #E8E0D8 !important;
        border-radius: 18px !important;
        background: #FFFFFF !important;
        box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06) !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div {
        min-width: 0 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div:not(.col-span-full) {
        border: 1px solid #E8E0D8 !important;
        border-radius: 16px !important;
        background: #FFFFFF !important;
        box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06) !important;
        padding: 16px !important;
      }
      .testimonial-manager-shell img {
        width: 56px !important;
        height: 56px !important;
        border-radius: 16px !important;
        object-fit: cover !important;
      }
      .testimonial-manager-shell .col-span-full {
        grid-column: 1 / -1 !important;
      }
      .testimonial-manager-shell .col-span-full > div {
        min-height: 340px !important;
        border: 2px dashed #E6DCD1 !important;
        border-radius: 16px !important;
        background: #FBFAF8 !important;
        box-shadow: none !important;
      }
      @media (max-width: 640px) {
        .testimonial-manager-shell > div:first-of-type {
          align-items: stretch !important;
          flex-direction: column !important;
          padding: 14px !important;
        }
        .testimonial-manager-shell > div:nth-of-type(2) {
          grid-template-columns: 1fr !important;
          padding: 14px !important;
        }
      }
    `}),e.jsx(I,{icon:he,title:"Student Testimonials",subtitle:`${t.length} reviews published`,action:e.jsx(X,{onClick:()=>{r({name:"",role:"",content:"",rating:5,image:null}),l("testimonial")}})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[t.map(o=>e.jsxs(re.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},className:"p-6 rounded-3xl group relative shadow-md transition-all hover:shadow-lg flex flex-col h-full",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-start justify-between gap-4 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("img",{src:K(o.imageUrl),alt:o.name,className:"w-14 h-14 rounded-full object-cover border-2 shadow-inner",style:{borderColor:n.accentSoft}}),e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm leading-tight mb-1",style:{color:n.text},children:o.name}),e.jsx("p",{className:"text-xs font-medium",style:{color:n.muted},children:o.role}),e.jsx("div",{className:"flex gap-0.5 mt-1",children:[...Array(5)].map((i,s)=>e.jsx("span",{className:"text-sm",style:{color:s<o.rating?"#F59E0B":n.border},children:"★"},s))})]})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0",children:[e.jsx(M,{onClick:()=>{r({name:o.name,role:o.role,content:o.content,rating:o.rating,image:null}),l("testimonial",o)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>d(`/testimonials/${o._id}`),children:e.jsx(H,{size:14})})]})]}),e.jsxs("p",{className:"text-sm leading-relaxed italic text-gray-600 line-clamp-4 mt-1 flex-1",children:['"',o.content,'"']})]},o._id)),t.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(me,{icon:he,text:"No testimonials available"})})]})]}),ve=({slot:t,linkedKey:a,label:r,aboutImages:l,setAboutImages:d,aboutImageFiles:o,setAboutImageFiles:i,axiosInstance:s,notify:b})=>{if(!t)return null;const m=o[t.key],k=m?URL.createObjectURL(m):t.imageUrl?K(t.imageUrl):null,h=F=>{d(l.map(D=>D.key===t.key||D.key===a?{...D,...F}:D))},f=async()=>{const F=new FormData;F.append("title",t.title||r),F.append("alt",t.alt||r),m&&F.append("image",m);try{const D=await s.put(`/about/images/${t.key}`,F);let E=l.some($=>$.key===t.key)?l.map($=>$.key===t.key?D.data:$):[...l,D.data];if(a){const $=new FormData;$.append("title",t.title||r),$.append("alt",t.alt||r),m&&$.append("image",m);try{const V=await s.put(`/about/images/${a}`,$);E=E.some(z=>z.key===a)?E.map(z=>z.key===a?V.data:z):[...E,V.data]}catch{}}d(E),i({...o,[t.key]:null,...a?{[a]:null}:{}}),b(`${r} image saved`)}catch{b("Image update failed","error")}},C=async()=>{if(window.confirm(`Delete ${r} image? The website will use the default image.`))try{const F=await s.delete(`/about/images/${t.key}`);let D=l.some(E=>E.key===t.key)?l.map(E=>E.key===t.key?F.data:E):[...l,F.data];if(a)try{const E=await s.delete(`/about/images/${a}`);D=D.some($=>$.key===a)?D.map($=>$.key===a?E.data:$):[...D,E.data]}catch{}d(D),i({...o,[t.key]:null,...a?{[a]:null}:{}}),b(`${r} image deleted`)}catch{b("Delete failed","error")}};return e.jsxs("div",{className:"p-4 rounded-2xl shadow-sm space-y-3",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest",style:{color:n.muted},children:[r," Image"]}),e.jsx("div",{className:"rounded-xl overflow-hidden bg-gray-50 border border-dashed flex items-center justify-center",style:{borderColor:n.border,maxHeight:"200px",minHeight:"120px"},children:k?e.jsx("img",{src:k,alt:t.alt||r,className:"w-full object-cover",style:{maxHeight:"200px",width:"100%",display:"block"}}):e.jsxs("div",{className:"text-center py-8",style:{color:n.muted},children:[e.jsx(Z,{size:28,className:"mx-auto mb-2 opacity-60"}),e.jsx("p",{className:"text-[11px] font-bold uppercase tracking-wider",children:"Default image active"})]})}),e.jsx(x,{label:"Alt Text",children:e.jsx("input",{value:t.alt||"",onChange:F=>h({alt:F.target.value}),className:q,style:L})}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border-2 border-dashed text-xs font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:n.border,color:n.muted},children:[e.jsx(se,{size:14})," ",m?m.name:"Choose Image",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:F=>i({...o,[t.key]:F.target.files[0]})})]}),e.jsxs("button",{onClick:f,className:"px-4 py-2.5 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition-all flex items-center justify-center gap-2",style:{background:n.brand},children:[e.jsx(je,{size:14})," Save"]}),e.jsxs("button",{onClick:C,className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 active:scale-95 transition-all flex items-center justify-center gap-2",children:[e.jsx(H,{size:14})," Delete"]})]})]})},Ni=({aboutSub:t,setAboutSub:a,collegeLogo:r,setCollegeLogo:l,logoFile:d,setLogoFile:o,deanMessage:i,setDeanMessage:s,deanPhotoFile:b,setDeanPhotoFile:m,milestones:k,milestoneForm:h,setMilestoneForm:f,openModal:C,setMilestones:F,visionMission:D,setVmForm:E,coreValues:$,setCvForm:V,aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,historyContent:_,setHistoryContent:Y,axiosInstance:B,notify:g,del:j})=>e.jsxs("div",{className:"about-manager-shell admin-clean-page",children:[e.jsx("style",{children:`
      .about-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
    `}),e.jsx(ze,{tabs:["Branding","Principal","Timeline","Vision & Mission","Core Values"],active:t,onChange:a}),e.jsx(fe,{mode:"wait",children:e.jsxs(re.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:-8},children:[t==="Branding"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:n.text},children:"Institution Branding"}),e.jsxs("div",{className:"flex flex-col sm:flex-row items-start gap-6",children:[e.jsx("div",{className:"rounded-2xl border-2 border-dashed overflow-hidden bg-gray-50 flex items-center justify-center shrink-0 shadow-inner",style:{width:"100px",height:"100px",minWidth:"100px",minHeight:"100px",maxWidth:"100px",maxHeight:"100px",borderColor:n.border,padding:"6px",background:"#f8fafc",boxSizing:"border-box"},children:r.logoUrl?e.jsx("img",{src:K(r.logoUrl),style:{width:"100%",height:"100%",maxWidth:"86px",maxHeight:"86px",objectFit:"contain",display:"block"},alt:"College Logo"}):e.jsx(Z,{size:32,style:{color:n.muted}})}),e.jsxs("div",{className:"flex-1 w-full space-y-4",children:[e.jsx(x,{label:"College Full Name",children:e.jsx("input",{value:r.collegeName||"",onChange:c=>l({...r,collegeName:c.target.value}),placeholder:"e.g. Ginera Nursing College",className:q,style:L})}),e.jsx(x,{label:"Tagline / Motto",children:e.jsx("input",{value:r.tagline||"",onChange:c=>l({...r,tagline:c.target.value}),placeholder:"e.g. Excellence in Healthcare",className:q,style:L})})]})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-3 pt-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed text-sm font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:n.border,color:n.muted},children:[e.jsx(se,{size:16})," ",d?d.name:"Choose New Logo File",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:c=>o(c.target.files[0])})]}),e.jsx("button",{onClick:async()=>{const c=new FormData;c.append("collegeName",r.collegeName||""),c.append("tagline",r.tagline||""),d&&c.append("logo",d);try{const p=await B.put("/about/college-logo",c);l(p.data),o(null),g("Branding Updated Successfully")}catch{g("Update failed","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all",style:{background:n.brand},children:"Save Branding"})]})]}),t==="Principal"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-5 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:n.text},children:"Dean / Principal's Message"}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[e.jsx(x,{label:"Full Name",children:e.jsx("input",{value:i.name||"",onChange:c=>s({...i,name:c.target.value}),placeholder:"e.g. Dr. Jane Doe",className:q,style:L})}),e.jsx(x,{label:"Official Title",children:e.jsx("input",{value:i.title||"",onChange:c=>s({...i,title:c.target.value}),placeholder:"e.g. Dean of Nursing",className:q,style:L})})]}),e.jsx(x,{label:"Opening Greeting",children:e.jsx("input",{value:i.greeting||"",onChange:c=>s({...i,greeting:c.target.value}),placeholder:"e.g. Welcome to Ginera...",className:q,style:L})}),e.jsx(x,{label:"Message Content (New line for each paragraph)",children:e.jsx("textarea",{rows:6,className:`${q} resize-none`,style:L,value:(i.paragraphs||[]).join(`
`),onChange:c=>s({...i,paragraphs:c.target.value.split(`
`)})})}),e.jsx(x,{label:"Highlight Quote",children:e.jsx("textarea",{rows:2,className:`${q} resize-none font-medium italic`,style:L,placeholder:"A powerful summary statement...",value:i.highlight||"",onChange:c=>s({...i,highlight:c.target.value})})}),e.jsxs("div",{className:"flex flex-col gap-4 p-4 rounded-2xl bg-gray-50 border border-dashed sm:flex-row sm:items-center",style:{borderColor:n.border},children:[e.jsx("div",{className:"rounded-2xl overflow-hidden border-2 shadow-sm shrink-0",style:{width:"64px",height:"64px",minWidth:"64px",minHeight:"64px",maxWidth:"64px",maxHeight:"64px",borderColor:n.brand+"40"},children:i.photoUrl?e.jsx("img",{src:K(i.photoUrl),className:"w-full h-full object-cover",alt:""}):e.jsx("div",{className:"w-full h-full bg-white flex items-center justify-center",children:e.jsx(he,{size:24,style:{color:n.muted}})})}),e.jsxs("label",{className:"flex min-w-0 flex-1 items-center gap-3 rounded-xl border-2 border-dashed px-4 py-3 text-sm font-bold cursor-pointer transition-all hover:border-amber-400 hover:bg-amber-50",style:{borderColor:b?n.accent:n.border,color:n.text,background:b?n.accentSoft:"#FFFFFF"},children:[e.jsx("span",{className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",style:{background:n.accentSoft,color:n.accent},children:e.jsx(se,{size:17})}),e.jsxs("span",{className:"min-w-0 flex-1",children:[e.jsx("span",{className:"block text-[11px] uppercase tracking-wider",style:{color:n.muted},children:"Principal photo"}),e.jsx("span",{className:"block truncate mt-0.5",children:b?b.name:"Choose or replace photo"})]}),e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:c=>m(c.target.files[0])})]})]}),e.jsx("button",{onClick:async()=>{const c=new FormData;["name","title","greeting","highlight"].forEach(p=>c.append(p,i[p]||"")),c.append("paragraphs",JSON.stringify((i.paragraphs||[]).filter(p=>p&&p.trim()!==""))),c.append("stats",JSON.stringify(i.stats||[])),b&&c.append("photo",b);try{const p=await B.put("/about/dean",c);s(p.data),m(null),g("Message Updated Successfully")}catch{g("Update failed","error")}},className:"w-full sm:w-auto px-10 py-3.5 rounded-xl text-sm font-bold text-white shadow-xl active:scale-95 transition-all",style:{background:n.brand},children:"Publish Message"})]}),t==="Timeline"&&e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:n.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:n.text},children:"History Page Images Management"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:n.muted},children:"Upload, update, or delete images for Hero Banner, Institutional Timeline, and Legacy of Excellence sections"})]})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsx(ve,{slot:z.find(c=>c.key==="historyHero")||{key:"historyHero",title:"History Hero Banner Image",alt:"Our History Banner"},label:"History Hero Banner",aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,axiosInstance:B,notify:g}),e.jsx(ve,{slot:z.find(c=>c.key==="historyTimeline")||{key:"historyTimeline",title:"Institutional Timeline Image",alt:"Institutional Timeline"},label:"Institutional Timeline Section",aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,axiosInstance:B,notify:g}),e.jsx(ve,{slot:z.find(c=>c.key==="historyLegacy")||{key:"historyLegacy",title:"Legacy of Excellence Image",alt:"Legacy of Excellence"},label:"Legacy of Excellence Section",aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,axiosInstance:B,notify:g})]})]}),e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:n.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:n.text},children:"History Page Content & Section Titles"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:n.muted},children:"Edit main hero title, section headings, and history paragraphs"})]})}),e.jsx(x,{label:"Hero Banner Title",children:e.jsx(y,{value:_.heroTitle||"",onChange:c=>Y({..._,heroTitle:c.target.value}),placeholder:"e.g. Our History"})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6 pt-2",children:[e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:n.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Institutional Timeline Section"}),e.jsx(x,{label:"Section Title",children:e.jsx(y,{value:_.timelineTitle||"",onChange:c=>Y({..._,timelineTitle:c.target.value}),placeholder:"e.g. Institutional Timeline"})}),e.jsx(x,{label:"Paragraphs (One paragraph per line)",children:e.jsx(R,{rows:6,value:Array.isArray(_.timelineParagraphs)?_.timelineParagraphs.join(`
`):_.timelineParagraphs||"",onChange:c=>Y({..._,timelineParagraphs:c.target.value.split(`
`)}),placeholder:"Enter timeline history paragraphs..."})})]}),e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:n.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Legacy of Excellence Section"}),e.jsx(x,{label:"Section Title",children:e.jsx(y,{value:_.legacyTitle||"",onChange:c=>Y({..._,legacyTitle:c.target.value}),placeholder:"e.g. Legacy of Excellence"})}),e.jsx(x,{label:"Paragraphs (One paragraph per line)",children:e.jsx(R,{rows:6,value:Array.isArray(_.legacyParagraphs)?_.legacyParagraphs.join(`
`):_.legacyParagraphs||"",onChange:c=>Y({..._,legacyParagraphs:c.target.value.split(`
`)}),placeholder:"Enter legacy paragraphs..."})})]})]}),e.jsx("div",{className:"flex justify-end pt-2",children:e.jsxs("button",{onClick:async()=>{try{const c={..._,timelineParagraphs:(Array.isArray(_.timelineParagraphs)?_.timelineParagraphs:(_.timelineParagraphs||"").split(`
`)).filter(w=>w&&w.trim()!==""),legacyParagraphs:(Array.isArray(_.legacyParagraphs)?_.legacyParagraphs:(_.legacyParagraphs||"").split(`
`)).filter(w=>w&&w.trim()!=="")},p=await B.put("/about/history-content",c);Y(p.data),g("History Page Content Updated Successfully!")}catch{g("Failed to update history content","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all flex items-center gap-2",style:{background:n.brand},children:[e.jsx(je,{size:16})," Save History Page Content"]})})]}),e.jsxs("div",{className:"space-y-4 pt-4 border-t border-gray-200",children:[e.jsx(I,{icon:Ut,title:"Institutional Milestones",subtitle:"Timeline entries & historical achievements",action:e.jsx(X,{onClick:()=>{f({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),C("milestone")},label:"Add Milestone"})}),e.jsx("div",{className:"grid grid-cols-1 gap-4",children:k.map(c=>e.jsxs("div",{className:"p-5 rounded-2xl transition-all hover:shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",style:{background:n.surface,border:`1px solid ${n.border}`,borderLeft:`5px solid ${c.color||"#f59e0b"}`},children:[e.jsxs("div",{className:"flex items-start gap-4 min-w-0 flex-1",children:[e.jsx("span",{className:"text-3xl shrink-0 p-2 rounded-xl bg-amber-50 border border-amber-100",children:c.icon||"🎯"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("div",{className:"flex items-center gap-2 mb-1",children:e.jsx("span",{className:"px-2.5 py-0.5 rounded-md text-xs font-bold text-gray-800 bg-gray-100 border border-gray-200",children:c.year})}),e.jsx("p",{className:"font-bold text-sm text-gray-900 truncate",children:c.event}),e.jsx("p",{className:"text-xs text-gray-500 line-clamp-2 mt-1 leading-relaxed",children:c.description})]})]}),e.jsxs("div",{className:"flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-100",children:[e.jsxs("button",{onClick:()=>{f({year:c.year,event:c.event,icon:c.icon,color:c.color,description:c.description,order:c.order||0}),C("milestone",c)},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition-all shadow-sm",children:[e.jsx(Q,{size:14})," Edit"]}),e.jsxs("button",{onClick:async()=>{if(window.confirm("Delete this milestone?"))try{await B.delete(`/about/milestones/${c._id}`),F(k.filter(p=>p._id!==c._id)),g("Milestone Removed")}catch{g("Delete failed","error")}},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-all shadow-sm",children:[e.jsx(H,{size:14})," Delete"]})]})]},c._id))})]})]}),t==="Vision & Mission"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:$e,title:"Vision & Mission",subtitle:"Strategic direction statements",action:e.jsx(X,{onClick:()=>{E({type:"vision",content:"",order:0}),C("visionMission")},label:"Add Statement"})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-4",children:[e.jsx(ve,{slot:z.find(c=>c.key==="visionMain")||z.find(c=>c.key==="visionGoals"),linkedKey:"visionGoals",label:"Vision",aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,axiosInstance:B,notify:g}),e.jsx(ve,{slot:z.find(c=>c.key==="missionMain")||z.find(c=>c.key==="missionValues"),linkedKey:"missionValues",label:"Mission",aboutImages:z,setAboutImages:v,aboutImageFiles:T,setAboutImageFiles:P,axiosInstance:B,notify:g})]}),e.jsx("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",style:{gap:"1.5rem"},children:["vision","mission"].map(c=>e.jsxs("div",{className:"flex flex-col gap-3 min-w-0",style:{gap:"0.75rem"},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest pl-2",style:{color:n.muted},children:[c," Statement"]}),D.filter(p=>p.type===c).map(p=>e.jsxs("div",{className:"p-5 rounded-2xl relative group shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"text-sm leading-relaxed",style:{color:n.text},children:p.content}),e.jsxs("div",{className:"absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{E({type:p.type,content:p.content,order:p.order}),C("visionMission",p)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>j(`/about/vision-mission/${p._id}`),children:e.jsx(H,{size:13})})]})]},p._id))]},c))})]}),t==="Core Values"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:de,title:"Institutional Values",subtitle:"The pillars of our culture",action:e.jsx(X,{onClick:()=>{V({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),C("coreValue")},label:"Add Core Value"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",style:{gap:"1.25rem"},children:$.map(c=>e.jsxs("div",{className:"p-6 rounded-3xl group relative transition-all hover:shadow-lg overflow-hidden",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("div",{className:`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${c.color} opacity-[0.03] rounded-bl-[100px] transition-all group-hover:opacity-[0.08]`}),e.jsx("span",{className:"text-4xl block mb-4 filter drop-shadow-sm",children:c.icon}),e.jsx("p",{className:"font-bold text-base mb-2",style:{color:n.text},children:c.title}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:n.muted},children:c.description}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{V({icon:c.icon,title:c.title,description:c.description,color:c.color,order:c.order}),C("coreValue",c)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>j(`/about/core-values/${c._id}`),children:e.jsx(H,{size:13})})]})]},c._id))})]})]},t)})]}),Ci=({admSub:t,setAdmSub:a,courses:r,openModal:l,setCourseForm:d,del:o,admissionSteps:i,setStepForm:s,admissionRules:b,setRuleForm:m,bonds:k,setBondForm:h,guidelines:f,setGuidelineForm:C,announcements:F,setAnnouncementForm:D})=>{const[E,$]=u.useState("All"),V=["All",...Array.from(new Set(r.map(v=>v.category).filter(Boolean)))],z=E==="All"?r:r.filter(v=>v.category===E);return e.jsxs("div",{className:"admission-manager-shell admin-clean-page",children:[e.jsx(ze,{tabs:["Courses","Procedure","Eligibility","Guidelines","Announcements"],active:t,onChange:a}),t==="Courses"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:ge,title:"Program Offerings",subtitle:`${r.length} courses listed`,action:e.jsx(X,{onClick:()=>{d({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),l("course")},label:"Add Course"})}),e.jsx("div",{className:"flex flex-wrap gap-2",children:V.map(v=>e.jsx("button",{type:"button",onClick:()=>$(v),className:"px-3 py-2 rounded-xl text-xs font-bold border transition-all",style:{background:E===v?n.brand:n.surface,color:E===v?"#fff":n.muted,borderColor:n.border},children:v},v))}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:z.map(v=>e.jsx(be,{icon:v.icon,badge:v.category,title:v.name,sub:`${v.duration} | ${v.seats} Seats`,onEdit:()=>{d({...v,highlights:v.highlights?.join(", ")||""}),l("course",v)},onDelete:()=>o(`/courses/${v._id}`)},v._id))})]}),t==="Procedure"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:we,title:"Admission Steps",subtitle:"Step-by-step guidance for applicants",action:e.jsx(X,{onClick:()=>{s({step:1,title:"",description:"",details:"",icon:"Calendar"}),l("step")},label:"Add Step"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:i.sort((v,T)=>v.step-T.step).map(v=>e.jsxs("div",{className:"p-5 rounded-3xl group relative shadow-sm hover:shadow-md transition-all",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold text-white shadow-md",style:{background:n.brand},children:v.step}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:n.text},children:v.title}),e.jsx("p",{className:"text-xs line-clamp-1",style:{color:n.muted},children:v.description})]})]}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{s({...v}),l("step",v)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>o(`/admission-steps/${v._id}`),children:e.jsx(H,{size:13})})]})]},v._id))})]}),t==="Eligibility"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:Fe,title:"Admission Rules",subtitle:"Criteria for selection",action:e.jsx(X,{onClick:()=>{m({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),l("rule")},label:"Add Rule"})}),["UnderGraduated Programs","PostGraduated Programs","General Rules"].map(v=>{const T=b.filter(P=>P.category===v);return T.length?e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em] px-2",style:{color:n.muted},children:v}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:T.map(P=>e.jsx(be,{icon:P.icon==="CheckCircle"?"✅":"📋",title:P.title,sub:P.description?.slice(0,60)+"...",onEdit:()=>{m({...P}),l("rule",P)},onDelete:()=>o(`/admission-rules/${P._id}`)},P._id))})]},v):null})]}),t==="Guidelines"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:$e,title:"Guidelines & Conduct",subtitle:"Rules for students and guardians",action:e.jsx(X,{onClick:()=>{C({category:"General Guidelines",subCategory:"",points:"",order:0}),l("guideline")},label:"Add Section"})}),["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(v=>{const T=f.filter(P=>P.category===v);return T.length?e.jsxs("div",{className:"rounded-3xl overflow-hidden shadow-sm border",style:{borderColor:n.border},children:[e.jsx("div",{className:"px-6 py-3.5 border-b",style:{background:n.bg,borderColor:n.border},children:e.jsx("p",{className:"font-bold text-xs uppercase tracking-widest",style:{color:n.text},children:v})}),e.jsx("div",{className:"divide-y divide-gray-100",style:{background:n.surface},children:T.map(P=>e.jsxs("div",{className:"flex items-start gap-5 p-5 group transition-all hover:bg-gray-50/50",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"font-bold text-sm mb-2",style:{color:n.text},children:P.subCategory}),e.jsx("ul",{className:"space-y-1.5",children:P.points.map((_,Y)=>e.jsxs("li",{className:"flex items-start gap-2 text-xs leading-relaxed",style:{color:n.muted},children:[e.jsx("span",{className:"mt-1.5 w-1 h-1 rounded-full bg-amber-500 shrink-0"}),_]},Y))})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{C({...P,points:P.points.join(`
`)}),l("guideline",P)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>o(`/guidelines/${P._id}`),children:e.jsx(H,{size:14})})]})]},P._id))})]},v):null})]}),t==="Announcements"&&e.jsx(Aa,{announcements:F,setAnnouncementForm:D,openModal:l,del:o})]})},Aa=({announcements:t,setAnnouncementForm:a,openModal:r,del:l})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:De,title:"Admission Announcements",subtitle:`${(t||[]).length} announcement(s) published · Visible on public Admission Announcement page`,action:e.jsx(X,{onClick:()=>{a({title:"Admission Announcements Will Be Available Soon",badge:"Will Be Updated Soon",subtitle:"Official announcements, notices, and admission circulars for Government College of Nursing, GINERA.",description:"The official admission notices, circulars, and application schedules for Post Basic Diploma Course in Nursing at Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad) will be published here.",points:`Official admission notifications and merit lists will be published here as soon as released.
Post Basic Diploma Course in Nursing admissions are conducted for Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad).`,pdf:null,existingPdf:"",formName:"",formSize:0,removeFile:!1,isActive:!0,order:0}),r("announcement")},label:"Add Announcement"})}),!t||t.length===0?e.jsx(me,{icon:De,text:"No announcements yet. Click 'Add Announcement' to create one."}):e.jsx("div",{className:"grid grid-cols-1 gap-4",children:t.map((d,o)=>{const i=!!d.formUrl,s=Array.isArray(d.points)?d.points.length:0;return e.jsxs("div",{className:"p-5 rounded-3xl group relative shadow-sm hover:shadow-md transition-all space-y-4",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-start justify-between gap-4",children:[e.jsxs("div",{className:"flex items-start gap-3 flex-1 min-w-0",children:[e.jsx("div",{className:"w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 bg-amber-100 text-amber-700 shadow-sm",children:e.jsx(De,{size:20})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap mb-1",children:[e.jsx("span",{className:"text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 border border-amber-200",children:d.badge||"Will Be Updated Soon"}),e.jsx("span",{className:`text-[10px] font-bold px-2 py-0.5 rounded-md ${d.isActive!==!1?"bg-green-100 text-green-700":"bg-gray-100 text-gray-500"}`,children:d.isActive!==!1?"Active (Visible)":"Draft"})]}),e.jsx("h4",{className:"font-bold text-base text-gray-900 leading-snug",children:d.title}),e.jsx("p",{className:"text-xs text-gray-600 line-clamp-2 mt-1 leading-relaxed",children:d.description})]})]}),e.jsxs("div",{className:"flex items-center gap-1.5 shrink-0",children:[e.jsx(M,{title:"Edit Announcement",onClick:()=>{a({...d,points:Array.isArray(d.points)?d.points.join(`
`):d.points||"",pdf:null,existingPdf:d.formUrl||"",formName:d.formName||"",formSize:d.formSize||0,removeFile:!1}),r("announcement",d)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,title:"Delete Announcement",onClick:()=>l(`/announcements/${d._id}`),children:e.jsx(H,{size:14})})]})]}),e.jsxs("div",{className:"pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2 text-xs",children:[i?e.jsxs("div",{className:"flex items-center gap-2 text-amber-900 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200",children:[e.jsx(Ce,{size:15,className:"text-amber-600 shrink-0"}),e.jsx("span",{className:"font-semibold truncate max-w-xs",children:d.formName||"Attached Form (PDF)"}),d.formSize>0&&e.jsxs("span",{className:"text-[11px] text-gray-500",children:["(",(d.formSize/1024).toFixed(0)," KB)"]}),e.jsx("a",{href:_e(d.formUrl),target:"_blank",rel:"noopener noreferrer",className:"text-amber-600 hover:text-amber-800 font-bold underline ml-1 cursor-pointer",children:"View/Download"})]}):e.jsxs("div",{className:"text-gray-400 italic flex items-center gap-1.5",children:[e.jsx(Ce,{size:14}),e.jsx("span",{children:"No PDF form uploaded · Download button hidden from students"})]}),e.jsxs("span",{className:"text-[11px] text-gray-400 font-medium",children:[s," key point(s)"]})]})]},d._id||o)})})]}),ki=({selectedDept:t,setSelectedDept:a,departments:r,deptForm:l,setDeptForm:d,deptSub:o,setDeptSub:i,deptFacultyForm:s,setDeptFacultyForm:b,deptFacilityInput:m,setDeptFacilityInput:k,deptActivityInput:h,setDeptActivityInput:f,sliders:C,axiosInstance:F,fetchData:D,notify:E,openModal:$,del:V,handleSliderUpload:z})=>{const[v,T]=u.useState(null),[P,_]=u.useState(null),[Y,B]=u.useState(null),[g,j]=u.useState(!1),c=async p=>{const w=p.target.files?.[0];if(w){if(w.size>500*1024){E(`Image size is ${(w.size/1024).toFixed(0)}KB. Maximum allowed is 500KB.`,"error"),p.target.value="";return}try{j(!0);const S=new FormData;S.append("image",w);const G=await F.post("/departments/upload-faculty-image",S);b(ae=>({...ae,imageUrl:G.data.imageUrl})),E("Faculty photo uploaded successfully")}catch(S){const G=S.response?.data?.message||"Failed to upload faculty photo";E(G,"error")}finally{j(!1),p.target.value=""}}};return t?e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-col lg:flex-row items-start lg:items-center gap-6 p-6 rounded-3xl shadow-sm border overflow-hidden",style:{background:n.surface,borderColor:n.border},children:[e.jsxs("div",{className:"flex items-center gap-4 flex-1 min-w-0",children:[e.jsx("button",{onClick:()=>{a(null),T(null),_(null),B(null)},className:"p-3 rounded-2xl hover:bg-gray-50 transition-all shrink-0 border shadow-sm group",style:{borderColor:n.border,color:n.muted},children:e.jsx(Lt,{size:20,className:"group-hover:-translate-x-1 transition-transform"})}),l.logoUrl||t.logoUrl?e.jsx("img",{src:K(l.logoUrl||t.logoUrl),className:"w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm",alt:""}):e.jsx("span",{className:"text-3xl shrink-0 drop-shadow-sm",children:"🏥"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-base sm:text-xl whitespace-nowrap overflow-hidden text-ellipsis leading-tight",style:{color:n.text},children:t.name}),e.jsxs("div",{className:"flex items-center gap-2 mt-1",children:[e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em]",style:{color:n.accent},children:t.category}),e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"}),e.jsx("span",{className:"text-[11px] font-bold text-muted-foreground",children:"Editor Mode"})]})]})]}),e.jsxs("button",{onClick:async()=>{try{let p=l.faculty?[...l.faculty]:[];v!==null&&s.name?.trim()&&(p[v]={...s});const w=new FormData;w.append("name",l.name||""),w.append("category",l.category||""),w.append("description",l.description||""),w.append("overview",l.overview||""),w.append("overview2",l.overview2||""),w.append("faculty",JSON.stringify(p)),l.facilities&&w.append("facilities",JSON.stringify(l.facilities)),l.activities&&w.append("activities",JSON.stringify(l.activities)),l.logo instanceof File&&w.append("logo",l.logo);const S=await F.put(`/departments/${t._id}`,w);a(S.data),d({...S.data}),T(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}),E("Department & Staff Saved Successfully"),D()}catch{E("Failed to save changes","error")}},className:"w-full lg:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-sm font-bold text-white shadow-xl hover:opacity-90 active:scale-95 transition-all",style:{background:n.brand},children:[e.jsx(je,{size:18})," Save All Changes"]})]}),e.jsxs("div",{className:"flex flex-col gap-6",children:[e.jsx(ze,{tabs:["Overview","Faculty","Facilities","Activities","Sliders"],active:o,onChange:i}),e.jsxs("div",{className:"p-7 rounded-3xl shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[o==="Overview"&&e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-5 items-end",children:[e.jsx(x,{label:"Department Display Name",children:e.jsx("input",{value:l.name,onChange:p=>d({...l,name:p.target.value}),className:q,style:L})}),e.jsx(x,{label:"Academic Category",children:e.jsx("input",{value:l.category,onChange:p=>d({...l,category:p.target.value}),className:q,style:L})}),e.jsx(x,{label:"Department Logo",children:e.jsxs("div",{className:"flex items-center gap-3",children:[l.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(l.logo),className:"h-12 w-12 object-cover rounded-xl border",alt:"preview"}):l.logoUrl||t.logoUrl?e.jsx("img",{src:K(l.logoUrl||t.logoUrl),className:"h-12 w-12 object-cover rounded-xl border",alt:"current logo"}):e.jsx("div",{className:"h-12 w-12 rounded-xl flex items-center justify-center text-xl bg-gray-100",children:"🏥"}),e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border bg-white cursor-pointer hover:bg-gray-50 transition text-sm text-gray-500",style:{borderColor:"#E2E8F0"},children:[e.jsx(Z,{size:16}),l.logo instanceof File?"Change Logo":"Upload Image",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:p=>d({...l,logo:p.target.files[0]})})]})]})})]}),e.jsx(x,{label:"Short Introduction",children:e.jsx("input",{value:l.description,onChange:p=>d({...l,description:p.target.value}),className:q,style:L})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-5",children:[e.jsx(x,{label:"Primary Overview Paragraph",children:e.jsx("textarea",{rows:5,value:l.overview,onChange:p=>d({...l,overview:p.target.value}),className:`${q} resize-none`,style:L})}),e.jsx(x,{label:"Secondary Details (Optional)",children:e.jsx("textarea",{rows:5,value:l.overview2,onChange:p=>d({...l,overview2:p.target.value}),className:`${q} resize-none`,style:L})})]})]}),o==="Faculty"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"p-5 rounded-2xl shadow-inner border border-dashed space-y-4",style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[s.imageUrl?e.jsxs("div",{className:"relative group/avatar",children:[e.jsx("img",{src:K(s.imageUrl),alt:"Faculty preview",className:"w-16 h-16 rounded-2xl object-cover border-2 shadow-sm",style:{borderColor:n.brand}}),e.jsx("button",{type:"button",onClick:()=>b({...s,imageUrl:""}),className:"absolute -top-1.5 -right-1.5 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition shadow",title:"Remove photo",children:e.jsx(oe,{size:12})})]}):e.jsx("div",{className:"w-16 h-16 rounded-2xl flex items-center justify-center text-2xl border-2 border-dashed bg-white shadow-sm",style:{borderColor:n.border,color:n.muted},children:e.jsx(he,{size:24})}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap",children:[e.jsxs("label",{className:"flex items-center gap-2 px-4 py-2.5 rounded-xl border bg-white cursor-pointer hover:bg-gray-50 transition text-xs font-semibold text-gray-700 shadow-sm",style:{borderColor:n.border},children:[e.jsx(se,{size:14}),g?"Uploading...":s.imageUrl?"Change Photo":"Upload Faculty Photo",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",disabled:g,onChange:c})]}),s.imageUrl&&e.jsxs("button",{type:"button",onClick:()=>b({...s,imageUrl:""}),className:"flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-600 transition text-xs font-semibold shadow-sm",title:"Cancel / Remove image",children:[e.jsx(H,{size:13})," Cancel Image"]})]}),e.jsx("p",{className:"text-[11px] text-gray-400 mt-1",children:"Recommended: max 500KB (PNG/JPG/WEBP)"})]})]}),v!==null&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("div",{className:"px-3 py-1.5 rounded-lg bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1.5",children:[e.jsx(Q,{size:13})," Editing Faculty #",v+1]}),e.jsx("button",{type:"button",onClick:()=>{T(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 text-xs font-semibold transition",children:"Cancel Edit"})]})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-3",children:[e.jsx("input",{placeholder:"Faculty Full Name *",value:s.name||"",onChange:p=>b({...s,name:p.target.value}),className:q,style:L}),e.jsx("input",{placeholder:"Designation (e.g. Nursing Tutor)",value:s.designation||"",onChange:p=>b({...s,designation:p.target.value}),className:q,style:L}),e.jsx("input",{placeholder:"Qualification (e.g. M.Sc. Child Health Nursing)",value:s.qualification||"",onChange:p=>b({...s,qualification:p.target.value}),className:q,style:L})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-3 items-end",children:[e.jsx("div",{className:"sm:col-span-2",children:e.jsx("textarea",{rows:2,placeholder:"Faculty Description / Bio (e.g. Specialization, experience, clinical training...)",value:s.description||"",onChange:p=>b({...s,description:p.target.value}),className:`${q} resize-none`,style:L})}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("button",{type:"button",onClick:()=>{if(!s.name||!s.name.trim()){E("Please enter faculty name","error");return}if(v!==null){const p=[...l.faculty];p[v]={...s},d(w=>({...w,faculty:p})),T(null),E("Staff updated in list! Click 'Save All Changes' above to apply to the website.")}else d(p=>({...p,faculty:[...p.faculty||[],{...s}]})),E("Staff added to list! Click 'Save All Changes' above to apply to the website.");b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"flex-1 px-4 py-2.5 rounded-xl text-sm font-bold text-white shadow hover:opacity-90 active:scale-95 transition-all flex items-center justify-center gap-1.5",style:{background:n.brand},children:v!==null?"Update Staff":"Add Staff"}),v!==null&&e.jsx("button",{type:"button",onClick:()=>{T(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition",children:"Cancel"})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",children:[l.faculty.map((p,w)=>e.jsx("div",{className:`flex flex-col justify-between p-4 rounded-2xl shadow-sm border group transition-all ${v===w?"ring-2 ring-amber-500 bg-amber-50/40":"hover:border-amber-300 hover:shadow-md"}`,style:{background:n.bg,borderColor:n.border},children:e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-2.5",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0 flex-1",children:[p.imageUrl?e.jsx("img",{src:K(p.imageUrl),alt:p.name,className:"w-14 h-14 rounded-2xl object-cover shrink-0 border shadow-sm group-hover:scale-105 transition-transform"}):e.jsx("div",{className:"w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-base shrink-0 border shadow-sm",style:{background:n.accentSoft,color:n.accent,borderColor:n.border},children:p.name?p.name.charAt(0).toUpperCase():"👨‍⚕️"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:n.text},children:p.name}),e.jsx("p",{className:"text-[11px] font-bold uppercase tracking-wide text-amber-600 truncate mt-0.5",children:p.designation||"Faculty Member"}),e.jsx("p",{className:"text-[11px] text-gray-500 truncate mt-0.5",children:p.qualification})]})]}),e.jsxs("div",{className:"flex items-center gap-1 shrink-0",children:[e.jsx(M,{title:"Edit faculty member",onClick:()=>{T(w),b({name:p.name||"",designation:p.designation||"",qualification:p.qualification||"",specialization:p.specialization||"",description:p.description||"",imageUrl:p.imageUrl||""})},children:e.jsx(Q,{size:15})}),e.jsx(M,{danger:!0,title:"Delete faculty member",onClick:()=>{d({...l,faculty:l.faculty.filter((S,G)=>G!==w)}),v===w&&(T(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}))},children:e.jsx(H,{size:15})})]})]}),p.description&&e.jsx("p",{className:"text-xs text-gray-600 bg-amber-50/50 p-2.5 rounded-xl border border-amber-100/60 leading-relaxed mt-2 line-clamp-3",children:p.description})]})},w)),l.faculty.length===0&&e.jsx("div",{className:"col-span-full py-8 text-center text-gray-400 text-sm",children:"No faculty members added yet. Use the form above to add staff with photo and description."})]})]}),(o==="Facilities"||o==="Activities")&&(()=>{const p=o==="Facilities"?"facilities":"activities",w=o==="Facilities"?m:h,S=o==="Facilities"?k:f,G=o==="Facilities"?P:Y,ae=o==="Facilities"?_:B,ue=()=>{if(w.trim()){if(G!==null){const te=[...l[p]];te[G]=w.trim(),d({...l,[p]:te}),ae(null)}else d({...l,[p]:[...l[p],w.trim()]});S("")}};return e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx("input",{value:w,onChange:te=>S(te.target.value),onKeyDown:te=>te.key==="Enter"&&ue(),placeholder:G!==null?`Edit ${o.toLowerCase()} point...`:`Describe new ${o.toLowerCase()} point...`,className:`${q} flex-1 shadow-sm`,style:L}),e.jsx("button",{onClick:ue,className:"px-6 py-2.5 rounded-xl font-bold text-white shadow-lg hover:opacity-90 active:scale-95 transition-all shrink-0",style:{background:n.brand},children:G!==null?"Update Point":e.jsx(ke,{size:20})}),G!==null&&e.jsx("button",{onClick:()=>{ae(null),S("")},className:"px-4 py-2.5 rounded-xl font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition shrink-0 text-xs",children:"Cancel"})]}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:l[p].map((te,pe)=>e.jsxs("div",{className:`flex items-center justify-between p-4 rounded-2xl group transition-all border shadow-sm ${G===pe?"ring-2 ring-amber-500 bg-amber-50/30":"hover:bg-gray-50"}`,style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0 pr-3",children:[e.jsx("div",{className:"w-6 h-6 rounded-lg bg-white flex items-center justify-center shadow-sm shrink-0",children:e.jsx("span",{className:"text-[10px] font-bold",style:{color:n.accent},children:pe+1})}),e.jsx("p",{className:"text-sm leading-relaxed",style:{color:n.text},children:te})]}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(M,{onClick:()=>{ae(pe),S(te)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>{d({...l,[p]:l[p].filter((Le,Ae)=>Ae!==pe)}),G===pe&&(ae(null),S(""))},children:e.jsx(H,{size:14})})]})]},pe))})]})})(),o==="Sliders"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl shadow-inner border border-dashed",style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm",style:{color:n.text},children:"Department Hero Sliders"}),e.jsx("p",{className:"text-[11px] font-medium mt-0.5",style:{color:n.muted},children:"Upload high-resolution banner images for the department landing page (stored on Cloudinary)"})]}),e.jsxs("label",{className:"flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white cursor-pointer shadow-lg active:scale-95 transition-all hover:opacity-90",style:{background:n.brand},children:[e.jsx(se,{size:16})," Bulk Upload",e.jsx("input",{type:"file",multiple:!0,accept:"image/*",className:"hidden",onChange:p=>{p.target.files&&p.target.files.length>0&&(z(p,t._id),p.target.value="")}})]})]}),(()=>{const p=C.filter(w=>w.department?._id===t._id);return p.length===0?e.jsxs("div",{className:"flex flex-col items-center justify-center p-10 rounded-2xl border-2 border-dashed text-center",style:{borderColor:n.border,background:n.panel},children:[e.jsx("div",{className:"w-14 h-14 rounded-2xl flex items-center justify-center mb-3 shadow-inner",style:{background:`${n.brand}15`,color:n.brand},children:e.jsx(Z,{size:28})}),e.jsx("p",{className:"font-bold text-sm",style:{color:n.text},children:"No Sliders Uploaded Yet"}),e.jsxs("p",{className:"text-xs max-w-md mt-1 mb-5",style:{color:n.muted},children:["Upload one or multiple images for ",e.jsx("strong",{children:t.name}),". All images will be securely saved to Cloudinary and displayed immediately in the website banner."]}),e.jsxs("label",{className:"flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white cursor-pointer shadow-md active:scale-95 transition-all hover:opacity-90",style:{background:n.brand},children:[e.jsx(se,{size:14})," Choose Banner Images",e.jsx("input",{type:"file",multiple:!0,accept:"image/*",className:"hidden",onChange:w=>{w.target.files&&w.target.files.length>0&&(z(w,t._id),w.target.value="")}})]})]}):e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",children:p.map(w=>e.jsxs("div",{className:"group relative aspect-video rounded-2xl overflow-hidden shadow-md transition-all hover:shadow-xl",style:{border:`2px solid ${n.border}`},children:[e.jsx("img",{src:K(w.imageUrl),alt:"",className:"w-full h-full object-cover transition-transform duration-500 group-hover:scale-110",onError:S=>{S.currentTarget.onerror=null,S.currentTarget.src="https://placehold.co/600x400?text=Image+Unavailable"}}),w.imageUrl?.includes("cloudinary.com")&&e.jsx("span",{className:"absolute top-2 left-2 bg-emerald-600/90 text-white text-[9px] font-semibold px-2 py-0.5 rounded-full shadow backdrop-blur-xs",children:"Cloudinary"}),e.jsx("div",{className:"absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[1px]",children:e.jsx("button",{onClick:()=>V(`/sliders/${w._id}`),className:"p-3 bg-red-500 text-white rounded-2xl shadow-xl hover:bg-red-600 transform transition-transform group-hover:scale-110",title:"Delete Slider",children:e.jsx(H,{size:18})})})]},w._id))})})()]})]})]})]}):e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:ce,title:"Academic Departments",subtitle:`Managing ${r.length} nursing specialties`,action:e.jsx(X,{onClick:()=>{d({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],logo:null}),$("department")},label:"New Department"})}),e.jsxs("div",{className:"admin-department-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[r.map(p=>e.jsxs(re.div,{whileHover:{y:-4},className:"admin-department-card p-6 rounded-3xl group transition-all relative overflow-hidden",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("div",{className:"absolute top-0 right-0 w-20 h-20 bg-amber-500 opacity-[0.02] rounded-bl-[80px] group-hover:opacity-[0.06] transition-all"}),e.jsxs("div",{className:"admin-card-actions flex justify-end gap-1.5 mb-3",children:[e.jsx(M,{title:"Edit department",onClick:w=>{w.stopPropagation(),d({...p,logo:null}),$("department",p)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,title:"Delete department",onClick:w=>{w.stopPropagation(),V(`/departments/${p._id}`)},children:e.jsx(H,{size:14})})]}),e.jsxs("div",{className:"cursor-pointer",onClick:()=>{a(p),d({...p}),i("Overview")},children:[e.jsxs("div",{className:"admin-department-body flex items-center gap-4 mb-5",children:[p.logoUrl?e.jsx("img",{src:K(p.logoUrl),className:"admin-department-logo w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm group-hover:scale-105 transition-transform duration-300",alt:""}):e.jsx("div",{className:"w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0",style:{background:n.accentSoft},children:"🏥"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"admin-department-title font-bold text-sm truncate leading-tight mb-1",style:{color:n.text},children:p.name}),e.jsx(Na,{color:n.brand,children:p.category})]})]}),e.jsxs("div",{className:"admin-department-meta flex items-center justify-between text-[11px] font-bold uppercase tracking-wider",style:{color:n.muted},children:[e.jsxs("div",{className:"flex gap-2 flex-wrap",children:[e.jsxs("span",{children:[p.faculty?.length||0," Staff"]}),e.jsxs("span",{children:[p.facilities?.length||0," Labs"]})]}),e.jsx(va,{size:14,className:"group-hover:translate-x-1 transition-transform",style:{color:n.accent}})]})]})]},p._id)),r.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(me,{icon:ce,text:"No departments found"})})]})]})},Ai=({editItem:t,formState:a,setFormState:r,closeModal:l,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{if(s.preventDefault(),!t&&!a.media)return o(`Please select a ${a.mediaType==="video"?"video":"image"}`,"error");const b=new FormData;a.media instanceof File&&b.append("image",a.media),b.append("title",a.title||""),b.append("description",a.description||""),b.append("category",a.category||"college_campus_view"),b.append("mediaType",a.mediaType||"image");const m=t?`/gallery/${t._id}`:"/gallery";try{t?await i.put(m,b):await i.post(m,b),o(t?"Updated":"Created"),l(),d()}catch(k){const h=k.response?.data?.message||"Failed to save gallery item";o(h,"error")}},className:"space-y-5",children:[e.jsx("div",{className:"flex gap-1 p-1 rounded-2xl",style:{background:n.bg,border:`1px solid ${n.border}`},children:["image","video"].map(s=>e.jsxs("button",{type:"button",onClick:()=>r({...a,mediaType:s,media:null}),className:"flex-1 py-2.5 rounded-xl text-sm font-bold transition-all capitalize flex items-center justify-center gap-2",style:{background:a.mediaType===s?n.surface:"transparent",color:a.mediaType===s?n.text:n.muted,boxShadow:a.mediaType===s?"0 1px 6px rgba(0,0,0,0.08)":"none"},children:[s==="image"?e.jsx(Z,{size:15}):e.jsx("span",{style:{fontSize:"15px"},children:"🎬"}),s==="image"?"Image":"Video"]},s))}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:s=>r({...a,title:s.target.value}),placeholder:"e.g. Main Academic Building"})}),e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:s=>r({...a,category:s.target.value}),children:[e.jsx("option",{value:"college_campus_view",children:"College Campus View"}),e.jsx("option",{value:"college_highlight",children:"College Highlight"}),e.jsx("option",{value:"hospital",children:"Hospital Main/Additional Images"}),e.jsx("option",{value:"hospital_facility",children:"Hospital Facility & Department"}),e.jsx("option",{value:"event",children:"Main/Additional Event Images"}),e.jsx("option",{value:"event_academic",children:"Academic Events"}),e.jsx("option",{value:"event_cultural",children:"Cultural Events"}),e.jsx("option",{value:"event_sports",children:"Sports Events"}),e.jsx("option",{value:"event_community",children:"Community Service Events"})]})})]}),e.jsx(x,{label:"Description",children:e.jsx(R,{rows:3,value:a.description,onChange:s=>r({...a,description:s.target.value}),placeholder:"Media description..."})}),e.jsxs(x,{label:a.mediaType==="video"?"Video File":"Image File",children:[e.jsx("p",{className:"mb-2 text-xs font-semibold",style:{color:n.muted},children:"Recommended file size: 2–5 MB. Files larger than 5 MB are not accepted."}),e.jsxs("label",{className:"flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-dashed cursor-pointer hover:bg-gray-50 transition",style:{borderColor:a.media?n.accent:n.border},children:[e.jsx("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center shrink-0",style:{background:n.accentSoft},children:a.mediaType==="video"?e.jsx("span",{children:"🎬"}):e.jsx(Z,{size:16,style:{color:n.accent}})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold truncate",style:{color:a.media?n.text:n.muted},children:a.media&&typeof a.media=="object"?a.media.name:`Select ${a.mediaType==="video"?"video":"image"} file`}),e.jsx("p",{className:"text-[11px]",style:{color:n.muted},children:a.mediaType==="video"?"MP4, WebM, OGG, MOV · Max 100MB":"JPG, PNG, WEBP · Max 100MB"})]}),e.jsx("input",{type:"file",className:"hidden",accept:a.mediaType==="video"?"video/mp4,video/webm,video/ogg,video/quicktime":"image/*",onChange:s=>r({...a,media:s.target.files[0]})})]}),a.media&&a.media instanceof File&&(a.mediaType==="video"?e.jsx("video",{src:URL.createObjectURL(a.media),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"180px"}}):e.jsx("img",{src:URL.createObjectURL(a.media),className:"mt-2 h-20 w-20 object-cover rounded-xl border shadow-sm",alt:"preview"})),!a.media&&t&&(t.mediaType==="video"&&t.videoUrl?e.jsx("video",{src:K(t.videoUrl),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"150px"}}):t.imageUrl?e.jsx("img",{src:K(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border shadow-sm",alt:"current"}):null)]}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":a.mediaType==="video"?"Upload Video":"Create Image"})]}),Di=({galleryImages:t,galleryForm:a,setGalleryForm:r,openModal:l,del:d})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:Z,title:"Photo & Video Gallery",subtitle:"Manage all photos and videos in the gallery",action:e.jsx(X,{onClick:()=>{r({title:"",description:"",category:"college_campus_view",mediaType:"image",media:null}),l("gallery")},label:"Add Media"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(o=>e.jsx(be,{left:e.jsx("div",{className:"admin-media-thumb w-16 h-12 rounded-xl overflow-hidden border-2 shrink-0 shadow-sm relative",style:{borderColor:n.border},children:o.mediaType==="video"?e.jsx("div",{className:"w-full h-full flex items-center justify-center",style:{background:"#1a1a2e"},children:e.jsx("span",{style:{fontSize:"20px"},children:"🎬"})}):e.jsx("img",{src:K(o.imageUrl),className:"w-full h-full object-cover",alt:""})}),badge:`${o.mediaType==="video"?"🎬 VIDEO · ":""}${o.category.replace(/_/g," ")}`,title:o.title,sub:o.description?.substring(0,50)+"...",onEdit:()=>{r({...o,mediaType:o.mediaType||"image",media:null}),l("gallery",o)},onDelete:()=>d(`/gallery/${o._id}`)},o._id)),t.length===0&&e.jsx(me,{icon:Z,text:"No gallery media yet. Add your first photo or video."})]})]}),Ei=({institutes:t,openModal:a,del:r})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:ce,title:"Affiliated Institutes",subtitle:`${t.length} partners registered`,action:e.jsx(X,{onClick:()=>a("institute"),label:"Add Institute"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(l=>e.jsx(be,{left:e.jsx("div",{className:"w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-2xl shadow-sm border border-amber-100",children:l.icon||"🏥"}),badge:l.type,title:l.name,sub:l.capacity,onEdit:()=>a("institute",l),onDelete:()=>r(`/institutes/${l._id}`)},l._id)),t.length===0&&e.jsx(me,{icon:ce,text:"No institutes registered yet"})]})]}),Si=({editItem:t,closeModal:a,fetchData:r,notify:l})=>{const[d,o]=u.useState({name:"",type:"",description:"",description2:"",description3:"",established:"",capacity:"",icon:"🏥",order:0,specialties:"",services:"",contact:{address:"",phone:"",website:""}});u.useEffect(()=>{t&&o({...t,order:t.order||0,specialties:Array.isArray(t.specialties)?t.specialties.join(", "):"",services:Array.isArray(t.services)?t.services.join(", "):"",contact:{address:t.contact?.address||"",phone:t.contact?.phone||"",website:t.contact?.website||""}})},[t]);const i=async s=>{s.preventDefault();const b={...d,specialties:d.specialties.split(",").map(m=>m.trim()).filter(Boolean),services:d.services.split(",").map(m=>m.trim()).filter(Boolean)};try{t?await N.put(`/institutes/${t._id}`,b):await N.post("/institutes",b),l(t?"Updated":"Created"),a(),r()}catch{l("Operation failed","error")}};return e.jsxs("form",{onSubmit:i,className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Institute Name",required:!0,children:e.jsx(y,{required:!0,value:d.name,onChange:s=>o({...d,name:s.target.value}),placeholder:"e.g. Government Spine Institute"})}),e.jsx(x,{label:"Type (e.g. Hospital)",required:!0,children:e.jsx(y,{required:!0,value:d.type,onChange:s=>o({...d,type:s.target.value}),placeholder:"e.g. Educational Institute"})})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-4",children:[e.jsx(x,{label:"Established",children:e.jsx(y,{value:d.established,onChange:s=>o({...d,established:s.target.value}),placeholder:"e.g. 1980"})}),e.jsx(x,{label:"Capacity",children:e.jsx(y,{value:d.capacity,onChange:s=>o({...d,capacity:s.target.value}),placeholder:"e.g. 80 Beds"})}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:d.icon,onChange:s=>o({...d,icon:s.target.value})})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",required:!0,value:d.order,onChange:s=>o({...d,order:parseInt(s.target.value)||0})})})]}),e.jsx(x,{label:"Main Description",required:!0,children:e.jsx(R,{required:!0,rows:3,value:d.description,onChange:s=>o({...d,description:s.target.value}),placeholder:"Main description..."})}),e.jsx(x,{label:"Additional Description",children:e.jsx(R,{rows:2,value:d.description2,onChange:s=>o({...d,description2:s.target.value}),placeholder:"Extra details..."})}),e.jsx(x,{label:"Clinical Areas (comma separated)",children:e.jsx(R,{rows:2,value:d.specialties,onChange:s=>o({...d,specialties:s.target.value}),placeholder:"e.g. Orthopedics, Spine Surgery"})}),e.jsx(x,{label:"Key Services (comma separated)",children:e.jsx(R,{rows:2,value:d.services,onChange:s=>o({...d,services:s.target.value}),placeholder:"e.g. Emergency, OPD, ICU"})}),e.jsx(Ne,{title:"Contact Details",children:e.jsxs("div",{className:"p-4 rounded-2xl bg-white space-y-4 border border-gray-200",children:[e.jsx(x,{label:"Address",children:e.jsx(y,{value:d.contact.address,onChange:s=>o({...d,contact:{...d.contact,address:s.target.value}}),placeholder:"Institute address..."})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Phone",children:e.jsx(y,{value:d.contact.phone,onChange:s=>o({...d,contact:{...d.contact,phone:s.target.value}}),placeholder:"Contact number..."})}),e.jsx(x,{label:"Website",children:e.jsx(y,{value:d.contact.website,onChange:s=>o({...d,contact:{...d.contact,website:s.target.value}}),placeholder:"https://..."})})]})]})}),e.jsx(J,{onCancel:a,submitLabel:t?"Save Changes":"Create Institute"})]})},Fi=({editItem:t,keyPersonForm:a,setKeyPersonForm:r,closeModal:l,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{s.preventDefault();const b=t?`/contact/key-persons/${t._id}`:"/contact/key-persons",m={...a,responsibilities:typeof a.responsibilities=="string"?a.responsibilities.split(`
`).filter(Boolean):a.responsibilities};try{t?await i.put(b,m):await i.post(b,m),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:s=>r({...a,name:s.target.value}),placeholder:"Full name"})}),e.jsx(x,{label:"Position",required:!0,children:e.jsx(y,{required:!0,value:a.position,onChange:s=>r({...a,position:s.target.value}),placeholder:"e.g. Principal"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Qualification",children:e.jsx(y,{value:a.qualification,onChange:s=>r({...a,qualification:s.target.value}),placeholder:"e.g. M.Sc. Nursing, Ph.D."})}),e.jsx(x,{label:"Phone",children:e.jsx(y,{value:a.phone,onChange:s=>r({...a,phone:s.target.value}),placeholder:"Phone number"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Email",children:e.jsx(y,{value:a.email,onChange:s=>r({...a,email:s.target.value}),placeholder:"Email address"})}),e.jsx(x,{label:"Office Hours",children:e.jsx(y,{value:a.hours,onChange:s=>r({...a,hours:s.target.value}),placeholder:"e.g. 9:00 AM - 5:00 PM"})})]}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:a.icon,onChange:s=>r({...a,icon:s.target.value})})}),e.jsx(x,{label:"Responsibilities (one per line)",required:!0,children:e.jsx(R,{required:!0,rows:4,value:a.responsibilities,onChange:s=>r({...a,responsibilities:s.target.value}),placeholder:`Responsibility 1
Responsibility 2`})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Key Contact"})]}),zi=({editItem:t,contactDeptForm:a,setContactDeptForm:r,closeModal:l,fetchData:d,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{s.preventDefault();const b=t?`/contact/departments/${t._id}`:"/contact/departments";try{t?await i.put(b,a):await i.post(b,a),o("Saved"),l(),d()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Department Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:s=>r({...a,name:s.target.value}),placeholder:"e.g. Admission Office"})}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:a.icon,onChange:s=>r({...a,icon:s.target.value})})})]}),e.jsx(x,{label:"Phone",children:e.jsx(y,{value:a.phone,onChange:s=>r({...a,phone:s.target.value}),placeholder:"Phone number"})}),e.jsx(x,{label:"Email",children:e.jsx(y,{value:a.email,onChange:s=>r({...a,email:s.target.value}),placeholder:"Email address"})}),e.jsx(J,{onCancel:l,submitLabel:t?"Save Changes":"Add Department Contact"})]}),Bi=({contactSub:t,setContactSub:a,keyPersons:r,setKeyPersonForm:l,contactDepartments:d,setContactDeptForm:o,contactInfo:i,setContactInfo:s,openModal:b,del:m,notify:k,axiosInstance:h})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(ze,{tabs:["Key Persons","Departments","College Info"],active:t,onChange:a}),t==="Key Persons"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:he,title:"Key Administrative Contacts",subtitle:"Manage main contacts shown on the contact page",action:e.jsx(X,{onClick:()=>{l({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),b("keyPerson")},label:"Add Person"})}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:r.map(f=>e.jsx(be,{icon:f.icon,title:f.name,sub:f.position,onEdit:()=>{l({...f,responsibilities:f.responsibilities?.join(`
`)||""}),b("keyPerson",f)},onDelete:()=>m(`/contact/key-persons/${f._id}`)},f._id))})]}),t==="Departments"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:ce,title:"Department Contact Directory",subtitle:"Manage specific departments on the contact page",action:e.jsx(X,{onClick:()=>{o({name:"",phone:"",email:"",icon:"📚"}),b("contactDept")},label:"Add Department"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:d.map(f=>e.jsx(be,{icon:f.icon,title:f.name,sub:f.phone+" | "+f.email,onEdit:()=>{o({...f}),b("contactDept",f)},onDelete:()=>m(`/contact/departments/${f._id}`)},f._id))})]}),t==="College Info"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(I,{icon:$t,title:"College Contact Information",subtitle:"Address, phone, and general emails"}),e.jsxs("div",{className:"p-6 rounded-2xl space-y-4 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx(x,{label:"College Address",children:e.jsx("textarea",{required:!0,rows:4,value:i.address||"",onChange:f=>s({...i,address:f.target.value}),className:`${q} resize-none`,style:L})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Reception Phone",children:e.jsx("input",{value:i.receptionPhone||"",onChange:f=>s({...i,receptionPhone:f.target.value}),className:q,style:L})}),e.jsx(x,{label:"Ambulance Phone",children:e.jsx("input",{value:i.ambulancePhone||"",onChange:f=>s({...i,ambulancePhone:f.target.value}),className:q,style:L})})]}),e.jsx(x,{label:"General Email",children:e.jsx("input",{value:i.generalEmail||"",onChange:f=>s({...i,generalEmail:f.target.value}),className:q,style:L})}),e.jsx("button",{onClick:async()=>{try{await h.put("/contact/info",i),k("Contact Info Saved")}catch{k("Failed to save","error")}},className:"px-6 py-2.5 rounded-xl text-sm font-bold text-white shadow-md hover:opacity-90",style:{background:n.brand},children:"Save College Info"})]})]})]}),Pi=({notify:t})=>{const{sectionsList:a,loading:r,toggleSection:l,togglePageSections:d,toggleDepartmentSections:o,refreshVisibility:i}=Bt(),[s,b]=u.useState("Home Page"),[m,k]=u.useState("all"),[h,f]=u.useState("");u.useEffect(()=>{typeof i=="function"&&i()},[]);const C=["Home Page","About Us","Admission","Departments","Gallery","Institutes","Student Corner","Contact Us","All Pages"],F=C.reduce((g,j)=>(g[j]=j==="All Pages"?a.length:a.filter(c=>c.page===j).length,g),{}),D=u.useMemo(()=>{const g=new Map;a.filter(c=>c.page==="Departments").forEach(c=>{let p=c.departmentSlug;p||(p=c.sectionKey.replace(/^dept_/,"").replace(/_(overview|facilities|faculty|activities)$/,""));let w=c.departmentName;w||(w=c.sectionName.split(" - ")[0]||p),g.has(p)||g.set(p,{slug:p,name:w,sections:[]}),g.get(p).sections.push(c)});const j={page:1,overview:2,facilities:3,faculty:4,activities:5};return g.forEach(c=>{c.sections.sort((p,w)=>{const S=j[p.subSection]||99,G=j[w.subSection]||99;return S-G})}),Array.from(g.values()).sort((c,p)=>c.name.localeCompare(p.name))},[a]),E=g=>g.subSection==="page"||g.sectionKey.endsWith("_page")||!g.subSection&&!g.sectionKey.includes("_overview")&&!g.sectionKey.includes("_facilities")&&!g.sectionKey.includes("_faculty")&&!g.sectionKey.includes("_activities")?{label:"Entire Page",tag:"Page Access",color:"#6B3F1D",bg:"#FDF0E6",icon:ce}:g.subSection==="overview"||g.sectionKey.endsWith("_overview")?{label:"Overview",tag:"Overview & Vision",color:"#0284C7",bg:"#E0F2FE",icon:Ee}:g.subSection==="facilities"||g.sectionKey.endsWith("_facilities")?{label:"Facilities",tag:"Labs & Equipment",color:"#7C3AED",bg:"#EDE9FE",icon:we}:g.subSection==="faculty"||g.sectionKey.endsWith("_faculty")?{label:"Faculty",tag:"Faculty & Slider",color:"#D97706",bg:"#FEF3C7",icon:he}:g.subSection==="activities"||g.sectionKey.endsWith("_activities")?{label:"Activities",tag:"Academic Activities",color:"#059669",bg:"#D1FAE5",icon:ge}:{label:"Section",tag:"Section Control",color:"#4B5563",bg:"#F3F4F6",icon:we},$=u.useMemo(()=>{let g=D;if(m!=="all"&&(g=g.filter(c=>c.slug===m)),!h.trim())return g;const j=h.toLowerCase();return g.map(c=>{if(c.name.toLowerCase().includes(j)||c.slug.toLowerCase().includes(j))return c;const w=c.sections.filter(S=>(S.sectionName||"").toLowerCase().includes(j)||(S.description||"").toLowerCase().includes(j)||(S.sectionKey||"").toLowerCase().includes(j));return w.length>0?{...c,sections:w}:null}).filter(Boolean)},[D,m,h]),V=u.useMemo(()=>a.filter(g=>{if(g.page==="Departments")return!1;const j=s==="All Pages"||g.page===s,c=!h.trim()||(g.sectionName||"").toLowerCase().includes(h.toLowerCase())||(g.description||"").toLowerCase().includes(h.toLowerCase())||(g.sectionKey||"").toLowerCase().includes(h.toLowerCase());return j&&c}),[a,s,h]),z=u.useMemo(()=>V.reduce((g,j)=>(g[j.page]=g[j.page]||[],g[j.page].push(j),g),{}),[V]),v=a.length,T=a.filter(g=>g.isVisible!==!1).length,P=v-T,_=v?Math.round(T/v*100):0,Y=s==="Departments"||s==="All Pages",B=s!=="Departments";return e.jsxs("div",{className:"section-control-shell",children:[e.jsx("style",{children:`
        .section-control-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .section-control-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: stretch;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.96), rgba(255,250,246,0.92)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .section-control-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .section-control-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .section-control-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .section-control-subtitle {
          margin: 8px 0 0;
          max-width: 660px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .section-control-metrics {
          display: grid;
          grid-template-columns: repeat(3, minmax(92px, 1fr));
          gap: 10px;
          min-width: 340px;
        }
        .section-control-metric {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .section-control-metric strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .section-control-metric span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .section-control-progress {
          grid-column: 1 / -1;
          height: 8px;
          overflow: hidden;
          border-radius: 99px;
          background: #EFE7DF;
        }
        .section-control-progress > span {
          display: block;
          height: 100%;
          width: var(--section-progress, 0%);
          border-radius: inherit;
          background: linear-gradient(90deg, #16A34A, #E07B39);
        }
        .section-control-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(260px, 360px);
          gap: 16px;
          align-items: start;
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .section-control-tabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          min-width: 0;
        }
        .section-control-tab {
          min-height: 36px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 7px 12px;
          color: #655646;
          background: #FBFAF8;
          font-size: 12px;
          font-weight: 800;
          line-height: 1;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .section-control-tab:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .section-control-tab.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        .section-control-count {
          min-width: 22px;
          height: 22px;
          padding: 0 7px;
          border-radius: 999px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: inherit;
          background: rgba(255,255,255,0.65);
          font-size: 11px;
          font-weight: 900;
        }
        .section-control-tab.is-active .section-control-count {
          background: rgba(255,255,255,0.18);
        }
        .section-control-search {
          position: relative;
          min-width: 0;
        }
        .section-control-search input {
          width: 100%;
          height: 42px;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 0 38px 0 40px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-search input:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .section-control-search svg {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #9A806B;
        }
        .section-control-clear {
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 26px;
          height: 26px;
          border-radius: 8px;
          color: #8A7A6A;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .section-control-clear:hover {
          background: #EFE7DF;
          color: #1A1208;
        }

        /* Department Filter Pills */
        .dept-filter-bar {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding: 12px 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FBFAF8;
        }
        .dept-filter-pill {
          min-height: 32px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 6px 12px;
          color: #655646;
          background: #FFFFFF;
          font-size: 12px;
          font-weight: 750;
          line-height: 1;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .dept-filter-pill:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .dept-filter-pill.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 8px 18px rgba(107, 63, 29, 0.18);
        }
        .dept-filter-pill.is-active .dept-filter-count {
          background: rgba(255,255,255,0.22);
          color: #FFFFFF;
        }
        .dept-filter-count {
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 999px;
          background: #F1ECE6;
          color: #796858;
          font-weight: 800;
        }

        .section-control-loading {
          min-height: 280px;
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          color: #8A7A6A;
          font-size: 14px;
          font-weight: 800;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
        }
        .section-control-spinner {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          border: 3px solid #E8E0D8;
          border-top-color: #6B3F1D;
          animation: section-spin 800ms linear infinite;
        }
        @keyframes section-spin {
          to { transform: rotate(360deg); }
        }
        .section-control-groups {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        .section-control-group {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .section-control-group-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .section-control-group-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-group-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .section-control-group-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 16px;
          line-height: 1.2;
          font-weight: 900;
        }
        .section-control-group-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .dept-meta-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-top: 4px;
          flex-wrap: wrap;
        }
        .dept-slug-badge {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          font-size: 11px;
          font-weight: 700;
          padding: 2px 7px;
          border-radius: 6px;
          background: #F5EFE9;
          color: #6B3F1D;
          border: 1px solid #E8DDD2;
        }
        .dept-stat-badge {
          font-size: 11px;
          font-weight: 800;
          padding: 2px 8px;
          border-radius: 999px;
        }
        .dept-stat-badge.is-all {
          background: #ECFDF3;
          color: #146C3E;
          border: 1px solid #B8E7CA;
        }
        .dept-stat-badge.is-partial {
          background: #FFFBEB;
          color: #B45309;
          border: 1px solid #FDE68A;
        }
        .dept-stat-badge.is-none {
          background: #FFF1F1;
          color: #A13434;
          border: 1px solid #F4C7C7;
        }

        .section-control-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 0 0 auto;
        }
        .section-control-action {
          height: 34px;
          border: 1px solid transparent;
          border-radius: 10px;
          padding: 0 12px;
          font-size: 12px;
          font-weight: 900;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
        }
        .section-control-action:hover {
          transform: translateY(-1px);
        }
        .section-control-action.on {
          color: #146C3E;
          background: #ECFDF3;
          border-color: #B8E7CA;
        }
        .section-control-action.off {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-control-list {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          padding: 16px;
        }
        .section-control-card {
          position: relative;
          min-width: 0;
          min-height: 108px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 14px;
          align-items: center;
          padding: 16px 16px 16px 18px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          transition: transform 160ms ease, border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-card::before {
          content: "";
          position: absolute;
          left: 0;
          top: 12px;
          bottom: 12px;
          width: 4px;
          border-radius: 0 999px 999px 0;
          background: #16A34A;
        }
        .section-control-card:hover {
          transform: translateY(-1px);
          border-color: #D8C8B7;
          box-shadow: 0 14px 28px rgba(65, 42, 22, 0.08);
        }
        .section-control-card.is-hidden {
          background: #FBFAF8;
        }
        .section-control-card.is-hidden::before {
          background: #D94B4B;
        }
        .section-control-card-copy {
          min-width: 0;
        }
        .section-control-status-row {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
          margin-bottom: 9px;
          flex-wrap: wrap;
        }
        .section-control-status {
          min-width: 68px;
          border-radius: 999px;
          padding: 4px 8px;
          color: #146C3E;
          background: #ECFDF3;
          border: 1px solid #B8E7CA;
          font-size: 10px;
          font-weight: 950;
          line-height: 1;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-align: center;
          flex: 0 0 auto;
        }
        .section-control-card.is-hidden .section-control-status {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-sub-tag {
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.04em;
          padding: 4px 8px;
          border-radius: 6px;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          flex: 0 0 auto;
        }
        .section-control-key {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          border: 1px solid #E7DDD2;
          border-radius: 8px;
          padding: 4px 8px;
          color: #725B45;
          background: #FFF8F1;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
          font-size: 11px;
          line-height: 1.2;
        }
        .section-control-card h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .section-control-card p {
          margin: 5px 0 0;
          color: #756657;
          font-size: 12px;
          line-height: 1.45;
          font-weight: 600;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .section-toggle {
          width: 58px;
          height: 32px;
          border: 0;
          border-radius: 999px;
          background: #16A34A;
          padding: 3px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: flex-end;
          box-shadow: inset 0 0 0 1px rgba(0,0,0,0.08);
          transition: background 180ms ease;
        }
        .section-toggle.is-off {
          justify-content: flex-start;
          background: #CBD5E1;
        }
        .section-toggle span {
          width: 26px;
          height: 26px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #16A34A;
          background: #FFFFFF;
          box-shadow: 0 3px 8px rgba(0,0,0,0.18);
        }
        .section-toggle.is-off span {
          color: #64748B;
        }
        @media (max-width: 1180px) {
          .section-control-hero,
          .section-control-toolbar {
            grid-template-columns: 1fr;
          }
          .section-control-metrics {
            min-width: 0;
          }
        }
        @media (max-width: 860px) {
          .section-control-list {
            grid-template-columns: 1fr;
          }
          .section-control-group-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .section-control-actions {
            width: 100%;
          }
          .section-control-action {
            flex: 1 1 0;
          }
        }
        @media (max-width: 560px) {
          .section-control-hero,
          .section-control-toolbar {
            padding: 14px;
            border-radius: 14px;
          }
          .section-control-title {
            font-size: 21px;
          }
          .section-control-title-row {
            align-items: flex-start;
          }
          .section-control-metrics {
            grid-template-columns: 1fr;
          }
          .section-control-card {
            grid-template-columns: 1fr;
          }
          .section-toggle {
            width: 100%;
            justify-content: flex-end;
          }
          .section-toggle.is-off {
            justify-content: flex-start;
          }
          .section-control-tabs {
            flex-wrap: nowrap;
            overflow-x: auto;
            padding-bottom: 2px;
          }
        }
      `}),e.jsxs("div",{className:"section-control-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"section-control-title-row",children:[e.jsx("div",{className:"section-control-icon",children:e.jsx(wa,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"section-control-kicker",children:"Site Content Manager"}),e.jsx("h2",{className:"section-control-title",children:"Section Visibility"})]})]}),e.jsx("p",{className:"section-control-subtitle",children:"Live control for public page sections & individual department modules (Full Page, Overview, Facilities, Faculty, Activities)."})]}),e.jsxs("div",{className:"section-control-metrics",children:[e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{children:v}),e.jsx("span",{children:"Total Sections"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#16A34A"},children:T}),e.jsx("span",{children:"Visible"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#D94B4B"},children:P}),e.jsx("span",{children:"Hidden"})]}),e.jsx("div",{className:"section-control-progress",style:{"--section-progress":`${_}%`},children:e.jsx("span",{})})]})]}),e.jsxs("div",{className:"section-control-toolbar",children:[e.jsx("div",{className:"section-control-tabs",children:C.map(g=>{const j=s===g;return e.jsxs("button",{type:"button",onClick:()=>{b(g),g==="Departments"&&k("all")},className:`section-control-tab ${j?"is-active":""}`,children:[g,e.jsx("span",{className:"section-control-count",children:F[g]})]},g)})}),e.jsxs("div",{className:"section-control-search",children:[e.jsx(Qt,{size:16}),e.jsx("input",{type:"text",placeholder:"Search sections or departments...",value:h,onChange:g=>f(g.target.value)}),h&&e.jsx("button",{type:"button",className:"section-control-clear",onClick:()=>f(""),"aria-label":"Clear search",children:e.jsx(oe,{size:15})})]})]}),s==="Departments"&&D.length>0&&e.jsxs("div",{className:"dept-filter-bar",children:[e.jsxs("span",{className:"text-xs font-bold text-stone-500 flex items-center gap-1.5 self-center mr-1",children:[e.jsx(ce,{size:14})," Filter Dept:"]}),e.jsxs("button",{type:"button",onClick:()=>k("all"),className:`dept-filter-pill ${m==="all"?"is-active":""}`,children:["All Departments",e.jsx("span",{className:"dept-filter-count",children:D.length})]}),D.map(g=>{const j=g.sections.filter(p=>p.isVisible!==!1).length,c=m===g.slug;return e.jsxs("button",{type:"button",onClick:()=>k(g.slug),className:`dept-filter-pill ${c?"is-active":""}`,title:g.name,children:[g.name.replace(/^Department of\s+/i,""),e.jsxs("span",{className:"dept-filter-count",children:[j,"/",g.sections.length]})]},g.slug)})]}),r?e.jsxs("div",{className:"section-control-loading",children:[e.jsx("span",{className:"section-control-spinner"}),"Loading visibility settings..."]}):e.jsxs("div",{className:"section-control-groups",children:[B&&Object.entries(z).map(([g,j])=>e.jsxs("div",{className:"section-control-group",children:[e.jsxs("div",{className:"section-control-group-head",children:[e.jsxs("div",{className:"section-control-group-title",children:[e.jsx("div",{className:"section-control-group-icon",children:e.jsx(we,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{children:g}),e.jsxs("p",{children:[j.length," sections configured"]})]})]}),e.jsxs("div",{className:"section-control-actions",children:[e.jsxs("button",{type:"button",onClick:async()=>{try{await d(g,!0),t(`Turned ALL sections ON for ${g}`)}catch{t("Update failed","error")}},className:"section-control-action on",children:[e.jsx(de,{size:14})," All ON"]}),e.jsxs("button",{type:"button",onClick:async()=>{try{await d(g,!1),t(`Turned ALL sections OFF for ${g}`)}catch{t("Update failed","error")}},className:"section-control-action off",children:[e.jsx(oe,{size:14})," All OFF"]})]})]}),e.jsx("div",{className:"section-control-list",children:j.map(c=>{const p=c.isVisible!==!1;return e.jsxs("div",{className:`section-control-card ${p?"":"is-hidden"}`,children:[e.jsxs("div",{className:"section-control-card-copy",children:[e.jsxs("div",{className:"section-control-status-row",children:[e.jsx("span",{className:"section-control-status",children:p?"Visible":"Hidden"}),e.jsx("span",{className:"section-control-key",children:c.sectionKey})]}),e.jsx("h4",{children:c.sectionName}),c.description&&e.jsx("p",{children:c.description})]}),e.jsx("button",{type:"button","aria-pressed":p,"aria-label":`Toggle ${c.sectionName}`,onClick:async()=>{try{await l(c.sectionKey,!p),t(`${c.sectionName} is now ${p?"OFF (Hidden)":"ON (Visible)"}`)}catch{t("Update failed","error")}},className:`section-toggle ${p?"":"is-off"}`,children:e.jsx("span",{children:p?e.jsx(de,{size:15}):e.jsx(oe,{size:15})})})]},c.sectionKey)})})]},g)),Y&&e.jsxs(e.Fragment,{children:[s==="All Pages"&&e.jsxs("div",{className:"flex items-center gap-3 pt-4 pb-1",children:[e.jsx("div",{className:"h-px bg-stone-300 flex-1"}),e.jsxs("span",{className:"text-xs font-black uppercase tracking-widest text-stone-500 flex items-center gap-2",children:[e.jsx(ge,{size:16})," Department-Wise Section Controls (",D.length," Departments)"]}),e.jsx("div",{className:"h-px bg-stone-300 flex-1"})]}),$.length===0?e.jsx(me,{icon:Se,text:"No departments or sections found matching search/filter."}):$.map(g=>{const j=g.sections.filter(S=>S.isVisible!==!1).length,c=g.sections.length,p=j===c,w=j===0;return e.jsxs("div",{className:"section-control-group",children:[e.jsxs("div",{className:"section-control-group-head",children:[e.jsxs("div",{className:"section-control-group-title",children:[e.jsx("div",{className:"section-control-group-icon",style:{background:"#FDF0E6",color:"#6B3F1D"},children:e.jsx(ge,{size:22})}),e.jsxs("div",{children:[e.jsx("h3",{children:g.name}),e.jsxs("div",{className:"dept-meta-row",children:[e.jsxs("span",{className:"dept-slug-badge",children:["/department-",g.slug]}),e.jsxs("span",{className:`dept-stat-badge ${p?"is-all":w?"is-none":"is-partial"}`,children:[j," of ",c," Sections Visible"]})]})]})]}),e.jsxs("div",{className:"section-control-actions",children:[e.jsxs("button",{type:"button",onClick:async()=>{try{await o(g.slug,!0),t(`Turned ALL sections ON for ${g.name}`)}catch{t("Update failed","error")}},className:"section-control-action on",children:[e.jsx(de,{size:14})," All ON"]}),e.jsxs("button",{type:"button",onClick:async()=>{try{await o(g.slug,!1),t(`Turned ALL sections OFF for ${g.name}`)}catch{t("Update failed","error")}},className:"section-control-action off",children:[e.jsx(oe,{size:14})," All OFF"]})]})]}),e.jsx("div",{className:"section-control-list",children:g.sections.map(S=>{const G=S.isVisible!==!1,ae=E(S),ue=ae.icon;return e.jsxs("div",{className:`section-control-card ${G?"":"is-hidden"}`,children:[e.jsxs("div",{className:"section-control-card-copy",children:[e.jsxs("div",{className:"section-control-status-row",children:[e.jsx("span",{className:"section-control-status",children:G?"Visible":"Hidden"}),e.jsxs("span",{className:"section-sub-tag",style:{background:ae.bg,color:ae.color},children:[e.jsx(ue,{size:11})," ",ae.tag]}),e.jsx("span",{className:"section-control-key",children:S.sectionKey})]}),e.jsx("h4",{children:S.sectionName}),S.description&&e.jsx("p",{children:S.description})]}),e.jsx("button",{type:"button","aria-pressed":G,"aria-label":`Toggle ${S.sectionName}`,onClick:async()=>{try{await l(S.sectionKey,!G),t(`${S.sectionName} is now ${G?"OFF (Hidden)":"ON (Visible)"}`)}catch{t("Update failed","error")}},className:`section-toggle ${G?"":"is-off"}`,children:e.jsx("span",{children:G?e.jsx(de,{size:15}):e.jsx(oe,{size:15})})})]},S.sectionKey)})})]},g.slug)})]}),!Y&&Object.keys(z).length===0&&e.jsx(me,{icon:Se,text:"No sections found matching filter search."})]})]})},_i=({onLogout:t})=>{const[a,r]=u.useState("Home Page"),[l,d]=u.useState("Branding"),[o,i]=u.useState("Courses"),[s,b]=u.useState("Overview"),[m,k]=u.useState("Key Persons"),[h,f]=u.useState(!1),[C,F]=u.useState("null"),[D,E]=u.useState(null),[$,V]=u.useState(!1),[z,v]=u.useState(null),[T,P]=u.useState(!1),[_,Y]=u.useState(!1),[B,g]=u.useState(""),[j,c]=u.useState(null),[p,w]=u.useState(window.innerWidth<1024);u.useEffect(()=>{const A=()=>w(window.innerWidth<1024);return window.addEventListener("resize",A),()=>window.removeEventListener("resize",A)},[]);const[S,G]=u.useState([]),[ae,ue]=u.useState([]),[te,pe]=u.useState([]),[Le,Ae]=u.useState({title:"",description1:"",description2:""}),[Da,Ge]=u.useState([]),[Ea,Re]=u.useState({name:"",title:"",greeting:"",paragraphs:[],highlight:"",photoUrl:"",stats:[]}),[Sa,Oe]=u.useState({logoUrl:"",collegeName:"",tagline:""}),[Fa,Me]=u.useState([]),[za,He]=u.useState({heroTitle:"Our History",timelineTitle:"Institutional Timeline",timelineParagraphs:[],legacyTitle:"Legacy of Excellence",legacyParagraphs:[]}),[Ba,Pa]=u.useState([]),[Ua,$a]=u.useState([]),[_a,Ta]=u.useState([]),[qa,La]=u.useState([]),[Ga,Ra]=u.useState([]),[Oa,Ma]=u.useState([]),[Ha,Va]=u.useState([]),[Ve,Wa]=u.useState([]),[Ka,Ya]=u.useState([]),[Ia,Ja]=u.useState([]),[Qa,Xa]=u.useState([]),[Za,We]=u.useState({address:"",receptionPhone:"",ambulancePhone:"",generalEmail:""}),[Ke,Ye]=u.useState([]),[et,Ie]=u.useState({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),[Je,Qe]=u.useState({name:"",role:"",content:"",rating:5,image:null}),[Xe,Ze]=u.useState({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),[at,ea]=u.useState({type:"vision",content:"",order:0}),[tt,aa]=u.useState({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),[it,ta]=u.useState({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),[st,ia]=u.useState({step:1,title:"",description:"",details:"",icon:"Calendar"}),[rt,sa]=u.useState({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),[nt,ra]=u.useState({type:"student",title:"",content:"",order:0}),[lt,na]=u.useState({category:"General Guidelines",subCategory:"",points:"",order:0}),[la,oa]=u.useState({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],icon:"🏥"}),[ot,dt]=u.useState({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}),[ct,pt]=u.useState(""),[xt,mt]=u.useState(""),[gt,ht]=u.useState(null),[ut,bt]=u.useState(null),[ft,jt]=u.useState({}),[yt,vt]=u.useState([]),[da,ca]=u.useState({title:"",description:"",category:"college_campus_view",image:null}),[wt,pa]=u.useState({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),[Nt,xa]=u.useState({name:"",phone:"",email:"",icon:"📚"}),[Ct,ma]=u.useState([]),[kt,ga]=u.useState({title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0}),[At,Be]=u.useState({title:"Admission Announcements Will Be Available Soon",subtitle:"Official announcements, notices, and admission circulars for Government College of Nursing, GINERA.",badge:"Will Be Updated Soon",description:"The official admission notices, circulars, and application schedules for Post Basic Diploma Course in Nursing at Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad) will be published here.",points:`Official admission notifications and merit lists will be published here as soon as released.
Post Basic Diploma Course in Nursing admissions are conducted for Government / GMERS Medical / Nursing College (Government College of Nursing, GINERA, Ahmedabad).`,pdf:null,existingPdf:"",formName:"",formSize:0,removeFile:!1,isActive:!0,order:0}),U=(A,le="success")=>{v({message:A,type:le}),setTimeout(()=>v(null),3e3)};u.useEffect(()=>{O()},[]);const O=async()=>{V(!0);try{const A=await Promise.all([N.get("/programs"),N.get("/testimonials"),N.get("/content/academic"),N.get("/about/milestones"),N.get("/about/dean"),N.get("/about/college-logo"),N.get("/about/images"),N.get("/about/vision-mission"),N.get("/about/core-values"),N.get("/courses"),N.get("/admission-steps"),N.get("/admission-rules"),N.get("/bonds"),N.get("/guidelines"),N.get("/departments"),N.get("/sliders?department=all"),N.get("/gallery"),N.get("/institutes"),N.get("/contact/key-persons"),N.get("/contact/departments"),N.get("/contact/info"),N.get("/about/history-content")]);ue(A[0].data),pe(A[1].data),Ae(A[2].data),Ge(A[3].data),Re(A[4].data),Oe(A[5].data),Me(A[6].data),Pa(A[7].data),$a(A[8].data),Ta(A[9].data),La(A[10].data),Ra(A[11].data),Ma(A[12].data),Va(A[13].data),Wa(A[14].data),G(A[15].data),vt(A[16].data),Ya(A[17].data),Ja(A[18].data),Xa(A[19].data),We(A[20].data),A[21]?.data&&He(A[21].data)}catch{U("Error fetching data","error")}finally{try{const{data:A}=await N.get("/student-corner");ma(Array.isArray(A)?A:[])}catch{ma([]),U("Unable to load Student Corner data","error")}try{const A=await N.get("/announcements?all=true");Ye(Array.isArray(A.data)?A.data:[])}catch{Ye([])}V(!1)}},ie=async(A,le=!0)=>{if(window.confirm("Are you sure?"))try{await N.delete(A),U("Deleted"),le&&O()}catch{U("Delete failed","error")}},ha=async(A,le)=>{const ye=Array.from(A.target?.files||[A]);if(!ye.length)return;const Pe=new FormData;ye.forEach(St=>Pe.append("images",St));const ba=le||C;ba!=="null"&&Pe.append("department",ba);try{await N.post("/sliders/upload",Pe),U("Uploaded"),O()}catch{U("Upload failed","error")}},Dt=async(A,le)=>{const ye=new FormData;ye.append("image",le);try{await N.put(`/sliders/${A}`,ye),U("Updated"),O()}catch{U("Update failed","error")}},ne=(A,le=null)=>{g(A),c(le),P(!0)},W=()=>{P(!1),c(null)},Et=[{name:"Section Control",icon:wa},{name:"Home Page",icon:Z},{name:"Academic",icon:Ee},{name:"Testimonials",icon:he},{name:"About Us",icon:$e},{name:"Admission",icon:we},{name:"Announcement",icon:De},{name:"Departments",icon:ce},{name:"Institutes",icon:ce},{name:"Gallery",icon:Z},{name:"Student Corner",icon:ge},{name:"Contact Us",icon:Ft},{name:"Settings",icon:fa}],ua={program:{title:j?"Edit Program":"Add Program",subtitle:"Academic program details"},testimonial:{title:j?"Edit Testimonial":"Add Testimonial",subtitle:"Student review"},milestone:{title:j?"Edit Milestone":"Add Milestone",subtitle:"Timeline entry"},visionMission:{title:j?"Edit Point":"Add Point",subtitle:"Vision or Mission statement"},coreValue:{title:j?"Edit Value":"Add Core Value",subtitle:"Institutional value"},course:{title:j?"Edit Course":"Add Course",subtitle:"Admission course"},step:{title:j?"Edit Step":"Add Step",subtitle:"Admission procedure step"},rule:{title:j?"Edit Rule":"Add Rule",subtitle:"Eligibility rule"},bond:{title:j?"Edit Bond":"Add Bond Point",subtitle:"Student bond"},guideline:{title:j?"Edit Guidelines":"Add Guidelines",subtitle:"Student / parent guidance"},department:{title:j?"Edit Dept":"Add Department",subtitle:"Create a new department"},gallery:{title:j?"Edit Photo":"Add Photo",subtitle:"Gallery image"},institute:{title:j?"Edit Institute":"Add Institute",subtitle:"Affiliated institute details"},keyPerson:{title:j?"Edit Contact":"Add Contact",subtitle:"Key administrative contact"},contactDept:{title:j?"Edit Dept":"Add Dept",subtitle:"Contact department"},studentCorner:{title:j?"Edit Section":"Add Section",subtitle:"Student Corner document section"},announcement:{title:j?"Edit Announcement":"Add Announcement",subtitle:"Admission announcement & PDF form"}}[B]||{};return e.jsxs("div",{className:"admin-shell flex flex-1 h-full w-full min-h-0 bg-gray-50 text-gray-900 font-sans overflow-hidden relative items-stretch",style:{display:"flex",height:"100dvh",minHeight:"100dvh",maxHeight:"100dvh",width:"100%",overflow:"hidden"},children:[e.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
        * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
        html, body, #root {
          height: 100%;
        }
        body:has(.admin-shell) {
          overflow: hidden;
        }
        .admin-shell {
          display: flex !important;
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-sidebar {
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
          background:
            linear-gradient(180deg, #6B3F1D 0%, #633815 46%, #4E2B12 100%) !important;
          box-shadow: inset -1px 0 0 rgba(255,255,255,0.07);
        }
        .admin-sidebar nav button {
          min-height: 46px;
          border: 1px solid transparent;
        }
        .admin-sidebar nav button:hover {
          background: rgba(255,255,255,0.09) !important;
          color: rgba(255,255,255,0.9) !important;
          border-color: rgba(255,255,255,0.08);
        }
        .admin-sidebar nav button[style*="rgba(255,255,255,0.12)"] {
          background: rgba(255,255,255,0.15) !important;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 12px 24px rgba(37, 22, 10, 0.16);
        }
        .admin-main {
          display: flex !important;
          flex-direction: column !important;
          flex: 1 1 auto !important;
          min-width: 0 !important;
          min-height: 0 !important;
          height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-header {
          height: 64px !important;
          min-height: 64px !important;
        }
        .admin-content-scroll {
          flex: 1 1 auto !important;
          min-height: 0 !important;
          height: calc(100dvh - 64px) !important;
          overflow-y: auto !important;
          overflow-x: hidden !important;
          overscroll-behavior: contain;
        }
        .admin-page-inner {
          width: 100%;
          max-width: 1580px !important;
        }
        @media (max-width: 1023px) {
          .admin-header {
            height: 56px !important;
            min-height: 56px !important;
          }
          .admin-content-scroll {
            height: calc(100dvh - 56px) !important;
          }
        }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        /* Premium admin scrollbar */
        .admin-scroll::-webkit-scrollbar { width: 8px; }
        .admin-scroll::-webkit-scrollbar-track { background: #F4F1EE; border-radius: 10px; }
        .admin-scroll::-webkit-scrollbar-thumb { background: #C4A882; border-radius: 10px; border: 2px solid #F4F1EE; }
        .admin-scroll::-webkit-scrollbar-thumb:hover { background: #6B3F1D; }
        .admin-scroll { scrollbar-width: thin; scrollbar-color: #C4A882 #F4F1EE; -webkit-overflow-scrolling: touch; }
        .admin-header {
          background:
            linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,252,249,0.96)) !important;
          box-shadow: 0 1px 0 rgba(232, 224, 216, 0.78), 0 10px 30px rgba(65, 42, 22, 0.04);
        }
        .admin-header h2 {
          letter-spacing: 0;
        }
        .admin-header-chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          height: 32px;
          padding: 0 12px;
          border: 1px solid #EEE2D6;
          border-radius: 999px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 800;
        }
        .admin-header-dot {
          width: 8px;
          height: 8px;
          border-radius: 999px;
          background: #16A34A;
          box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.12);
        }
        .admin-content-scroll {
          background:
            radial-gradient(circle at top right, rgba(224, 123, 57, 0.07), transparent 34%),
            linear-gradient(180deg, #F8F6F3 0%, #F4F1EE 100%);
        }
        .admin-section-header,
        .admin-row-item,
        .admin-department-card {
          border-radius: 18px !important;
          box-shadow: 0 14px 32px rgba(65, 42, 22, 0.055);
        }
        .admin-section-header {
          min-height: 76px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.98), rgba(255,248,241,0.88)) !important;
        }
        .admin-section-icon,
        .admin-row-icon {
          box-shadow: inset 0 0 0 1px rgba(224, 123, 57, 0.12);
        }
        .admin-section-title,
        .admin-row-title,
        .admin-department-title {
          letter-spacing: 0;
        }
        .admin-section-subtitle,
        .admin-row-subtitle {
          font-weight: 600;
        }
        .admin-add-btn {
          min-height: 38px;
          border-radius: 999px !important;
          padding-inline: 16px !important;
          background: linear-gradient(135deg, #6B3F1D 0%, #8A4E23 100%) !important;
          box-shadow: 0 12px 22px rgba(107, 63, 29, 0.18);
          white-space: nowrap;
        }
        .admin-icon-btn {
          width: 36px;
          height: 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(226, 217, 208, 0.82);
          border-radius: 12px !important;
          box-shadow: 0 6px 14px rgba(17, 24, 39, 0.04);
        }
        .admin-icon-btn.is-danger {
          border-color: rgba(254, 226, 226, 0.95);
        }
        .admin-row-item {
          min-height: 82px;
          background: rgba(255,255,255,0.96) !important;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-row-item:hover {
          transform: translateY(-2px);
          border-color: #D8C6B4 !important;
          box-shadow: 0 18px 38px rgba(65, 42, 22, 0.085);
        }
        .admin-row-actions {
          padding-left: 12px;
        }
        .admin-pill {
          border-radius: 999px !important;
          text-transform: none !important;
          letter-spacing: 0 !important;
          font-size: 12px !important;
          line-height: 1.15;
          padding: 5px 10px !important;
        }
        .admin-department-grid {
          align-items: stretch;
        }
        .admin-department-card {
          min-height: 178px;
          background: rgba(255,255,255,0.96) !important;
          cursor: default;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-department-card:hover {
          border-color: #D8C6B4 !important;
          box-shadow: 0 20px 44px rgba(65, 42, 22, 0.1);
        }
        .admin-department-body {
          align-items: flex-start;
        }
        .admin-department-body > :first-child,
        .admin-media-thumb {
          box-shadow: 0 8px 18px rgba(65, 42, 22, 0.08);
        }
        .admin-department-title {
          white-space: normal !important;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
          min-height: 38px;
          font-size: 15px !important;
          line-height: 1.28 !important;
        }
        .admin-department-meta {
          margin-top: auto;
          padding-top: 14px;
          border-top: 1px solid #F0E7DF;
          letter-spacing: 0 !important;
          text-transform: none !important;
          font-size: 13px !important;
        }
        .admin-department-meta span {
          display: inline-flex;
          align-items: center;
          min-height: 24px;
          padding: 4px 9px;
          border-radius: 999px;
          color: #6F6254;
          background: #F7F2ED;
        }
        .admin-media-thumb {
          width: 72px !important;
          height: 52px !important;
          border-width: 1px !important;
        }
        .admin-subtabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding: 10px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .admin-subtabs button {
          min-height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 8px 15px;
          color: #655646;
          background: #FBFAF8;
          font-size: 13px;
          font-weight: 850;
          line-height: 1;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .admin-subtabs button:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .admin-subtabs button.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        @media (max-width: 640px) {
          .admin-section-header {
            padding: 16px !important;
          }
          .admin-add-btn {
            width: 100%;
            justify-content: center;
          }
          .admin-row-item {
            align-items: flex-start;
            gap: 12px;
            padding: 14px !important;
          }
          .admin-row-actions {
            opacity: 1 !important;
            padding-left: 0;
          }
          .admin-icon-btn {
            width: 34px;
            height: 34px;
          }
          .admin-subtabs {
            flex-wrap: nowrap;
            overflow-x: auto;
          }
        }
      `}),e.jsx(bi,{isMobile:p,sidebarOpen:h,setSidebarOpen:f,activeTab:a,setActiveTab:r,selectedDept:D,setSelectedDept:E,navItems:Et,onLogout:t}),e.jsxs("main",{className:"admin-main flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-gray-50",style:{height:"100dvh",minHeight:0,overflow:"hidden"},children:[e.jsx(ji,{setSidebarOpen:f,selectedDept:D,activeTab:a,onOpenResetPassword:()=>Y(!0)}),e.jsx(ti,{note:z,onDismiss:()=>v(null)}),e.jsx("div",{className:"admin-content-scroll flex-1 min-h-0 overflow-y-auto admin-scroll p-4 md:p-6 lg:p-8",children:e.jsxs("div",{className:"admin-page-inner max-w-7xl mx-auto pb-24",children:[$&&e.jsx("div",{className:"absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm",children:e.jsx("div",{className:"w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"})}),e.jsx(fe,{mode:"wait",children:e.jsxs(re.div,{initial:{opacity:0,y:12},animate:{opacity:1,y:0},exit:{opacity:0,y:-12},transition:{duration:.25},children:[a==="Section Control"&&e.jsx(Pi,{notify:U}),a==="Home Page"&&e.jsx(yi,{selectedDeptForSlider:C,setSelectedDeptForSlider:F,departments:Ve,sliders:S,handleSliderUpload:ha,updateSliderImage:Dt,del:ie}),a==="Academic"&&e.jsx(vi,{programs:ae,academicContent:Le,setAcademicContent:Ae,axiosInstance:N,notify:U,openModal:ne,setProgramForm:Ie,del:ie}),a==="Testimonials"&&e.jsx(wi,{testimonials:te,testimonialForm:Je,setTestimonialForm:Qe,openModal:ne,del:ie}),a==="About Us"&&e.jsx(Ni,{aboutSub:l,setAboutSub:d,collegeLogo:Sa,setCollegeLogo:Oe,logoFile:ut,setLogoFile:bt,deanMessage:Ea,setDeanMessage:Re,deanPhotoFile:gt,setDeanPhotoFile:ht,milestones:Da,milestoneForm:Xe,setMilestoneForm:Ze,openModal:ne,setMilestones:Ge,visionMission:Ba,setVmForm:ea,coreValues:Ua,setCvForm:aa,aboutImages:Fa,setAboutImages:Me,aboutImageFiles:ft,setAboutImageFiles:jt,historyContent:za,setHistoryContent:He,axiosInstance:N,notify:U,del:ie}),a==="Admission"&&e.jsx(Ci,{admSub:o,setAdmSub:i,courses:_a,openModal:ne,setCourseForm:ta,del:ie,admissionSteps:qa,setStepForm:ia,admissionRules:Ga,setRuleForm:sa,bonds:Oa,setBondForm:ra,guidelines:Ha,setGuidelineForm:na,announcements:Ke,setAnnouncementForm:Be}),a==="Announcement"&&e.jsx(Aa,{announcements:Ke,setAnnouncementForm:Be,openModal:ne,del:ie}),a==="Departments"&&e.jsx(ki,{selectedDept:D,setSelectedDept:E,departments:Ve,deptForm:la,setDeptForm:oa,deptSub:s,setDeptSub:b,deptFacultyForm:ot,setDeptFacultyForm:dt,deptFacilityInput:ct,setDeptFacilityInput:pt,deptActivityInput:xt,setDeptActivityInput:mt,sliders:S,axiosInstance:N,fetchData:O,notify:U,openModal:ne,del:ie,handleSliderUpload:ha}),a==="Gallery"&&e.jsx(Di,{galleryImages:yt,galleryForm:da,setGalleryForm:ca,openModal:ne,del:ie}),a==="Institutes"&&e.jsx(Ei,{institutes:Ka,openModal:ne,del:ie}),a==="Student Corner"&&e.jsx(hi,{sections:Ct,openModal:ne,setScForm:ga,del:ie}),a==="Contact Us"&&e.jsx(Bi,{contactSub:m,setContactSub:k,keyPersons:Ia,setKeyPersonForm:pa,contactDepartments:Qa,setContactDeptForm:xa,contactInfo:Za,setContactInfo:We,openModal:ne,del:ie,notify:U,axiosInstance:N}),a==="Settings"&&e.jsxs("div",{className:"flex flex-col items-center justify-center py-32 text-center text-slate-400",children:[e.jsx(fa,{size:48,className:"mb-4 opacity-30"}),e.jsx("p",{className:"font-semibold",children:"Settings Console — feature coming soon"})]})]},a+(D?._id||""))})]})})]}),e.jsxs(Ca,{show:T,onClose:W,title:ua.title,subtitle:ua.subtitle,children:[B==="program"&&e.jsx(ii,{editItem:j,programForm:et,setProgramForm:Ie,closeModal:W,fetchData:O,notify:U}),B==="testimonial"&&e.jsx(si,{editItem:j,testimonialForm:Je,setTestimonialForm:Qe,closeModal:W,fetchData:O,notify:U}),B==="milestone"&&e.jsx(ri,{editItem:j,milestoneForm:Xe,setMilestoneForm:Ze,closeModal:W,fetchData:O,notify:U}),B==="visionMission"&&e.jsx(ni,{editItem:j,vmForm:at,setVmForm:ea,closeModal:W,fetchData:O,notify:U}),B==="coreValue"&&e.jsx(li,{editItem:j,cvForm:tt,setCvForm:aa,closeModal:W,fetchData:O,notify:U}),B==="course"&&e.jsx(oi,{editItem:j,courseForm:it,setCourseForm:ta,closeModal:W,fetchData:O,notify:U}),B==="step"&&e.jsx(di,{editItem:j,stepForm:st,setStepForm:ia,closeModal:W,fetchData:O,notify:U}),B==="rule"&&e.jsx(ci,{editItem:j,ruleForm:rt,setRuleForm:sa,closeModal:W,fetchData:O,notify:U}),B==="bond"&&e.jsx(pi,{editItem:j,bondForm:nt,setBondForm:ra,closeModal:W,fetchData:O,notify:U}),B==="guideline"&&e.jsx(xi,{editItem:j,guidelineForm:lt,setGuidelineForm:na,closeModal:W,fetchData:O,notify:U}),B==="department"&&e.jsx(mi,{editItem:j,deptForm:la,setDeptForm:oa,closeModal:W,fetchData:O,notify:U}),B==="gallery"&&e.jsx(Ai,{editItem:j,formState:da,setFormState:ca,closeModal:W,fetchData:O,notify:U,axiosInstance:N}),B==="institute"&&e.jsx(Si,{editItem:j,closeModal:W,fetchData:O,notify:U}),B==="keyPerson"&&e.jsx(Fi,{editItem:j,keyPersonForm:wt,setKeyPersonForm:pa,closeModal:W,fetchData:O,notify:U,axiosInstance:N}),B==="contactDept"&&e.jsx(zi,{editItem:j,contactDeptForm:Nt,setContactDeptForm:xa,closeModal:W,fetchData:O,notify:U,axiosInstance:N}),B==="studentCorner"&&e.jsx(gi,{editItem:j,scForm:kt,setScForm:ga,closeModal:W,fetchData:O,notify:U}),B==="announcement"&&e.jsx(ui,{editItem:j,announcementForm:At,setAnnouncementForm:Be,closeModal:W,fetchData:O,notify:U})]}),e.jsx(fi,{show:_,onClose:()=>Y(!1),notify:U})]})};export{_i as default};
