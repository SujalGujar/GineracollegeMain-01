import{c as ee,r as u,a as v,j as e,B as Ae,U as ge,I as Fe,b as ce,G as me,P as wt,A as fe,m as ie,d as xa,M as Nt,X as oe,u as Ct,E as De,C as kt,F as At,e as Dt,f as ma,g as Et,S as St,h as Ft}from"./index-jNgyShJ2.js";import{K as zt,C as ze,E as da}from"./key-round-DW_UF25j.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bt=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],Pt=ee("arrow-left",Bt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ut=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],de=ee("circle-check",Ut);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],Z=ee("image",$t);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _t=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],ve=ee("layers",_t);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tt=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],qt=ee("layout-dashboard",Tt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Lt=[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]],Ht=ee("log-out",Lt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]],Q=ee("pen-line",Ot);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rt=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],we=ee("plus",Rt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mt=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],Ne=ee("save",Mt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],Vt=ee("search",Gt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wt=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ca=ee("settings",Wt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yt=[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]],ga=ee("sliders-vertical",Yt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]],W=ee("trash-2",Kt);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]],re=ee("upload",Jt),n={brand:"#6B3F1D",accent:"#E07B39",accentSoft:"#FDF0E6",surface:"#FFFFFF",bg:"#F4F1EE",panel:"#FBFAF8",border:"#E8E0D8",text:"#1A1208",muted:"#8A7A6A",danger:"#DC2626",dangerSoft:"#FEF2F2",success:"#16A34A",successSoft:"#F0FDF4"},V=t=>Ft(t),ha=({children:t,color:a=n.accent})=>e.jsx("span",{style:{background:a+"20",color:a},className:"admin-pill text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",children:t}),M=({onClick:t,danger:a,children:r,className:l="",title:p})=>e.jsx("button",{onClick:t,type:"button",title:p,"aria-label":p,className:`admin-icon-btn p-2 rounded-lg transition-all hover:scale-105 active:scale-95 ${a?"is-danger bg-red-50 text-red-500 hover:bg-red-100":"bg-gray-100 text-gray-600 hover:bg-gray-200"} ${l}`,children:r}),It=({note:t,onDismiss:a})=>e.jsx(fe,{children:t&&e.jsxs(ie.div,{role:"status","aria-live":"polite",initial:{opacity:0,y:-18,scale:.97},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-18,scale:.97},transition:{type:"spring",stiffness:420,damping:28},className:"mx-4 mt-4 flex max-w-2xl items-center gap-3 rounded-2xl border p-3 shadow-lg md:mx-6 lg:mx-8",style:{background:"#FFFFFF",borderColor:t.type==="error"?"#FECACA":"#BBF7D0",boxShadow:"0 18px 40px rgba(26, 18, 8, 0.18)"},children:[e.jsx("div",{className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",style:{background:t.type==="error"?n.dangerSoft:n.successSoft,color:t.type==="error"?n.danger:n.success},children:t.type==="error"?e.jsx(ze,{size:21}):e.jsx(de,{size:21})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-[0.12em]",style:{color:t.type==="error"?n.danger:n.success},children:t.type==="error"?"Action needs attention":"Saved successfully"}),e.jsx("p",{className:"mt-0.5 break-words text-sm font-semibold leading-snug",style:{color:n.text},children:t.message})]}),e.jsx("button",{onClick:a,type:"button","aria-label":"Dismiss notification",className:"shrink-0 rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700",children:e.jsx(oe,{size:17})})]})}),x=({label:t,hint:a,required:r,children:l})=>e.jsxs("div",{className:"admin-field flex flex-col gap-1.5",children:[e.jsxs("div",{className:"admin-field-label flex items-center gap-1.5",children:[e.jsx("label",{className:"text-[13px] font-bold tracking-wide",style:{color:n.text},children:t}),r&&e.jsx("span",{className:"text-red-500 text-xs font-bold",children:"*"})]}),a&&e.jsx("p",{className:"text-[11px] leading-relaxed",style:{color:n.muted},children:a}),l]}),ke=({title:t,children:a})=>e.jsxs("div",{className:"space-y-4",children:[t&&e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"h-px flex-1",style:{background:n.border}}),e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.18em]",style:{color:n.muted},children:t}),e.jsx("div",{className:"h-px flex-1",style:{background:n.border}})]}),a]}),T="w-full px-4 py-3 rounded-xl border-2 bg-white text-sm text-gray-800 outline-none transition-all placeholder:text-gray-400",q={borderColor:"#E8E4DF"},ua="w-full py-3.5 rounded-xl text-sm font-bold text-white tracking-wide shadow-lg hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2",ba="flex-1 py-3.5 rounded-xl border-2 text-sm font-semibold text-gray-600 bg-white hover:bg-gray-50 transition-all",y=({className:t="",style:a={},...r})=>e.jsx("input",{...r,className:`${T} ${t} focus:border-amber-500 focus:ring-0`,style:{...q,...a}}),H=({className:t="",style:a={},...r})=>e.jsx("textarea",{...r,className:`${T} resize-none ${t} focus:border-amber-500 focus:ring-0`,style:{...q,...a}}),xe=({className:t="",style:a={},...r})=>e.jsx("select",{...r,className:`${T} ${t} focus:border-amber-500 focus:ring-0 cursor-pointer`,style:{...q,...a}}),fa=({show:t,onClose:a,title:r,subtitle:l,children:p})=>typeof document>"u"?null:xa.createPortal(e.jsx(fe,{children:t&&e.jsxs("div",{className:"admin-modal-overlay fixed inset-0 flex items-center justify-center p-4 sm:p-6",style:{fontFamily:"'DM Sans', sans-serif",zIndex:9999,minHeight:"100dvh",overflow:"hidden",padding:"clamp(14px, 2.4vw, 28px)"},children:[e.jsx("style",{children:`
            .form-scroll-container::-webkit-scrollbar {
              width: 8px !important;
              display: block !important;
            }
            .form-scroll-container::-webkit-scrollbar-track {
              background: #F0ECE7 !important;
              border-radius: 8px !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb {
              background: #6B3F1D !important;
              border-radius: 8px !important;
              border: 2px solid #F0ECE7 !important;
            }
            .form-scroll-container::-webkit-scrollbar-thumb:hover {
              background: #4A2B14 !important;
            }
            .form-scroll-container {
              overflow-y: auto !important;
              scrollbar-width: thin !important;
              scrollbar-color: #6B3F1D #F0ECE7 !important;
              -webkit-overflow-scrolling: touch;
              overscroll-behavior: contain;
              min-height: 0;
            }
            .admin-modal-overlay {
              align-items: center !important;
              justify-content: center !important;
              inset: 0 !important;
              width: 100vw !important;
              min-height: 100dvh !important;
            }
            .admin-modal-card {
              margin: 0 auto !important;
              width: min(720px, calc(100vw - 32px)) !important;
              max-height: calc(100dvh - 32px) !important;
              height: auto !important;
              border-radius: 18px !important;
              box-shadow: 0 30px 80px rgba(26, 18, 8, 0.32) !important;
            }
            .admin-modal-header {
              padding: 20px 24px !important;
              min-height: 78px;
              gap: 18px;
            }
            .admin-modal-header h3,
            .admin-modal-header p {
              margin: 0;
            }
            .admin-modal-header h3 {
              font-size: 18px !important;
              line-height: 1.2 !important;
            }
            .admin-modal-header p {
              margin-top: 6px !important;
              line-height: 1.35 !important;
            }
            .admin-modal-body {
              padding: 24px !important;
              max-height: calc(100dvh - 110px) !important;
              background: #FAFAF9 !important;
            }
            .admin-modal-body form .grid {
              display: grid !important;
              grid-template-columns: minmax(0, 1fr) !important;
              gap: 16px !important;
            }
            .admin-modal-body form {
              display: flex;
              flex-direction: column;
              gap: 22px;
            }
            .admin-modal-body form > * {
              margin-top: 0 !important;
              margin-bottom: 0 !important;
            }
            .admin-field {
              gap: 9px !important;
              min-width: 0;
            }
            .admin-field-label {
              min-height: 20px;
              align-items: center;
            }
            .admin-field-label label {
              line-height: 1.35 !important;
            }
            .admin-modal-body input,
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body label {
              max-width: 100%;
            }
            .admin-modal-body input,
            .admin-modal-body select,
            .admin-modal-body textarea,
            .admin-modal-body .admin-field > label {
              min-height: 46px;
            }
            .admin-form-actions {
              position: sticky;
              bottom: -24px;
              z-index: 2;
              background: linear-gradient(180deg, rgba(250,250,249,0.88), #FAFAF9 35%);
              padding-top: 18px !important;
              padding-bottom: 2px;
            }
            .admin-form-actions button {
              min-height: 46px;
            }
            @media (min-width: 760px) {
              .admin-modal-body form .grid {
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
              }
              .admin-modal-body form .grid-cols-1 {
                grid-template-columns: minmax(0, 1fr) !important;
              }
            }
            @media (min-width: 1024px) {
              .admin-modal-overlay {
                padding: 28px !important;
              }
            }
            @media (max-width: 640px) {
              .admin-modal-card {
                border-radius: 14px !important;
                width: calc(100vw - 24px) !important;
                max-height: calc(100dvh - 24px) !important;
              }
              .admin-modal-header {
                padding: 16px !important;
                min-height: auto;
              }
              .admin-modal-body {
                padding: 16px !important;
                max-height: calc(100dvh - 88px) !important;
              }
              .admin-form-actions {
                flex-direction: column;
                bottom: -16px;
              }
              .admin-form-actions button {
                width: 100%;
                min-width: 0 !important;
              }
            }
          `}),e.jsx(ie.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:a,className:"fixed inset-0 bg-black/60 backdrop-blur-[3px]",style:{zIndex:0}}),e.jsxs(ie.div,{initial:{opacity:0,scale:.94,y:-20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.94,y:-20},transition:{duration:.22,ease:[.16,1,.3,1]},className:"admin-modal-card relative w-full rounded-2xl shadow-2xl overflow-hidden flex flex-col",style:{background:"#fff",zIndex:1,width:"min(720px, calc(100vw - 32px))",maxWidth:"720px",maxHeight:"calc(100dvh - 32px)",height:"auto",minHeight:0},children:[e.jsxs("div",{className:"admin-modal-header flex items-start justify-between px-7 py-5 border-b shrink-0",style:{borderColor:"#EDE9E4",background:"linear-gradient(135deg, #6B3F1D 0%, #8B5E3C 100%)"},children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-[17px] font-bold text-white leading-tight",children:r}),l&&e.jsx("p",{className:"text-sm mt-1 text-white/70",children:l})]}),e.jsx("button",{type:"button",onClick:a,className:"p-2 rounded-xl border border-white/20 hover:bg-white/10 transition shrink-0 ml-4 mt-0.5",children:e.jsx(oe,{size:18,className:"text-white"})})]}),e.jsx("div",{className:"admin-modal-body px-6 sm:px-7 py-6 overflow-y-auto form-scroll-container flex-1",style:{background:"#FAFAF9",minHeight:0},children:p})]})]})}),document.body),ja="flex items-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed bg-white cursor-pointer hover:bg-amber-50 hover:border-amber-400 transition-all text-sm font-medium",Y=({onCancel:t,submitLabel:a="Save Changes"})=>e.jsxs("div",{className:"admin-form-actions flex flex-col-reverse gap-3 pt-5 mt-2 border-t sm:flex-row sm:items-center sm:justify-end",style:{borderColor:"#EDE9E4"},children:[e.jsx("button",{type:"button",onClick:t,className:`${ba} w-full sm:w-auto`,style:{borderColor:"#D1C7BC",minWidth:"120px"},children:"Cancel"}),e.jsxs("button",{type:"submit",className:`${ua} w-full sm:w-auto sm:min-w-[180px]`,style:{background:"linear-gradient(135deg, #6B3F1D 0%, #9B6A43 100%)",justifyContent:"center"},children:[e.jsx(Ne,{size:16}),a]})]}),Qt=({editItem:t,programForm:a,setProgramForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a cover image","error");const s=new FormData;s.append("title",a.title||""),s.append("description",a.description||""),s.append("duration",a.duration||""),s.append("category",a.category||"Undergraduate"),s.append("courses",JSON.stringify(typeof a.courses=="string"?a.courses.split(",").map(m=>m.trim()).filter(Boolean):a.courses||[])),a.image instanceof File&&s.append("image",a.image);const b=t?`/programs/${t._id}`:"/programs";try{t?await v.put(b,s):await v.post(b,s),o(t?"Updated":"Created"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Program Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})}),e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate"}),e.jsx("option",{children:"Postgraduate"}),e.jsx("option",{children:"Diploma"})]})})]}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(H,{required:!0,rows:3,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Describe the program objectives, curriculum overview…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Duration",children:e.jsx(y,{value:a.duration,onChange:i=>r({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsxs(x,{label:"Cover Image",children:[e.jsxs("label",{className:ja,style:{color:"#6B7280"},children:[e.jsx(Z,{size:16,style:{color:n.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose image file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>r({...a,image:i.target.files[0]})})]}),a.image instanceof File?e.jsx("img",{src:URL.createObjectURL(a.image),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"preview"}):t?.imageUrl?e.jsx("img",{src:V(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border-2 shadow-sm",alt:"current"}):null]})]}),e.jsx(x,{label:"Courses (comma separated)",hint:"e.g.  Anatomy, Physiology, Microbiology",children:e.jsx(H,{rows:2,value:a.courses,onChange:i=>r({...a,courses:i.target.value})})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Create Program"})]}),Xt=({editItem:t,testimonialForm:a,setTestimonialForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{if(i.preventDefault(),!t&&!a.image)return o("Please select a photo","error");const s=new FormData;Object.entries(a).forEach(([m,k])=>{m==="image"&&k instanceof File?s.append("image",k):m!=="image"&&s.append(m,k)});const b=t?`/testimonials/${t._id}`:"/testimonials";try{t?await v.put(b,s):await v.post(b,s),o(t?"Updated":"Created"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Student Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"Full name"})}),e.jsx(x,{label:"Role / Batch",required:!0,children:e.jsx(y,{required:!0,value:a.role,onChange:i=>r({...a,role:i.target.value}),placeholder:"e.g. B.Sc. Nursing 2023"})})]}),e.jsx(x,{label:"Testimonial",required:!0,children:e.jsx(H,{required:!0,rows:4,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Student's review about the college…"})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Rating (1–5)",children:e.jsx(y,{type:"number",min:1,max:5,value:a.rating,onChange:i=>r({...a,rating:parseInt(i.target.value)})})}),e.jsx(x,{label:"Student Photo",children:e.jsxs("label",{className:ja,style:{color:"#6B7280"},children:[e.jsx(Z,{size:16,style:{color:n.accent}}),e.jsx("span",{children:a.image instanceof File?a.image.name:"Choose photo file"}),e.jsx("input",{type:"file",className:"hidden",onChange:i=>r({...a,image:i.target.files[0]})})]})})]}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Testimonial"})]}),Zt=({editItem:t,milestoneForm:a,setMilestoneForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/milestones/${t._id}`:"/about/milestones";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[e.jsx(x,{label:"Year",required:!0,children:e.jsx(y,{required:!0,value:a.year,onChange:i=>r({...a,year:i.target.value}),placeholder:"1963"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",min:"0",step:"1",value:a.order,onChange:i=>r({...a,order:Math.max(0,parseInt(i.target.value,10)||0)})})})]}),e.jsx(x,{label:"Event Title",required:!0,children:e.jsx(y,{required:!0,value:a.event,onChange:i=>r({...a,event:i.target.value}),placeholder:"e.g. College Established"})}),e.jsx(x,{label:"Accent Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:i=>r({...a,color:i.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.color,onChange:i=>r({...a,color:i.target.value})})]})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(H,{required:!0,rows:3,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of this milestone…"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Milestone"})]}),ei=({editItem:t,vmForm:a,setVmForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/vision-mission/${t._id}`:"/about/vision-mission";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Statement Type",children:e.jsxs(xe,{value:a.type,onChange:i=>r({...a,type:i.target.value}),children:[e.jsx("option",{value:"vision",children:"🔭 Vision"}),e.jsx("option",{value:"mission",children:"🎯 Mission"})]})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",value:a.order||0,onChange:i=>r({...a,order:parseInt(i.target.value)||0})})})]}),e.jsx(x,{label:"Content",required:!0,children:e.jsx(H,{required:!0,rows:5,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Enter the statement content…"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Statement"})]}),ai=({editItem:t,cvForm:a,setCvForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/about/core-values/${t._id}`:"/about/core-values";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Value Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Excellence"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})})]}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(H,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of this value…"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Core Value"})]}),ti=({editItem:t,courseForm:a,setCourseForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/courses/${t._id}`:"/courses",b={...a,highlights:typeof a.highlights=="string"?a.highlights.split(",").map(m=>m.trim()).filter(Boolean):a.highlights};try{t?await v.put(s,b):await v.post(s,b),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx("div",{className:"sm:col-span-2",children:e.jsx(x,{label:"Course Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"e.g. B.Sc. Nursing"})})}),e.jsx(x,{label:"Icon",children:e.jsx(y,{value:a.icon,onChange:i=>r({...a,icon:i.target.value})})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"Undergraduate Programs"}),e.jsx("option",{children:"Postgraduate Programs"}),e.jsx("option",{children:"Diploma Programs"})]})}),e.jsx(x,{label:"Duration",children:e.jsx(y,{value:a.duration,onChange:i=>r({...a,duration:i.target.value}),placeholder:"e.g. 4 Years"})}),e.jsx(x,{label:"Seats",children:e.jsx(y,{value:a.seats,onChange:i=>r({...a,seats:i.target.value}),placeholder:"e.g. 60"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Annual Fees",children:e.jsx(y,{value:a.fees,onChange:i=>r({...a,fees:i.target.value}),placeholder:"e.g. ₹50,000"})}),e.jsx(x,{label:"Official Website Link",children:e.jsx(y,{value:a.websiteLink,onChange:i=>r({...a,websiteLink:i.target.value}),placeholder:"https://…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Brief Description",children:e.jsx(H,{rows:3,value:a.description||"",onChange:i=>r({...a,description:i.target.value}),placeholder:"Short overview of the course…"})}),e.jsx(x,{label:"Eligibility",children:e.jsx(H,{rows:3,value:a.eligibility,onChange:i=>r({...a,eligibility:i.target.value}),placeholder:"Who can apply…"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Highlights",hint:"Comma separated",children:e.jsx(H,{rows:2,value:a.highlights,onChange:i=>r({...a,highlights:i.target.value})})}),e.jsx(x,{label:"Admission Method",children:e.jsx(H,{rows:2,value:a.admission||"",onChange:i=>r({...a,admission:i.target.value})})})]}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Course"})]}),ii=({editItem:t,stepForm:a,setStepForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/admission-steps/${t._id}`:"/admission-steps";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(x,{label:"Step Number",required:!0,children:e.jsx(y,{type:"number",required:!0,value:a.step,onChange:i=>r({...a,step:parseInt(i.target.value)})})}),e.jsx(x,{label:"Icon",children:e.jsx(xe,{value:a.icon,onChange:i=>r({...a,icon:i.target.value}),children:["Calendar","Users","CheckCircle","GraduationCap","FileText","Download"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(x,{label:"Step Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Submit Application Form"})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(H,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Explain what the applicant needs to do in this step…"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Step"})]}),si=({editItem:t,ruleForm:a,setRuleForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/admission-rules/${t._id}`:"/admission-rules";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:[e.jsx("option",{children:"UnderGraduated Programs"}),e.jsx("option",{children:"PostGraduated Programs"}),e.jsx("option",{children:"General Rules"})]})}),e.jsx(x,{label:"Icon",children:e.jsx(xe,{value:a.icon,onChange:i=>r({...a,icon:i.target.value}),children:["CheckCircle","Calendar","Stethoscope","GraduationCap","Info"].map(i=>e.jsx("option",{children:i},i))})})]}),e.jsx(x,{label:"Rule Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Minimum Percentage Required"})}),e.jsx(x,{label:"Description",required:!0,children:e.jsx(H,{required:!0,rows:4,value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Full explanation of this rule…"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Rule"})]}),ri=({editItem:t,bondForm:a,setBondForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=t?`/bonds/${t._id}`:"/bonds";try{t?await v.put(s,a):await v.post(s,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsx(x,{label:"Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:i=>r({...a,title:i.target.value}),placeholder:"e.g. Government Bond Agreement"})}),e.jsx(x,{label:"Content",required:!0,children:e.jsx(H,{required:!0,rows:5,value:a.content,onChange:i=>r({...a,content:i.target.value}),placeholder:"Bond details and conditions…"})}),e.jsx(x,{label:"Display Order",children:e.jsx(y,{type:"number",value:a.order,onChange:i=>r({...a,order:parseInt(i.target.value)||0})})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Bond"})]}),ni=({editItem:t,guidelineForm:a,setGuidelineForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s={...a,points:typeof a.points=="string"?a.points.split(`
`).map(m=>m.trim()).filter(Boolean):a.points},b=t?`/guidelines/${t._id}`:"/guidelines";try{t?await v.put(b,s):await v.post(b,s),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Category",children:e.jsx(xe,{value:a.category,onChange:i=>r({...a,category:i.target.value}),children:["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(i=>e.jsx("option",{children:i},i))})}),e.jsx(x,{label:"Sub-Category / Title",required:!0,children:e.jsx(y,{required:!0,value:a.subCategory,onChange:i=>r({...a,subCategory:i.target.value}),placeholder:"e.g. Dress Code Policy"})})]}),e.jsx(x,{label:"Points",hint:"Enter one point per line — each line becomes a separate bullet",children:e.jsx(H,{required:!0,rows:7,value:a.points,onChange:i=>r({...a,points:i.target.value}),placeholder:`Guideline point 1
Guideline point 2
Guideline point 3`})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Guideline"})]}),li=({editItem:t,deptForm:a,setDeptForm:r,closeModal:l,fetchData:p,notify:o})=>e.jsxs("form",{onSubmit:async i=>{i.preventDefault();const s=new FormData;s.append("name",a.name||""),s.append("slug",a.slug||""),s.append("category",a.category||"Nursing Department"),s.append("description",a.description||""),a.logo instanceof File&&s.append("logo",a.logo);const b=t?`/departments/${t._id}`:"/departments";try{t?await v.put(b,s):await v.post(b,s),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"flex flex-col items-center gap-3 py-5 px-6 rounded-2xl border-2 border-dashed",style:{borderColor:"#D1C7BC",background:"#FDFCFB"},children:[a.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(a.logo),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"preview"}):t?.logoUrl?e.jsx("img",{src:V(t.logoUrl),className:"w-20 h-20 rounded-2xl object-cover border-2 shadow-md",alt:"logo"}):e.jsx("div",{className:"w-20 h-20 rounded-2xl flex items-center justify-center text-4xl",style:{background:n.accentSoft},children:"🏥"}),e.jsxs("label",{className:"flex items-center gap-2 px-5 py-2.5 rounded-xl cursor-pointer text-sm font-semibold text-white shadow hover:opacity-90 transition-all",style:{background:n.brand},children:[e.jsx(re,{size:15}),a.logo instanceof File?"Change Logo":t?.logoUrl?"Replace Logo":"Upload Department Logo",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:i=>r({...a,logo:i.target.files[0]})})]}),e.jsx("p",{className:"text-xs",style:{color:n.muted},children:"PNG, JPG or WEBP · Recommended 200×200px"})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Department Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:i=>r({...a,name:i.target.value}),placeholder:"e.g. Fundamentals of Nursing"})}),e.jsx(x,{label:"URL Slug",hint:"Unique ID — no spaces",children:e.jsx(y,{required:!0,value:a.slug,onChange:i=>r({...a,slug:i.target.value.toLowerCase().replace(/\s+/g,"-")}),placeholder:"e.g. fundamentals"})})]}),e.jsx(x,{label:"Category",children:e.jsx(y,{required:!0,value:a.category,onChange:i=>r({...a,category:i.target.value}),placeholder:"e.g. Nursing Department"})}),e.jsx(x,{label:"Short Description",children:e.jsx(y,{value:a.description,onChange:i=>r({...a,description:i.target.value}),placeholder:"Brief description of the department"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Update Department":"Create Department"})]}),oi=({editItem:t,scForm:a,setScForm:r,closeModal:l,fetchData:p,notify:o})=>{const i=()=>r(m=>({...m,items:[...m.items||[],""]})),s=m=>r(k=>({...k,items:k.items.filter((h,w)=>w!==m)})),b=(m,k)=>r(h=>{const w=[...h.items||[]];return w[m]=k,{...h,items:w}});return e.jsxs("form",{onSubmit:async m=>{m.preventDefault();const k=t?`/student-corner/${t._id}`:"/student-corner";try{t?await v.put(k,a):await v.post(k,a),o(t?"Section updated":"Section created"),l(),p()}catch{o("Failed to save section","error")}},className:"space-y-5",children:[e.jsxs(ke,{title:"Section Details",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Section Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:m=>r({...a,title:m.target.value}),placeholder:"e.g. Documents for Transcript"})}),e.jsx(x,{label:"Subtitle",children:e.jsx(y,{value:a.subtitle,onChange:m=>r({...a,subtitle:m.target.value}),placeholder:"e.g. All Xerox Copies Required"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Tag / Badge Label",children:e.jsx(y,{value:a.tag,onChange:m=>r({...a,tag:m.target.value}),placeholder:"e.g. GNM Students"})}),e.jsx(x,{label:"Icon (emoji)",children:e.jsx(y,{value:a.icon,onChange:m=>r({...a,icon:m.target.value}),placeholder:"📄"})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",value:a.order,onChange:m=>r({...a,order:parseInt(m.target.value)||0})})})]}),e.jsx(x,{label:"Extra Description / Note",hint:"Optional note shown below the badge on the public page",children:e.jsx(H,{rows:2,value:a.description,onChange:m=>r({...a,description:m.target.value}),placeholder:"e.g. For GNM students completing their final year only"})})]}),e.jsx(ke,{title:"Colors",children:e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-4",children:[e.jsx(x,{label:"Main Color",hint:"Card accent & icon background",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.color,onChange:m=>r({...a,color:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.color,onChange:m=>r({...a,color:m.target.value})})]})}),e.jsx(x,{label:"Border Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.borderColor,onChange:m=>r({...a,borderColor:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.borderColor,onChange:m=>r({...a,borderColor:m.target.value})})]})}),e.jsx(x,{label:"Badge Color",children:e.jsxs("div",{className:"flex gap-3 items-center",children:[e.jsx("input",{type:"color",value:a.badgeColor,onChange:m=>r({...a,badgeColor:m.target.value}),className:"w-12 h-11 rounded-xl border-2 cursor-pointer shrink-0",style:{borderColor:"#E8E4DF"}}),e.jsx(y,{value:a.badgeColor,onChange:m=>r({...a,badgeColor:m.target.value})})]})})]})}),e.jsx(ke,{title:"Document Items",children:e.jsxs("div",{className:"space-y-2",children:[(a.items||[]).map((m,k)=>e.jsxs("div",{className:"flex gap-2 items-center",children:[e.jsx("span",{className:"w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0",style:{background:a.color||"#F59E0B"},children:k+1}),e.jsx(y,{value:m,onChange:h=>b(k,h.target.value),placeholder:`Document item ${k+1}`,className:"flex-1"}),e.jsx("button",{type:"button",onClick:()=>s(k),className:"p-2 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition-all shrink-0",children:e.jsx(W,{size:15})})]},k)),e.jsxs("button",{type:"button",onClick:i,className:"w-full py-2.5 rounded-xl border-2 border-dashed text-sm font-semibold transition-all hover:bg-amber-50",style:{borderColor:"#D1C7BC",color:"#8A7A6A"},children:[e.jsx(we,{size:15,className:"inline mr-1"})," Add Document Item"]})]})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Create Section"})]})},di=({sections:t,openModal:a,setScForm:r,del:l})=>{const p={title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0};return e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:me,title:"Student Corner — Document Sections",subtitle:"Manage document requirement notices shown on the Student Corner page",action:e.jsx(X,{label:"Add Section",onClick:()=>{r({...p,order:t.length+1}),a("studentCorner")}})}),t.length===0?e.jsx(he,{icon:me,text:"No document sections yet — click 'Add Section' to create one"}):e.jsx("div",{className:"space-y-3",children:t.map((o,i)=>e.jsxs("div",{className:"flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:"#FFFFFF",border:"1px solid #E8E0D8"},children:[e.jsx("div",{style:{width:"48px",height:"48px",borderRadius:"14px",background:o.color||"#F59E0B",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"22px",flexShrink:0,boxShadow:`0 4px 12px ${o.color||"#F59E0B"}44`},children:o.icon||"📄"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap mb-0.5",children:[o.tag&&e.jsx("span",{className:"text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md",style:{background:(o.badgeColor||"#D97706")+"22",color:o.badgeColor||"#D97706"},children:o.tag}),e.jsxs("span",{className:"text-[11px] font-semibold text-gray-400",children:["#",i+1," · ",(o.items||[]).length," items"]})]}),e.jsx("p",{className:"font-bold text-sm truncate",style:{color:"#1A1208"},children:o.title}),o.subtitle&&e.jsx("p",{className:"text-xs truncate mt-0.5",style:{color:"#8A7A6A"},children:o.subtitle})]}),e.jsx("div",{className:"hidden sm:flex gap-1.5 shrink-0",children:["color","borderColor","badgeColor"].map(s=>e.jsx("div",{style:{width:16,height:16,borderRadius:"50%",background:o[s]||"#ccc",border:"2px solid #F4F1EE"},title:s},s))}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[e.jsx(M,{title:"Edit",onClick:()=>{r({title:o.title||"",subtitle:o.subtitle||"",tag:o.tag||"",icon:o.icon||"📄",color:o.color||"#F59E0B",borderColor:o.borderColor||"#FCD34D",badgeColor:o.badgeColor||"#D97706",items:Array.isArray(o.items)?[...o.items]:[],description:o.description||"",order:o.order||0}),a("studentCorner",o)},children:e.jsx(Q,{size:15})}),e.jsx(M,{danger:!0,title:"Delete",onClick:()=>l(`/student-corner/${o._id}`),children:e.jsx(W,{size:15})})]})]},o._id))}),e.jsxs("div",{className:"p-4 rounded-2xl flex items-start gap-3",style:{background:"#FFF7ED",border:"1.5px solid #FDE68A"},children:[e.jsx("span",{className:"text-xl shrink-0",children:"💡"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-bold",style:{color:"#92400e"},children:"Tips"}),e.jsxs("ul",{className:"text-xs mt-1 space-y-1",style:{color:"#78350f"},children:[e.jsxs("li",{children:["• Use ",e.jsx("strong",{children:"Sort Order"})," when editing to control display order on the public page."]}),e.jsxs("li",{children:["• To hide Student Corner from the site, go to ",e.jsx("strong",{children:"Section Control"})," and toggle it off."]}),e.jsx("li",{children:"• Each section supports its own emoji icon, custom colors, badge label, and unlimited document items."})]})]})]})]})},Ee=({tabs:t,active:a,onChange:r})=>e.jsx("div",{className:"admin-subtabs",children:t.map(l=>e.jsx("button",{onClick:()=>r(l),type:"button",className:a===l?"is-active":"",children:l},l))}),K=({icon:t,title:a,subtitle:r,action:l})=>e.jsxs("div",{className:"admin-section-header flex flex-col sm:flex-row sm:items-center gap-4 p-5 rounded-2xl",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0",children:[e.jsx("div",{className:"admin-section-icon w-10 h-10 rounded-xl flex items-center justify-center shrink-0",style:{background:n.accentSoft},children:e.jsx(t,{size:20,style:{color:n.accent}})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h3",{className:"admin-section-title font-bold text-base truncate",style:{color:n.text},children:a}),r&&e.jsx("p",{className:"admin-section-subtitle text-xs mt-0.5 truncate",style:{color:n.muted},children:r})]})]}),l]}),X=({onClick:t,label:a="Add New"})=>e.jsxs("button",{onClick:t,className:"admin-add-btn shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition-all shadow hover:opacity-90 active:scale-95",style:{background:n.brand},children:[e.jsx(we,{size:16}),a]}),be=({icon:t,badge:a,title:r,sub:l,onEdit:p,onDelete:o,left:i})=>e.jsxs("div",{className:"admin-row-item flex items-center gap-4 p-4 rounded-2xl group transition-all hover:shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[i||e.jsx("div",{className:"admin-row-icon w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0",style:{background:n.accentSoft},children:t||"📌"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[a&&e.jsx("div",{className:"mb-0.5",children:e.jsx(ha,{children:a})}),e.jsx("p",{className:"admin-row-title font-bold text-sm truncate",style:{color:n.text},children:r}),l&&e.jsx("p",{className:"admin-row-subtitle text-xs truncate mt-0.5",style:{color:n.muted},children:l})]}),e.jsxs("div",{className:"admin-row-actions flex gap-1.5 opacity-0 group-hover:opacity-100 sm:opacity-100 transition-opacity shrink-0",children:[p&&e.jsx(M,{onClick:p,title:"Edit",children:e.jsx(Q,{size:15})}),o&&e.jsx(M,{onClick:o,danger:!0,title:"Delete",children:e.jsx(W,{size:15})})]})]}),he=({icon:t,text:a})=>e.jsxs("div",{className:"flex flex-col items-center justify-center py-20 rounded-3xl border-2 border-dashed shadow-inner",style:{borderColor:n.border,background:n.surface},children:[e.jsx(t,{size:48,style:{color:n.muted},className:"mb-4 opacity-10"}),e.jsx("p",{className:"text-sm font-bold tracking-tight",style:{color:n.muted},children:a})]}),pa=({onClose:t,activeTab:a,setActiveTab:r,selectedDept:l,setSelectedDept:p,navItems:o,onLogout:i})=>e.jsxs("div",{className:"flex flex-col min-h-0",style:{height:"100dvh",maxHeight:"100dvh"},children:[e.jsxs("div",{className:"flex items-center gap-3 p-6 border-b border-white/10 shrink-0",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shadow-inner",children:e.jsx(qt,{size:20,className:"text-white"})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-white font-bold text-sm leading-tight truncate",children:"Ginera Admin"}),e.jsx("p",{className:"text-white/40 text-[10px] uppercase tracking-widest mt-0.5 font-medium",children:"Dashboard Console"})]}),t&&e.jsx("button",{onClick:t,className:"lg:hidden p-2 text-white/40 hover:text-white transition-colors",children:e.jsx(oe,{size:20})})]}),e.jsxs("nav",{className:"flex-1 min-h-0 overflow-y-auto py-6 px-4 space-y-1 scrollbar-hide",style:{overscrollBehavior:"contain"},children:[o.map(({name:s,icon:b})=>{const m=a===s&&!l;return e.jsxs("button",{onClick:()=>{r(s),p(null),t&&t()},className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all group",style:{background:m?"rgba(255,255,255,0.12)":"transparent",color:m?"#fff":"rgba(255,255,255,0.55)"},children:[e.jsx(b,{size:18,className:`transition-transform ${m?"scale-110":"group-hover:scale-110"}`}),e.jsx("span",{className:"truncate",children:s}),m&&e.jsx(ma,{size:14,className:"ml-auto opacity-60"})]},s)}),l&&e.jsxs("div",{className:"mt-8 pt-6 border-t border-white/5 px-2",children:[e.jsx("p",{className:"text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-3 px-2",children:"Active Editor"}),e.jsxs("div",{className:"p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx("div",{className:"w-2 h-2 rounded-full bg-amber-400 animate-pulse"}),e.jsx("p",{className:"text-white text-xs font-bold truncate",children:l.name})]}),e.jsx("button",{onClick:()=>p(null),className:"w-full py-2.5 rounded-lg bg-white/10 text-[10px] font-bold text-white/70 hover:bg-white/20 transition-all border border-white/5 uppercase tracking-wider",children:"Exit Management"})]})]})]}),e.jsx("div",{className:"p-5 border-t border-white/10 shrink-0",children:e.jsxs("button",{onClick:i,className:"w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold text-red-300 hover:bg-red-500/20 transition-all active:scale-95",children:[e.jsx(Ht,{size:18})," Sign Out"]})})]}),ci=({isMobile:t,sidebarOpen:a,setSidebarOpen:r,...l})=>e.jsxs(e.Fragment,{children:[!t&&e.jsx("aside",{className:"admin-sidebar flex flex-col w-80 shrink-0 self-stretch border-r border-black/10",style:{background:n.brand,width:"320px",height:"100%",minHeight:"100dvh",maxHeight:"100dvh"},children:e.jsx(pa,{onClose:null,...l})}),t&&typeof document<"u"&&xa.createPortal(e.jsx(fe,{children:a&&e.jsxs(e.Fragment,{children:[e.jsx(ie.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>r(!1),className:"fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm",style:{position:"fixed",top:0,right:0,bottom:0,left:0}}),e.jsx(ie.aside,{initial:{x:-340},animate:{x:0},exit:{x:-340},transition:{type:"tween",duration:.3},className:"admin-sidebar fixed inset-y-0 left-0 z-[10000] w-80 flex flex-col shadow-2xl",style:{background:n.brand,position:"fixed",top:0,bottom:0,left:0,width:"min(320px, 86vw)",height:"100dvh",maxHeight:"100dvh",zIndex:1e4},children:e.jsx(pa,{onClose:()=>r(!1),...l})})]})}),document.body)]}),pi=({show:t,onClose:a,notify:r})=>{const[l,p]=u.useState(""),[o,i]=u.useState(""),[s,b]=u.useState(!1),[m,k]=u.useState(!1),[h,w]=u.useState(""),_=l.length>8,S=/[!@#$%^&*(),.?":{}|<>_\-+=\\/[\]~`]/.test(l),z=l.length>0&&l===o,F=_&&S&&z,P=()=>{p(""),i(""),b(!1),k(!1),w(""),a()},N=A=>{if(A.preventDefault(),!_){w("New password must be greater than 8 characters (at least 9 characters).");return}if(!S){w("New password must contain at least one unique special character (e.g., @, #, $, %, !).");return}if(l!==o){w("Passwords do not match. Please ensure both fields are identical.");return}localStorage.setItem("adminPassword",l),r("Admin password successfully updated!"),P()};return e.jsx(fa,{show:t,onClose:P,title:"Reset Admin Password",subtitle:"Update credentials to maintain secure administrative access",children:e.jsxs("form",{onSubmit:N,className:"space-y-4",children:[h&&e.jsxs("div",{className:"flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-semibold",children:[e.jsx(ze,{size:16,className:"shrink-0"}),e.jsx("span",{children:h})]}),e.jsx(x,{label:"New Password",required:!0,hint:"Must be greater than 8 characters with at least one unique special character",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:s?"text":"password",value:l,onChange:A=>{p(A.target.value),h&&w("")},placeholder:"Enter new strong password",className:T,style:{...q,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>b(A=>!A),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:s?"Hide password":"Show password",children:s?e.jsx(De,{size:18}):e.jsx(da,{size:18})})]})}),e.jsx(x,{label:"Confirm New Password",required:!0,hint:"Re-enter the exact same new password",children:e.jsxs("div",{className:"relative flex items-center",children:[e.jsx("input",{type:m?"text":"password",value:o,onChange:A=>{i(A.target.value),h&&w("")},placeholder:"Re-enter new password",className:T,style:{...q,paddingRight:"44px"},required:!0}),e.jsx("button",{type:"button",onClick:()=>k(A=>!A),className:"absolute right-3.5 text-gray-400 hover:text-gray-600 transition",title:m?"Hide password":"Show password",children:m?e.jsx(De,{size:18}):e.jsx(da,{size:18})})]})}),e.jsxs("div",{className:"p-3.5 rounded-xl border bg-amber-50/40 border-amber-200/60 space-y-2 text-xs",children:[e.jsx("p",{className:"font-bold text-gray-700 uppercase tracking-wider text-[11px]",children:"Password Security Requirements:"}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${_?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:_?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Greater than 8 characters (at least 9 characters long)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${S?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:S?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"At least 1 unique/special character (e.g. @, #, $, %, !, &, *)"})]}),e.jsxs("div",{className:`flex items-center gap-2 font-medium transition-colors ${z?"text-emerald-700":"text-gray-500"}`,children:[e.jsx(de,{size:15,className:z?"text-emerald-600":"text-gray-300"}),e.jsx("span",{children:"Passwords match in both fields"})]})]}),e.jsxs("div",{className:"admin-form-actions flex gap-3 pt-3",children:[e.jsx("button",{type:"button",onClick:P,className:ba,children:"Cancel"}),e.jsxs("button",{type:"submit",disabled:!F,className:ua,style:{background:F?n.brand:"#B5ACA2",cursor:F?"pointer":"not-allowed"},children:[e.jsx(St,{size:18}),"Reset Password"]})]})]})})},xi=({setSidebarOpen:t,selectedDept:a,activeTab:r,onOpenResetPassword:l})=>e.jsxs("header",{className:"admin-header h-14 lg:h-16 flex items-center px-4 lg:px-6 border-b shrink-0 z-10",style:{background:n.surface,borderColor:n.border},children:[e.jsx("button",{onClick:()=>t(!0),className:"p-2 rounded-xl hover:bg-gray-100 lg:hidden mr-3 transition",style:{color:n.muted},children:e.jsx(Nt,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h2",{className:"font-bold text-base lg:text-lg truncate",style:{color:n.text},children:a?a.name:r}),e.jsx("p",{className:"text-xs hidden sm:block",style:{color:n.muted},children:a?"Department management console":`Manage ${r.toLowerCase()} system content`})]}),e.jsxs("div",{className:"ml-auto flex items-center gap-2 sm:gap-3",children:[e.jsxs("button",{type:"button",onClick:l,title:"Reset Admin Password",className:"flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 rounded-xl border transition-all text-xs font-semibold shadow-xs hover:shadow-sm hover:scale-[1.02] active:scale-[0.98]",style:{background:"#FFF8F3",borderColor:"#EAD5C5",color:n.brand},children:[e.jsx(zt,{size:15,style:{color:n.accent}}),e.jsx("span",{className:"hidden sm:inline",children:"Reset Password"})]}),e.jsxs("span",{className:"admin-header-chip hidden md:inline-flex",children:[e.jsx("span",{className:"admin-header-dot"}),"Live Admin"]})]})]}),mi=({selectedDeptForSlider:t,setSelectedDeptForSlider:a,departments:r,sliders:l,handleSliderUpload:p,updateSliderImage:o,del:i})=>{const s=l.filter(h=>t==="null"?!h.department:h.department?._id===t),b=t==="null"?"Homepage Sliders":r.find(h=>h._id===t)?.name||"Department Sliders",m=(h,w)=>`${t==="null"?"Homepage Slider":`${r.find(S=>S._id===t)?.name||"Department"} Slider`} #${w+1}`,k=h=>h.createdAt?new Date(h.createdAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}):"Recent Upload";return e.jsxs("div",{className:"home-manager-shell",children:[e.jsx("style",{children:`
        .home-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .home-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .home-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .home-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .home-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .home-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .home-manager-subtitle {
          margin: 8px 0 0;
          max-width: 620px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .home-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .home-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .home-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .home-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .home-manager-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 16px;
          align-items: end;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .home-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .home-manager-select-wrap {
          position: relative;
        }
        .home-manager-select-wrap select {
          width: 100%;
          height: 46px;
          appearance: none;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 750;
          outline: none;
          padding: 0 42px 0 14px;
          cursor: pointer;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .home-manager-select-wrap select:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .home-manager-select-wrap svg {
          position: absolute;
          right: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #7A6A5B;
          pointer-events: none;
        }
        .home-manager-upload {
          height: 46px;
          min-width: 168px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .home-manager-upload:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .home-manager-upload input,
        .home-manager-action input {
          display: none;
        }
        .home-manager-content {
          padding: 18px;
        }
        .home-manager-section-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .home-manager-section-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .home-manager-section-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .home-manager-target-badge {
          max-width: 260px;
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 7px 11px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          flex: 0 0 auto;
        }
        .home-manager-empty {
          min-height: 320px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 36px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .home-manager-empty-icon {
          width: 64px;
          height: 64px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(107, 63, 29, 0.08);
          margin-bottom: 16px;
        }
        .home-manager-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .home-manager-empty p {
          margin: 8px 0 18px;
          max-width: 380px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .home-manager-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: 16px;
        }
        .home-slider-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          overflow: hidden;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          display: flex;
          flex-direction: column;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .home-slider-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .home-slider-media {
          position: relative;
          aspect-ratio: 16 / 10;
          background: #F3EFEA;
          overflow: hidden;
        }
        .home-slider-media img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 260ms ease;
        }
        .home-slider-card:hover .home-slider-media img {
          transform: scale(1.035);
        }
        .home-slider-overlay {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: rgba(26, 18, 8, 0.18);
          opacity: 0;
          transition: opacity 180ms ease;
          pointer-events: none;
        }
        .home-slider-card:hover .home-slider-overlay {
          opacity: 1;
        }
        .home-slider-overlay span {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: rgba(255,255,255,0.18);
          backdrop-filter: blur(8px);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.18);
        }
        .home-slider-body {
          padding: 14px;
          display: flex;
          flex: 1 1 auto;
          flex-direction: column;
          justify-content: space-between;
          gap: 14px;
        }
        .home-slider-body h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .home-slider-body p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .home-manager-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 9px;
          padding-top: 12px;
          border-top: 1px solid #EFE7DF;
        }
        .home-manager-action {
          height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          font-size: 12px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .home-manager-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .home-manager-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        @media (max-width: 920px) {
          .home-manager-hero,
          .home-manager-toolbar {
            grid-template-columns: 1fr;
          }
          .home-manager-stats {
            min-width: 0;
          }
          .home-manager-upload {
            width: 100%;
          }
        }
        @media (max-width: 560px) {
          .home-manager-hero,
          .home-manager-toolbar,
          .home-manager-content {
            padding: 14px;
          }
          .home-manager-title {
            font-size: 21px;
          }
          .home-manager-title-row {
            align-items: flex-start;
          }
          .home-manager-stats {
            grid-template-columns: 1fr;
          }
          .home-manager-section-head {
            flex-direction: column;
          }
          .home-manager-target-badge {
            max-width: 100%;
          }
          .home-manager-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),e.jsxs("div",{className:"home-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"home-manager-title-row",children:[e.jsx("div",{className:"home-manager-icon",children:e.jsx(Z,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"home-manager-kicker",children:"Homepage Media"}),e.jsx("h1",{className:"home-manager-title",children:"Home Page Management"})]})]}),e.jsx("p",{className:"home-manager-subtitle",children:"Manage homepage banner and department slider images with a cleaner preview-first workflow."})]}),e.jsxs("div",{className:"home-manager-stats",children:[e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:s.length}),e.jsx("span",{children:"Shown Here"})]}),e.jsxs("div",{className:"home-manager-stat",children:[e.jsx("strong",{children:l.length}),e.jsx("span",{children:"Total Images"})]})]})]}),e.jsxs("div",{className:"home-manager-panel",children:[e.jsxs("div",{className:"home-manager-toolbar",children:[e.jsxs("div",{className:"home-manager-field",children:[e.jsx("label",{children:"Target Section"}),e.jsxs("div",{className:"home-manager-select-wrap",children:[e.jsxs("select",{value:t,onChange:h=>a(h.target.value),children:[e.jsx("option",{value:"null",children:"Homepage Sliders"}),r.map(h=>e.jsx("option",{value:h._id,children:h.name},h._id))]}),e.jsx(kt,{size:17})]})]}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(re,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:p})]})]}),e.jsxs("div",{className:"home-manager-content",children:[e.jsxs("div",{className:"home-manager-section-head",children:[e.jsxs("div",{children:[e.jsx("h3",{children:"Gallery Images"}),e.jsx("p",{children:"Replace or remove images currently attached to this slider group."})]}),e.jsx("span",{className:"home-manager-target-badge",children:b})]}),s.length===0?e.jsxs("div",{className:"home-manager-empty",children:[e.jsx("div",{className:"home-manager-empty-icon",children:e.jsx(re,{size:30})}),e.jsx("h4",{children:"No Images Uploaded"}),e.jsx("p",{children:"Upload images for this section. A 16:9 image works best for public slider banners."}),e.jsxs("label",{className:"home-manager-upload",children:[e.jsx(re,{size:17}),"Upload Images",e.jsx("input",{type:"file",multiple:!0,onChange:p})]})]}):e.jsx("div",{className:"home-manager-grid",children:e.jsx(fe,{children:s.map((h,w)=>e.jsxs(ie.div,{layout:!0,initial:{opacity:0,y:10},animate:{opacity:1,y:0},exit:{opacity:0,scale:.96},className:"home-slider-card",children:[e.jsxs("div",{className:"home-slider-media",children:[e.jsx("img",{src:V(h.imageUrl),alt:m(h,w)}),e.jsx("div",{className:"home-slider-overlay",children:e.jsx("span",{children:e.jsx(Z,{size:18})})})]}),e.jsxs("div",{className:"home-slider-body",children:[e.jsxs("div",{children:[e.jsx("h4",{title:m(h,w),children:m(h,w)}),e.jsxs("p",{children:["Uploaded: ",k(h)]})]}),e.jsxs("div",{className:"home-manager-actions",children:[e.jsxs("label",{className:"home-manager-action",children:[e.jsx(Q,{size:13}),"Replace",e.jsx("input",{type:"file",onChange:_=>{const S=_.target.files?.[0];S&&o(h._id,S)}})]}),e.jsxs("button",{type:"button",className:"home-manager-action danger",onClick:()=>i(`/sliders/${h._id}`),children:[e.jsx(W,{size:13}),"Delete"]})]})]})]},h._id))})})]})]})]})},gi=({programs:t,academicContent:a,setAcademicContent:r,axiosInstance:l,notify:p,openModal:o,setProgramForm:i,del:s})=>{const b=new Set(t.map(h=>h.category).filter(Boolean)).size,m=()=>{i({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),o("program")},k=h=>{i({title:h.title,description:h.description,duration:h.duration,category:h.category,courses:h.courses?.join(", ")||"",image:null}),o("program",h)};return e.jsxs("div",{className:"academic-manager-shell",children:[e.jsx("style",{children:`
        .academic-manager-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .academic-manager-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: center;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .academic-manager-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .academic-manager-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .academic-manager-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .academic-manager-subtitle {
          margin: 8px 0 0;
          max-width: 650px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .academic-manager-top-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .academic-manager-add {
          height: 44px;
          border: 0;
          border-radius: 12px;
          padding: 0 16px;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%);
          box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-add:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 30px rgba(107, 63, 29, 0.25);
        }
        .academic-manager-stats {
          display: grid;
          grid-template-columns: repeat(2, minmax(116px, 1fr));
          gap: 10px;
          min-width: 260px;
        }
        .academic-manager-stat {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .academic-manager-stat strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .academic-manager-stat span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .academic-manager-panel {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .academic-manager-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .academic-manager-panel-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .academic-manager-panel-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .academic-manager-panel-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 17px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-manager-panel-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .academic-manager-form {
          padding: 18px;
          display: grid;
          gap: 14px;
        }
        .academic-manager-field label {
          display: block;
          margin: 0 0 8px 1px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .academic-manager-field input,
        .academic-manager-field textarea {
          width: 100%;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 12px 14px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .academic-manager-field input {
          height: 46px;
        }
        .academic-manager-field textarea {
          min-height: 94px;
          resize: vertical;
          line-height: 1.55;
        }
        .academic-manager-field input:focus,
        .academic-manager-field textarea:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .academic-manager-save {
          justify-self: start;
          height: 42px;
          border: 0;
          border-radius: 11px;
          padding: 0 16px;
          color: #FFFFFF;
          background: #6B3F1D;
          box-shadow: 0 10px 20px rgba(107, 63, 29, 0.18);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }
        .academic-manager-save:hover {
          transform: translateY(-1px);
          box-shadow: 0 14px 26px rgba(107, 63, 29, 0.24);
        }
        .academic-programs-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          margin-bottom: 16px;
        }
        .academic-programs-head h3 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 900;
        }
        .academic-programs-head p {
          margin: 5px 0 0;
          color: #8A7A6A;
          font-size: 13px;
          font-weight: 650;
        }
        .academic-programs-wrap {
          padding: 18px;
        }
        .academic-programs-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(310px, 1fr));
          gap: 16px;
        }
        .academic-program-card {
          min-width: 0;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06);
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          transition: transform 170ms ease, box-shadow 170ms ease, border-color 170ms ease;
        }
        .academic-program-card:hover {
          transform: translateY(-2px);
          border-color: #D7C3AE;
          box-shadow: 0 18px 36px rgba(65, 42, 22, 0.11);
        }
        .academic-program-top {
          display: grid;
          grid-template-columns: 82px minmax(0, 1fr) auto;
          gap: 13px;
          align-items: start;
        }
        .academic-program-image {
          width: 82px;
          aspect-ratio: 1;
          border-radius: 14px;
          overflow: hidden;
          background: #F3EFEA;
          border: 1px solid #EFE7DF;
          flex: 0 0 auto;
        }
        .academic-program-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }
        .academic-program-main {
          min-width: 0;
        }
        .academic-program-main h4 {
          margin: 0;
          color: #1A1208;
          font-size: 15px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .academic-program-meta {
          display: flex;
          flex-wrap: wrap;
          gap: 7px;
          margin-top: 9px;
        }
        .academic-program-pill {
          border: 1px solid #E7DDD2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-duration {
          border: 1px solid #DDE7F2;
          border-radius: 999px;
          padding: 6px 9px;
          color: #536C8D;
          background: #F6FAFE;
          font-size: 11px;
          font-weight: 900;
          line-height: 1;
        }
        .academic-program-actions {
          display: flex;
          align-items: center;
          gap: 7px;
        }
        .academic-program-action {
          width: 34px;
          height: 34px;
          border: 1px solid #E6DCD1;
          border-radius: 10px;
          background: #FBFAF8;
          color: #1A1208;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .academic-program-action:hover {
          transform: translateY(-1px);
          background: #6B3F1D;
          border-color: #6B3F1D;
          color: #FFFFFF;
        }
        .academic-program-action.danger:hover {
          background: #B42318;
          border-color: #B42318;
        }
        .academic-program-desc {
          margin: 0;
          min-height: 42px;
          color: #786859;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.55;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .academic-program-empty {
          min-height: 260px;
          border: 2px dashed #E6DCD1;
          border-radius: 16px;
          background: #FBFAF8;
          text-align: center;
          padding: 34px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .academic-program-empty-icon {
          width: 60px;
          height: 60px;
          border-radius: 18px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 15px;
        }
        .academic-program-empty h4 {
          margin: 0;
          color: #1A1208;
          font-size: 18px;
          font-weight: 900;
        }
        .academic-program-empty p {
          margin: 8px 0 18px;
          max-width: 360px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        @media (max-width: 980px) {
          .academic-manager-hero {
            grid-template-columns: 1fr;
          }
          .academic-manager-stats {
            min-width: 0;
          }
          .academic-manager-top-actions {
            align-items: stretch;
            flex-direction: column;
          }
          .academic-manager-add {
            width: 100%;
          }
        }
        @media (max-width: 640px) {
          .academic-manager-hero,
          .academic-manager-panel-head,
          .academic-manager-form,
          .academic-programs-wrap {
            padding: 14px;
          }
          .academic-manager-title {
            font-size: 21px;
          }
          .academic-manager-title-row {
            align-items: flex-start;
          }
          .academic-manager-stats {
            grid-template-columns: 1fr;
          }
          .academic-manager-panel-head,
          .academic-programs-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .academic-programs-grid {
            grid-template-columns: 1fr;
          }
          .academic-program-top {
            grid-template-columns: 68px minmax(0, 1fr);
          }
          .academic-program-image {
            width: 68px;
          }
          .academic-program-actions {
            grid-column: 1 / -1;
            width: 100%;
            justify-content: flex-end;
          }
        }
      `}),e.jsxs("div",{className:"academic-manager-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"academic-manager-title-row",children:[e.jsx("div",{className:"academic-manager-icon",children:e.jsx(Ae,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"academic-manager-kicker",children:"Academic Content"}),e.jsx("h1",{className:"academic-manager-title",children:"Academic Programs"})]})]}),e.jsx("p",{className:"academic-manager-subtitle",children:"Manage the public academic section copy and program cards from one focused workspace."})]}),e.jsxs("div",{className:"academic-manager-top-actions",children:[e.jsxs("div",{className:"academic-manager-stats",children:[e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:t.length}),e.jsx("span",{children:"Programs"})]}),e.jsxs("div",{className:"academic-manager-stat",children:[e.jsx("strong",{children:b}),e.jsx("span",{children:"Categories"})]})]}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:m,children:[e.jsx(we,{size:16}),"Add New Program"]})]})]}),e.jsxs("div",{className:"academic-manager-panel",children:[e.jsx("div",{className:"academic-manager-panel-head",children:e.jsxs("div",{className:"academic-manager-panel-title",children:[e.jsx("div",{className:"academic-manager-panel-icon",children:e.jsx(At,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Section Banner Content"}),e.jsx("p",{children:"Copy shown above academic programs on the public website"})]})]})}),e.jsxs("div",{className:"academic-manager-form",children:[e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Section Display Title"}),e.jsx("input",{value:a.title,onChange:h=>r({...a,title:h.target.value}),placeholder:"Academic Programs"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Primary Description"}),e.jsx("textarea",{rows:3,value:a.description1,onChange:h=>r({...a,description1:h.target.value}),placeholder:"Primary description paragraph"})]}),e.jsxs("div",{className:"academic-manager-field",children:[e.jsx("label",{children:"Secondary Description"}),e.jsx("textarea",{rows:2,value:a.description2,onChange:h=>r({...a,description2:h.target.value}),placeholder:"Secondary description paragraph"})]}),e.jsxs("button",{type:"button",className:"academic-manager-save",onClick:async()=>{try{await l.put("/content/academic",a),p("Content Saved Successfully")}catch{p("Failed to save content","error")}},children:[e.jsx(Ne,{size:15}),"Update Content"]})]})]}),e.jsx("div",{className:"academic-manager-panel",children:e.jsxs("div",{className:"academic-programs-wrap",children:[e.jsx("div",{className:"academic-programs-head",children:e.jsxs("div",{children:[e.jsx("h3",{children:"Program Cards"}),e.jsx("p",{children:"These programs appear in the academic programs section."})]})}),t.length===0?e.jsxs("div",{className:"academic-program-empty",children:[e.jsx("div",{className:"academic-program-empty-icon",children:e.jsx(Ae,{size:28})}),e.jsx("h4",{children:"No programs registered yet"}),e.jsx("p",{children:"Add the first program to start building the academic page."}),e.jsxs("button",{type:"button",className:"academic-manager-add",onClick:m,children:[e.jsx(we,{size:16}),"Add New Program"]})]}):e.jsx("div",{className:"academic-programs-grid",children:t.map(h=>e.jsxs(ie.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},className:"academic-program-card",children:[e.jsxs("div",{className:"academic-program-top",children:[e.jsx("div",{className:"academic-program-image",children:e.jsx("img",{src:V(h.imageUrl),alt:h.title})}),e.jsxs("div",{className:"academic-program-main",children:[e.jsx("h4",{title:h.title,children:h.title}),e.jsxs("div",{className:"academic-program-meta",children:[h.category&&e.jsx("span",{className:"academic-program-pill",children:h.category}),h.duration&&e.jsx("span",{className:"academic-program-duration",children:h.duration})]})]}),e.jsxs("div",{className:"academic-program-actions",children:[e.jsx("button",{type:"button",className:"academic-program-action",onClick:()=>k(h),"aria-label":`Edit ${h.title}`,children:e.jsx(Q,{size:14})}),e.jsx("button",{type:"button",className:"academic-program-action danger",onClick:()=>s(`/programs/${h._id}`),"aria-label":`Delete ${h.title}`,children:e.jsx(W,{size:14})})]})]}),h.description&&e.jsx("p",{className:"academic-program-desc",children:h.description})]},h._id))})]})})]})},hi=({testimonials:t,testimonialForm:a,setTestimonialForm:r,openModal:l,del:p})=>e.jsxs("div",{className:"testimonial-manager-shell",children:[e.jsx("style",{children:`
      .testimonial-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
      .testimonial-manager-shell > div:first-of-type {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 18px !important;
        padding: 22px !important;
        border: 1px solid #E7DDD2 !important;
        border-radius: 18px !important;
        background:
          linear-gradient(135deg, rgba(255,255,255,0.97), rgba(255,249,243,0.94)),
          linear-gradient(135deg, #6B3F1D, #E07B39) !important;
        box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08) !important;
      }
      .testimonial-manager-shell > div:first-of-type h3 {
        margin: 0 !important;
        color: #1A1208 !important;
        font-size: 24px !important;
        line-height: 1.15 !important;
        font-weight: 900 !important;
        letter-spacing: 0 !important;
      }
      .testimonial-manager-shell > div:first-of-type p {
        margin: 6px 0 0 !important;
        color: #786859 !important;
        font-size: 13px !important;
        font-weight: 650 !important;
      }
      .testimonial-manager-shell > div:first-of-type button {
        height: 44px !important;
        border: 0 !important;
        border-radius: 12px !important;
        padding: 0 16px !important;
        color: #FFFFFF !important;
        background: linear-gradient(135deg, #6B3F1D 0%, #9B5A2D 100%) !important;
        box-shadow: 0 12px 24px rgba(107, 63, 29, 0.2) !important;
        font-size: 13px !important;
        font-weight: 900 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) {
        display: grid !important;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)) !important;
        gap: 16px !important;
        padding: 18px !important;
        border: 1px solid #E8E0D8 !important;
        border-radius: 18px !important;
        background: #FFFFFF !important;
        box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06) !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div {
        min-width: 0 !important;
      }
      .testimonial-manager-shell > div:nth-of-type(2) > div:not(.col-span-full) {
        border: 1px solid #E8E0D8 !important;
        border-radius: 16px !important;
        background: #FFFFFF !important;
        box-shadow: 0 12px 28px rgba(65, 42, 22, 0.06) !important;
        padding: 16px !important;
      }
      .testimonial-manager-shell img {
        width: 56px !important;
        height: 56px !important;
        border-radius: 16px !important;
        object-fit: cover !important;
      }
      .testimonial-manager-shell .col-span-full {
        grid-column: 1 / -1 !important;
      }
      .testimonial-manager-shell .col-span-full > div {
        min-height: 340px !important;
        border: 2px dashed #E6DCD1 !important;
        border-radius: 16px !important;
        background: #FBFAF8 !important;
        box-shadow: none !important;
      }
      @media (max-width: 640px) {
        .testimonial-manager-shell > div:first-of-type {
          align-items: stretch !important;
          flex-direction: column !important;
          padding: 14px !important;
        }
        .testimonial-manager-shell > div:nth-of-type(2) {
          grid-template-columns: 1fr !important;
          padding: 14px !important;
        }
      }
    `}),e.jsx(K,{icon:ge,title:"Student Testimonials",subtitle:`${t.length} reviews published`,action:e.jsx(X,{onClick:()=>{r({name:"",role:"",content:"",rating:5,image:null}),l("testimonial")}})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[t.map(o=>e.jsxs(ie.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},className:"p-6 rounded-3xl group relative shadow-md transition-all hover:shadow-lg flex flex-col h-full",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-start justify-between gap-4 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("img",{src:V(o.imageUrl),alt:o.name,className:"w-14 h-14 rounded-full object-cover border-2 shadow-inner",style:{borderColor:n.accentSoft}}),e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm leading-tight mb-1",style:{color:n.text},children:o.name}),e.jsx("p",{className:"text-xs font-medium",style:{color:n.muted},children:o.role}),e.jsx("div",{className:"flex gap-0.5 mt-1",children:[...Array(5)].map((i,s)=>e.jsx("span",{className:"text-sm",style:{color:s<o.rating?"#F59E0B":n.border},children:"★"},s))})]})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0",children:[e.jsx(M,{onClick:()=>{r({name:o.name,role:o.role,content:o.content,rating:o.rating,image:null}),l("testimonial",o)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>p(`/testimonials/${o._id}`),children:e.jsx(W,{size:14})})]})]}),e.jsxs("p",{className:"text-sm leading-relaxed italic text-gray-600 line-clamp-4 mt-1 flex-1",children:['"',o.content,'"']})]},o._id)),t.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(he,{icon:ge,text:"No testimonials available"})})]})]}),ye=({slot:t,linkedKey:a,label:r,aboutImages:l,setAboutImages:p,aboutImageFiles:o,setAboutImageFiles:i,axiosInstance:s,notify:b})=>{if(!t)return null;const m=o[t.key],k=m?URL.createObjectURL(m):t.imageUrl?V(t.imageUrl):null,h=S=>{p(l.map(z=>z.key===t.key||z.key===a?{...z,...S}:z))},w=async()=>{const S=new FormData;S.append("title",t.title||r),S.append("alt",t.alt||r),m&&S.append("image",m);try{const z=await s.put(`/about/images/${t.key}`,S);let F=l.some(P=>P.key===t.key)?l.map(P=>P.key===t.key?z.data:P):[...l,z.data];if(a){const P=new FormData;P.append("title",t.title||r),P.append("alt",t.alt||r),m&&P.append("image",m);try{const N=await s.put(`/about/images/${a}`,P);F=F.some(A=>A.key===a)?F.map(A=>A.key===a?N.data:A):[...F,N.data]}catch{}}p(F),i({...o,[t.key]:null,...a?{[a]:null}:{}}),b(`${r} image saved`)}catch{b("Image update failed","error")}},_=async()=>{if(window.confirm(`Delete ${r} image? The website will use the default image.`))try{const S=await s.delete(`/about/images/${t.key}`);let z=l.some(F=>F.key===t.key)?l.map(F=>F.key===t.key?S.data:F):[...l,S.data];if(a)try{const F=await s.delete(`/about/images/${a}`);z=z.some(P=>P.key===a)?z.map(P=>P.key===a?F.data:P):[...z,F.data]}catch{}p(z),i({...o,[t.key]:null,...a?{[a]:null}:{}}),b(`${r} image deleted`)}catch{b("Delete failed","error")}};return e.jsxs("div",{className:"p-4 rounded-2xl shadow-sm space-y-3",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest",style:{color:n.muted},children:[r," Image"]}),e.jsx("div",{className:"rounded-xl overflow-hidden bg-gray-50 border border-dashed flex items-center justify-center",style:{borderColor:n.border,maxHeight:"200px",minHeight:"120px"},children:k?e.jsx("img",{src:k,alt:t.alt||r,className:"w-full object-cover",style:{maxHeight:"200px",width:"100%",display:"block"}}):e.jsxs("div",{className:"text-center py-8",style:{color:n.muted},children:[e.jsx(Z,{size:28,className:"mx-auto mb-2 opacity-60"}),e.jsx("p",{className:"text-[11px] font-bold uppercase tracking-wider",children:"Default image active"})]})}),e.jsx(x,{label:"Alt Text",children:e.jsx("input",{value:t.alt||"",onChange:S=>h({alt:S.target.value}),className:T,style:q})}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border-2 border-dashed text-xs font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:n.border,color:n.muted},children:[e.jsx(re,{size:14})," ",m?m.name:"Choose Image",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:S=>i({...o,[t.key]:S.target.files[0]})})]}),e.jsxs("button",{onClick:w,className:"px-4 py-2.5 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition-all flex items-center justify-center gap-2",style:{background:n.brand},children:[e.jsx(Ne,{size:14})," Save"]}),e.jsxs("button",{onClick:_,className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 active:scale-95 transition-all flex items-center justify-center gap-2",children:[e.jsx(W,{size:14})," Delete"]})]})]})},ui=({aboutSub:t,setAboutSub:a,collegeLogo:r,setCollegeLogo:l,logoFile:p,setLogoFile:o,deanMessage:i,setDeanMessage:s,deanPhotoFile:b,setDeanPhotoFile:m,milestones:k,milestoneForm:h,setMilestoneForm:w,openModal:_,setMilestones:S,visionMission:z,setVmForm:F,coreValues:P,setCvForm:N,aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,historyContent:$,setHistoryContent:I,axiosInstance:B,notify:g,del:f})=>e.jsxs("div",{className:"about-manager-shell admin-clean-page",children:[e.jsx("style",{children:`
      .about-manager-shell {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
    `}),e.jsx(Ee,{tabs:["Branding","Principal","Timeline","Vision & Mission","Core Values"],active:t,onChange:a}),e.jsx(fe,{mode:"wait",children:e.jsxs(ie.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:-8},children:[t==="Branding"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:n.text},children:"Institution Branding"}),e.jsxs("div",{className:"flex flex-col sm:flex-row items-start gap-6",children:[e.jsx("div",{className:"rounded-2xl border-2 border-dashed overflow-hidden bg-gray-50 flex items-center justify-center shrink-0 shadow-inner",style:{width:"100px",height:"100px",minWidth:"100px",minHeight:"100px",maxWidth:"100px",maxHeight:"100px",borderColor:n.border,padding:"6px",background:"#f8fafc",boxSizing:"border-box"},children:r.logoUrl?e.jsx("img",{src:V(r.logoUrl),style:{width:"100%",height:"100%",maxWidth:"86px",maxHeight:"86px",objectFit:"contain",display:"block"},alt:"College Logo"}):e.jsx(Z,{size:32,style:{color:n.muted}})}),e.jsxs("div",{className:"flex-1 w-full space-y-4",children:[e.jsx(x,{label:"College Full Name",children:e.jsx("input",{value:r.collegeName||"",onChange:d=>l({...r,collegeName:d.target.value}),placeholder:"e.g. Ginera Nursing College",className:T,style:q})}),e.jsx(x,{label:"Tagline / Motto",children:e.jsx("input",{value:r.tagline||"",onChange:d=>l({...r,tagline:d.target.value}),placeholder:"e.g. Excellence in Healthcare",className:T,style:q})})]})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-3 pt-2",children:[e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed text-sm font-semibold cursor-pointer hover:bg-gray-50 transition-all",style:{borderColor:n.border,color:n.muted},children:[e.jsx(re,{size:16})," ",p?p.name:"Choose New Logo File",e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:d=>o(d.target.files[0])})]}),e.jsx("button",{onClick:async()=>{const d=new FormData;d.append("collegeName",r.collegeName||""),d.append("tagline",r.tagline||""),p&&d.append("logo",p);try{const c=await B.put("/about/college-logo",d);l(c.data),o(null),g("Branding Updated Successfully")}catch{g("Update failed","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all",style:{background:n.brand},children:"Save Branding"})]})]}),t==="Principal"&&e.jsxs("div",{className:"p-6 rounded-3xl space-y-5 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"font-bold text-base",style:{color:n.text},children:"Dean / Principal's Message"}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[e.jsx(x,{label:"Full Name",children:e.jsx("input",{value:i.name||"",onChange:d=>s({...i,name:d.target.value}),placeholder:"e.g. Dr. Jane Doe",className:T,style:q})}),e.jsx(x,{label:"Official Title",children:e.jsx("input",{value:i.title||"",onChange:d=>s({...i,title:d.target.value}),placeholder:"e.g. Dean of Nursing",className:T,style:q})})]}),e.jsx(x,{label:"Opening Greeting",children:e.jsx("input",{value:i.greeting||"",onChange:d=>s({...i,greeting:d.target.value}),placeholder:"e.g. Welcome to Ginera...",className:T,style:q})}),e.jsx(x,{label:"Message Content (New line for each paragraph)",children:e.jsx("textarea",{rows:6,className:`${T} resize-none`,style:q,value:(i.paragraphs||[]).join(`
`),onChange:d=>s({...i,paragraphs:d.target.value.split(`
`)})})}),e.jsx(x,{label:"Highlight Quote",children:e.jsx("textarea",{rows:2,className:`${T} resize-none font-medium italic`,style:q,placeholder:"A powerful summary statement...",value:i.highlight||"",onChange:d=>s({...i,highlight:d.target.value})})}),e.jsxs("div",{className:"flex flex-col gap-4 p-4 rounded-2xl bg-gray-50 border border-dashed sm:flex-row sm:items-center",style:{borderColor:n.border},children:[e.jsx("div",{className:"rounded-2xl overflow-hidden border-2 shadow-sm shrink-0",style:{width:"64px",height:"64px",minWidth:"64px",minHeight:"64px",maxWidth:"64px",maxHeight:"64px",borderColor:n.brand+"40"},children:i.photoUrl?e.jsx("img",{src:V(i.photoUrl),className:"w-full h-full object-cover",alt:""}):e.jsx("div",{className:"w-full h-full bg-white flex items-center justify-center",children:e.jsx(ge,{size:24,style:{color:n.muted}})})}),e.jsxs("label",{className:"flex min-w-0 flex-1 items-center gap-3 rounded-xl border-2 border-dashed px-4 py-3 text-sm font-bold cursor-pointer transition-all hover:border-amber-400 hover:bg-amber-50",style:{borderColor:b?n.accent:n.border,color:n.text,background:b?n.accentSoft:"#FFFFFF"},children:[e.jsx("span",{className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",style:{background:n.accentSoft,color:n.accent},children:e.jsx(re,{size:17})}),e.jsxs("span",{className:"min-w-0 flex-1",children:[e.jsx("span",{className:"block text-[11px] uppercase tracking-wider",style:{color:n.muted},children:"Principal photo"}),e.jsx("span",{className:"block truncate mt-0.5",children:b?b.name:"Choose or replace photo"})]}),e.jsx("input",{type:"file",className:"hidden",accept:"image/*",onChange:d=>m(d.target.files[0])})]})]}),e.jsx("button",{onClick:async()=>{const d=new FormData;["name","title","greeting","highlight"].forEach(c=>d.append(c,i[c]||"")),d.append("paragraphs",JSON.stringify((i.paragraphs||[]).filter(c=>c&&c.trim()!==""))),d.append("stats",JSON.stringify(i.stats||[])),b&&d.append("photo",b);try{const c=await B.put("/about/dean",d);s(c.data),m(null),g("Message Updated Successfully")}catch{g("Update failed","error")}},className:"w-full sm:w-auto px-10 py-3.5 rounded-xl text-sm font-bold text-white shadow-xl active:scale-95 transition-all",style:{background:n.brand},children:"Publish Message"})]}),t==="Timeline"&&e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:n.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:n.text},children:"History Page Images Management"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:n.muted},children:"Upload, update, or delete images for Hero Banner, Institutional Timeline, and Legacy of Excellence sections"})]})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsx(ye,{slot:A.find(d=>d.key==="historyHero")||{key:"historyHero",title:"History Hero Banner Image",alt:"Our History Banner"},label:"History Hero Banner",aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,axiosInstance:B,notify:g}),e.jsx(ye,{slot:A.find(d=>d.key==="historyTimeline")||{key:"historyTimeline",title:"Institutional Timeline Image",alt:"Institutional Timeline"},label:"Institutional Timeline Section",aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,axiosInstance:B,notify:g}),e.jsx(ye,{slot:A.find(d=>d.key==="historyLegacy")||{key:"historyLegacy",title:"Legacy of Excellence Image",alt:"Legacy of Excellence"},label:"Legacy of Excellence Section",aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,axiosInstance:B,notify:g})]})]}),e.jsxs("div",{className:"p-6 rounded-3xl space-y-6 shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[e.jsx("div",{className:"flex items-center justify-between border-b pb-4",style:{borderColor:n.border},children:e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",style:{color:n.text},children:"History Page Content & Section Titles"}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:n.muted},children:"Edit main hero title, section headings, and history paragraphs"})]})}),e.jsx(x,{label:"Hero Banner Title",children:e.jsx(y,{value:$.heroTitle||"",onChange:d=>I({...$,heroTitle:d.target.value}),placeholder:"e.g. Our History"})}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6 pt-2",children:[e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:n.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Institutional Timeline Section"}),e.jsx(x,{label:"Section Title",children:e.jsx(y,{value:$.timelineTitle||"",onChange:d=>I({...$,timelineTitle:d.target.value}),placeholder:"e.g. Institutional Timeline"})}),e.jsx(x,{label:"Paragraphs (One paragraph per line)",children:e.jsx(H,{rows:6,value:Array.isArray($.timelineParagraphs)?$.timelineParagraphs.join(`
`):$.timelineParagraphs||"",onChange:d=>I({...$,timelineParagraphs:d.target.value.split(`
`)}),placeholder:"Enter timeline history paragraphs..."})})]}),e.jsxs("div",{className:"p-4 rounded-2xl bg-gray-50/80 border space-y-4",style:{borderColor:n.border},children:[e.jsx("p",{className:"text-xs font-extrabold uppercase tracking-wider text-amber-700",children:"Legacy of Excellence Section"}),e.jsx(x,{label:"Section Title",children:e.jsx(y,{value:$.legacyTitle||"",onChange:d=>I({...$,legacyTitle:d.target.value}),placeholder:"e.g. Legacy of Excellence"})}),e.jsx(x,{label:"Paragraphs (One paragraph per line)",children:e.jsx(H,{rows:6,value:Array.isArray($.legacyParagraphs)?$.legacyParagraphs.join(`
`):$.legacyParagraphs||"",onChange:d=>I({...$,legacyParagraphs:d.target.value.split(`
`)}),placeholder:"Enter legacy paragraphs..."})})]})]}),e.jsx("div",{className:"flex justify-end pt-2",children:e.jsxs("button",{onClick:async()=>{try{const d={...$,timelineParagraphs:(Array.isArray($.timelineParagraphs)?$.timelineParagraphs:($.timelineParagraphs||"").split(`
`)).filter(j=>j&&j.trim()!==""),legacyParagraphs:(Array.isArray($.legacyParagraphs)?$.legacyParagraphs:($.legacyParagraphs||"").split(`
`)).filter(j=>j&&j.trim()!=="")},c=await B.put("/about/history-content",d);I(c.data),g("History Page Content Updated Successfully!")}catch{g("Failed to update history content","error")}},className:"px-8 py-3 rounded-xl text-sm font-bold text-white shadow-lg active:scale-95 transition-all flex items-center gap-2",style:{background:n.brand},children:[e.jsx(Ne,{size:16})," Save History Page Content"]})})]}),e.jsxs("div",{className:"space-y-4 pt-4 border-t border-gray-200",children:[e.jsx(K,{icon:Dt,title:"Institutional Milestones",subtitle:"Timeline entries & historical achievements",action:e.jsx(X,{onClick:()=>{w({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),_("milestone")},label:"Add Milestone"})}),e.jsx("div",{className:"grid grid-cols-1 gap-4",children:k.map(d=>e.jsxs("div",{className:"p-5 rounded-2xl transition-all hover:shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",style:{background:n.surface,border:`1px solid ${n.border}`,borderLeft:`5px solid ${d.color||"#f59e0b"}`},children:[e.jsxs("div",{className:"flex items-start gap-4 min-w-0 flex-1",children:[e.jsx("span",{className:"text-3xl shrink-0 p-2 rounded-xl bg-amber-50 border border-amber-100",children:d.icon||"🎯"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("div",{className:"flex items-center gap-2 mb-1",children:e.jsx("span",{className:"px-2.5 py-0.5 rounded-md text-xs font-bold text-gray-800 bg-gray-100 border border-gray-200",children:d.year})}),e.jsx("p",{className:"font-bold text-sm text-gray-900 truncate",children:d.event}),e.jsx("p",{className:"text-xs text-gray-500 line-clamp-2 mt-1 leading-relaxed",children:d.description})]})]}),e.jsxs("div",{className:"flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-100",children:[e.jsxs("button",{onClick:()=>{w({year:d.year,event:d.event,icon:d.icon,color:d.color,description:d.description,order:d.order||0}),_("milestone",d)},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition-all shadow-sm",children:[e.jsx(Q,{size:14})," Edit"]}),e.jsxs("button",{onClick:async()=>{if(window.confirm("Delete this milestone?"))try{await B.delete(`/about/milestones/${d._id}`),S(k.filter(c=>c._id!==d._id)),g("Milestone Removed")}catch{g("Delete failed","error")}},className:"flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-all shadow-sm",children:[e.jsx(W,{size:14})," Delete"]})]})]},d._id))})]})]}),t==="Vision & Mission"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:Fe,title:"Vision & Mission",subtitle:"Strategic direction statements",action:e.jsx(X,{onClick:()=>{F({type:"vision",content:"",order:0}),_("visionMission")},label:"Add Statement"})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-4",children:[e.jsx(ye,{slot:A.find(d=>d.key==="visionMain")||A.find(d=>d.key==="visionGoals"),linkedKey:"visionGoals",label:"Vision",aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,axiosInstance:B,notify:g}),e.jsx(ye,{slot:A.find(d=>d.key==="missionMain")||A.find(d=>d.key==="missionValues"),linkedKey:"missionValues",label:"Mission",aboutImages:A,setAboutImages:C,aboutImageFiles:O,setAboutImageFiles:J,axiosInstance:B,notify:g})]}),e.jsx("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",style:{gap:"1.5rem"},children:["vision","mission"].map(d=>e.jsxs("div",{className:"flex flex-col gap-3 min-w-0",style:{gap:"0.75rem"},children:[e.jsxs("p",{className:"text-xs font-bold uppercase tracking-widest pl-2",style:{color:n.muted},children:[d," Statement"]}),z.filter(c=>c.type===d).map(c=>e.jsxs("div",{className:"p-5 rounded-2xl relative group shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("p",{className:"text-sm leading-relaxed",style:{color:n.text},children:c.content}),e.jsxs("div",{className:"absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{F({type:c.type,content:c.content,order:c.order}),_("visionMission",c)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>f(`/about/vision-mission/${c._id}`),children:e.jsx(W,{size:13})})]})]},c._id))]},d))})]}),t==="Core Values"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:de,title:"Institutional Values",subtitle:"The pillars of our culture",action:e.jsx(X,{onClick:()=>{N({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),_("coreValue")},label:"Add Core Value"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",style:{gap:"1.25rem"},children:P.map(d=>e.jsxs("div",{className:"p-6 rounded-3xl group relative transition-all hover:shadow-lg overflow-hidden",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("div",{className:`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${d.color} opacity-[0.03] rounded-bl-[100px] transition-all group-hover:opacity-[0.08]`}),e.jsx("span",{className:"text-4xl block mb-4 filter drop-shadow-sm",children:d.icon}),e.jsx("p",{className:"font-bold text-base mb-2",style:{color:n.text},children:d.title}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:n.muted},children:d.description}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{N({icon:d.icon,title:d.title,description:d.description,color:d.color,order:d.order}),_("coreValue",d)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>f(`/about/core-values/${d._id}`),children:e.jsx(W,{size:13})})]})]},d._id))})]})]},t)})]}),bi=({admSub:t,setAdmSub:a,courses:r,openModal:l,setCourseForm:p,del:o,admissionSteps:i,setStepForm:s,admissionRules:b,setRuleForm:m,bonds:k,setBondForm:h,guidelines:w,setGuidelineForm:_})=>{const[S,z]=u.useState("All"),F=["All",...Array.from(new Set(r.map(N=>N.category).filter(Boolean)))],P=S==="All"?r:r.filter(N=>N.category===S);return e.jsxs("div",{className:"admission-manager-shell admin-clean-page",children:[e.jsx(Ee,{tabs:["Courses","Procedure","Eligibility","Guidelines"],active:t,onChange:a}),t==="Courses"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:me,title:"Program Offerings",subtitle:`${r.length} courses listed`,action:e.jsx(X,{onClick:()=>{p({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),l("course")},label:"Add Course"})}),e.jsx("div",{className:"flex flex-wrap gap-2",children:F.map(N=>e.jsx("button",{type:"button",onClick:()=>z(N),className:"px-3 py-2 rounded-xl text-xs font-bold border transition-all",style:{background:S===N?n.brand:n.surface,color:S===N?"#fff":n.muted,borderColor:n.border},children:N},N))}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:P.map(N=>e.jsx(be,{icon:N.icon,badge:N.category,title:N.name,sub:`${N.duration} | ${N.seats} Seats`,onEdit:()=>{p({...N,highlights:N.highlights?.join(", ")||""}),l("course",N)},onDelete:()=>o(`/courses/${N._id}`)},N._id))})]}),t==="Procedure"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ve,title:"Admission Steps",subtitle:"Step-by-step guidance for applicants",action:e.jsx(X,{onClick:()=>{s({step:1,title:"",description:"",details:"",icon:"Calendar"}),l("step")},label:"Add Step"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:i.sort((N,A)=>N.step-A.step).map(N=>e.jsxs("div",{className:"p-5 rounded-3xl group relative shadow-sm hover:shadow-md transition-all",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold text-white shadow-md",style:{background:n.brand},children:N.step}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:n.text},children:N.title}),e.jsx("p",{className:"text-xs line-clamp-1",style:{color:n.muted},children:N.description})]})]}),e.jsxs("div",{className:"absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{s({...N}),l("step",N)},children:e.jsx(Q,{size:13})}),e.jsx(M,{danger:!0,onClick:()=>o(`/admission-steps/${N._id}`),children:e.jsx(W,{size:13})})]})]},N._id))})]}),t==="Eligibility"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ze,title:"Admission Rules",subtitle:"Criteria for selection",action:e.jsx(X,{onClick:()=>{m({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),l("rule")},label:"Add Rule"})}),["UnderGraduated Programs","PostGraduated Programs","General Rules"].map(N=>{const A=b.filter(C=>C.category===N);return A.length?e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em] px-2",style:{color:n.muted},children:N}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:A.map(C=>e.jsx(be,{icon:C.icon==="CheckCircle"?"✅":"📋",title:C.title,sub:C.description?.slice(0,60)+"...",onEdit:()=>{m({...C}),l("rule",C)},onDelete:()=>o(`/admission-rules/${C._id}`)},C._id))})]},N):null})]}),t==="Guidelines"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:Fe,title:"Guidelines & Conduct",subtitle:"Rules for students and guardians",action:e.jsx(X,{onClick:()=>{_({category:"General Guidelines",subCategory:"",points:"",order:0}),l("guideline")},label:"Add Section"})}),["General Guidelines","Code of Conduct","Academic Requirements","For Parents/Guardians","Contact Information","Required Documents","Additional Documents"].map(N=>{const A=w.filter(C=>C.category===N);return A.length?e.jsxs("div",{className:"rounded-3xl overflow-hidden shadow-sm border",style:{borderColor:n.border},children:[e.jsx("div",{className:"px-6 py-3.5 border-b",style:{background:n.bg,borderColor:n.border},children:e.jsx("p",{className:"font-bold text-xs uppercase tracking-widest",style:{color:n.text},children:N})}),e.jsx("div",{className:"divide-y divide-gray-100",style:{background:n.surface},children:A.map(C=>e.jsxs("div",{className:"flex items-start gap-5 p-5 group transition-all hover:bg-gray-50/50",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"font-bold text-sm mb-2",style:{color:n.text},children:C.subCategory}),e.jsx("ul",{className:"space-y-1.5",children:C.points.map((O,J)=>e.jsxs("li",{className:"flex items-start gap-2 text-xs leading-relaxed",style:{color:n.muted},children:[e.jsx("span",{className:"mt-1.5 w-1 h-1 rounded-full bg-amber-500 shrink-0"}),O]},J))})]}),e.jsxs("div",{className:"flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx(M,{onClick:()=>{_({...C,points:C.points.join(`
`)}),l("guideline",C)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>o(`/guidelines/${C._id}`),children:e.jsx(W,{size:14})})]})]},C._id))})]},N):null})]})]})},fi=({selectedDept:t,setSelectedDept:a,departments:r,deptForm:l,setDeptForm:p,deptSub:o,setDeptSub:i,deptFacultyForm:s,setDeptFacultyForm:b,deptFacilityInput:m,setDeptFacilityInput:k,deptActivityInput:h,setDeptActivityInput:w,sliders:_,axiosInstance:S,fetchData:z,notify:F,openModal:P,del:N,handleSliderUpload:A})=>{const[C,O]=u.useState(null),[J,$]=u.useState(null),[I,B]=u.useState(null),[g,f]=u.useState(!1),d=async c=>{const j=c.target.files?.[0];if(j){if(j.size>500*1024){F(`Image size is ${(j.size/1024).toFixed(0)}KB. Maximum allowed is 500KB.`,"error"),c.target.value="";return}try{f(!0);const D=new FormData;D.append("image",j);const L=await S.post("/departments/upload-faculty-image",D);b(ae=>({...ae,imageUrl:L.data.imageUrl})),F("Faculty photo uploaded successfully")}catch(D){const L=D.response?.data?.message||"Failed to upload faculty photo";F(L,"error")}finally{f(!1),c.target.value=""}}};return t?e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-col lg:flex-row items-start lg:items-center gap-6 p-6 rounded-3xl shadow-sm border overflow-hidden",style:{background:n.surface,borderColor:n.border},children:[e.jsxs("div",{className:"flex items-center gap-4 flex-1 min-w-0",children:[e.jsx("button",{onClick:()=>{a(null),O(null),$(null),B(null)},className:"p-3 rounded-2xl hover:bg-gray-50 transition-all shrink-0 border shadow-sm group",style:{borderColor:n.border,color:n.muted},children:e.jsx(Pt,{size:20,className:"group-hover:-translate-x-1 transition-transform"})}),l.logoUrl||t.logoUrl?e.jsx("img",{src:V(l.logoUrl||t.logoUrl),className:"w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm",alt:""}):e.jsx("span",{className:"text-3xl shrink-0 drop-shadow-sm",children:"🏥"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-base sm:text-xl whitespace-nowrap overflow-hidden text-ellipsis leading-tight",style:{color:n.text},children:t.name}),e.jsxs("div",{className:"flex items-center gap-2 mt-1",children:[e.jsx("span",{className:"text-[10px] font-extrabold uppercase tracking-[0.2em]",style:{color:n.accent},children:t.category}),e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"}),e.jsx("span",{className:"text-[11px] font-bold text-muted-foreground",children:"Editor Mode"})]})]})]}),e.jsxs("button",{onClick:async()=>{try{let c=l.faculty?[...l.faculty]:[];C!==null&&s.name?.trim()&&(c[C]={...s});const j=new FormData;j.append("name",l.name||""),j.append("category",l.category||""),j.append("description",l.description||""),j.append("overview",l.overview||""),j.append("overview2",l.overview2||""),j.append("faculty",JSON.stringify(c)),l.facilities&&j.append("facilities",JSON.stringify(l.facilities)),l.activities&&j.append("activities",JSON.stringify(l.activities)),l.logo instanceof File&&j.append("logo",l.logo);const D=await S.put(`/departments/${t._id}`,j);a(D.data),p({...D.data}),O(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}),F("Department & Staff Saved Successfully"),z()}catch{F("Failed to save changes","error")}},className:"w-full lg:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-sm font-bold text-white shadow-xl hover:opacity-90 active:scale-95 transition-all",style:{background:n.brand},children:[e.jsx(Ne,{size:18})," Save All Changes"]})]}),e.jsxs("div",{className:"flex flex-col gap-6",children:[e.jsx(Ee,{tabs:["Overview","Faculty","Facilities","Activities","Sliders"],active:o,onChange:i}),e.jsxs("div",{className:"p-7 rounded-3xl shadow-sm border",style:{background:n.surface,borderColor:n.border},children:[o==="Overview"&&e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-5 items-end",children:[e.jsx(x,{label:"Department Display Name",children:e.jsx("input",{value:l.name,onChange:c=>p({...l,name:c.target.value}),className:T,style:q})}),e.jsx(x,{label:"Academic Category",children:e.jsx("input",{value:l.category,onChange:c=>p({...l,category:c.target.value}),className:T,style:q})}),e.jsx(x,{label:"Department Logo",children:e.jsxs("div",{className:"flex items-center gap-3",children:[l.logo instanceof File?e.jsx("img",{src:URL.createObjectURL(l.logo),className:"h-12 w-12 object-cover rounded-xl border",alt:"preview"}):l.logoUrl||t.logoUrl?e.jsx("img",{src:V(l.logoUrl||t.logoUrl),className:"h-12 w-12 object-cover rounded-xl border",alt:"current logo"}):e.jsx("div",{className:"h-12 w-12 rounded-xl flex items-center justify-center text-xl bg-gray-100",children:"🏥"}),e.jsxs("label",{className:"flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border bg-white cursor-pointer hover:bg-gray-50 transition text-sm text-gray-500",style:{borderColor:"#E2E8F0"},children:[e.jsx(Z,{size:16}),l.logo instanceof File?"Change Logo":"Upload Image",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",onChange:c=>p({...l,logo:c.target.files[0]})})]})]})})]}),e.jsx(x,{label:"Short Introduction",children:e.jsx("input",{value:l.description,onChange:c=>p({...l,description:c.target.value}),className:T,style:q})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-5",children:[e.jsx(x,{label:"Primary Overview Paragraph",children:e.jsx("textarea",{rows:5,value:l.overview,onChange:c=>p({...l,overview:c.target.value}),className:`${T} resize-none`,style:q})}),e.jsx(x,{label:"Secondary Details (Optional)",children:e.jsx("textarea",{rows:5,value:l.overview2,onChange:c=>p({...l,overview2:c.target.value}),className:`${T} resize-none`,style:q})})]})]}),o==="Faculty"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"p-5 rounded-2xl shadow-inner border border-dashed space-y-4",style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[s.imageUrl?e.jsxs("div",{className:"relative group/avatar",children:[e.jsx("img",{src:V(s.imageUrl),alt:"Faculty preview",className:"w-16 h-16 rounded-2xl object-cover border-2 shadow-sm",style:{borderColor:n.brand}}),e.jsx("button",{type:"button",onClick:()=>b({...s,imageUrl:""}),className:"absolute -top-1.5 -right-1.5 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition shadow",title:"Remove photo",children:e.jsx(oe,{size:12})})]}):e.jsx("div",{className:"w-16 h-16 rounded-2xl flex items-center justify-center text-2xl border-2 border-dashed bg-white shadow-sm",style:{borderColor:n.border,color:n.muted},children:e.jsx(ge,{size:24})}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap",children:[e.jsxs("label",{className:"flex items-center gap-2 px-4 py-2.5 rounded-xl border bg-white cursor-pointer hover:bg-gray-50 transition text-xs font-semibold text-gray-700 shadow-sm",style:{borderColor:n.border},children:[e.jsx(re,{size:14}),g?"Uploading...":s.imageUrl?"Change Photo":"Upload Faculty Photo",e.jsx("input",{type:"file",accept:"image/*",className:"hidden",disabled:g,onChange:d})]}),s.imageUrl&&e.jsxs("button",{type:"button",onClick:()=>b({...s,imageUrl:""}),className:"flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-600 transition text-xs font-semibold shadow-sm",title:"Cancel / Remove image",children:[e.jsx(W,{size:13})," Cancel Image"]})]}),e.jsx("p",{className:"text-[11px] text-gray-400 mt-1",children:"Recommended: max 500KB (PNG/JPG/WEBP)"})]})]}),C!==null&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("div",{className:"px-3 py-1.5 rounded-lg bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1.5",children:[e.jsx(Q,{size:13})," Editing Faculty #",C+1]}),e.jsx("button",{type:"button",onClick:()=>{O(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"px-2.5 py-1.5 rounded-lg border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 text-xs font-semibold transition",children:"Cancel Edit"})]})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-3",children:[e.jsx("input",{placeholder:"Faculty Full Name *",value:s.name||"",onChange:c=>b({...s,name:c.target.value}),className:T,style:q}),e.jsx("input",{placeholder:"Designation (e.g. Nursing Tutor)",value:s.designation||"",onChange:c=>b({...s,designation:c.target.value}),className:T,style:q}),e.jsx("input",{placeholder:"Qualification (e.g. M.Sc. Child Health Nursing)",value:s.qualification||"",onChange:c=>b({...s,qualification:c.target.value}),className:T,style:q})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-3 gap-3 items-end",children:[e.jsx("div",{className:"sm:col-span-2",children:e.jsx("textarea",{rows:2,placeholder:"Faculty Description / Bio (e.g. Specialization, experience, clinical training...)",value:s.description||"",onChange:c=>b({...s,description:c.target.value}),className:`${T} resize-none`,style:q})}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("button",{type:"button",onClick:()=>{if(!s.name||!s.name.trim()){F("Please enter faculty name","error");return}if(C!==null){const c=[...l.faculty];c[C]={...s},p(j=>({...j,faculty:c})),O(null),F("Staff updated in list! Click 'Save All Changes' above to apply to the website.")}else p(c=>({...c,faculty:[...c.faculty||[],{...s}]})),F("Staff added to list! Click 'Save All Changes' above to apply to the website.");b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"flex-1 px-4 py-2.5 rounded-xl text-sm font-bold text-white shadow hover:opacity-90 active:scale-95 transition-all flex items-center justify-center gap-1.5",style:{background:n.brand},children:C!==null?"Update Staff":"Add Staff"}),C!==null&&e.jsx("button",{type:"button",onClick:()=>{O(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""})},className:"px-3 py-2.5 rounded-xl text-xs font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition",children:"Cancel"})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",children:[l.faculty.map((c,j)=>e.jsx("div",{className:`flex flex-col justify-between p-4 rounded-2xl shadow-sm border group transition-all ${C===j?"ring-2 ring-amber-500 bg-amber-50/40":"hover:border-amber-300 hover:shadow-md"}`,style:{background:n.bg,borderColor:n.border},children:e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-2.5",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0 flex-1",children:[c.imageUrl?e.jsx("img",{src:V(c.imageUrl),alt:c.name,className:"w-14 h-14 rounded-2xl object-cover shrink-0 border shadow-sm group-hover:scale-105 transition-transform"}):e.jsx("div",{className:"w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-base shrink-0 border shadow-sm",style:{background:n.accentSoft,color:n.accent,borderColor:n.border},children:c.name?c.name.charAt(0).toUpperCase():"👨‍⚕️"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-bold text-sm truncate",style:{color:n.text},children:c.name}),e.jsx("p",{className:"text-[11px] font-bold uppercase tracking-wide text-amber-600 truncate mt-0.5",children:c.designation||"Faculty Member"}),e.jsx("p",{className:"text-[11px] text-gray-500 truncate mt-0.5",children:c.qualification})]})]}),e.jsxs("div",{className:"flex items-center gap-1 shrink-0",children:[e.jsx(M,{title:"Edit faculty member",onClick:()=>{O(j),b({name:c.name||"",designation:c.designation||"",qualification:c.qualification||"",specialization:c.specialization||"",description:c.description||"",imageUrl:c.imageUrl||""})},children:e.jsx(Q,{size:15})}),e.jsx(M,{danger:!0,title:"Delete faculty member",onClick:()=>{p({...l,faculty:l.faculty.filter((D,L)=>L!==j)}),C===j&&(O(null),b({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}))},children:e.jsx(W,{size:15})})]})]}),c.description&&e.jsx("p",{className:"text-xs text-gray-600 bg-amber-50/50 p-2.5 rounded-xl border border-amber-100/60 leading-relaxed mt-2 line-clamp-3",children:c.description})]})},j)),l.faculty.length===0&&e.jsx("div",{className:"col-span-full py-8 text-center text-gray-400 text-sm",children:"No faculty members added yet. Use the form above to add staff with photo and description."})]})]}),(o==="Facilities"||o==="Activities")&&(()=>{const c=o==="Facilities"?"facilities":"activities",j=o==="Facilities"?m:h,D=o==="Facilities"?k:w,L=o==="Facilities"?J:I,ae=o==="Facilities"?$:B,ue=()=>{if(j.trim()){if(L!==null){const te=[...l[c]];te[L]=j.trim(),p({...l,[c]:te}),ae(null)}else p({...l,[c]:[...l[c],j.trim()]});D("")}};return e.jsxs("div",{className:"space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx("input",{value:j,onChange:te=>D(te.target.value),onKeyDown:te=>te.key==="Enter"&&ue(),placeholder:L!==null?`Edit ${o.toLowerCase()} point...`:`Describe new ${o.toLowerCase()} point...`,className:`${T} flex-1 shadow-sm`,style:q}),e.jsx("button",{onClick:ue,className:"px-6 py-2.5 rounded-xl font-bold text-white shadow-lg hover:opacity-90 active:scale-95 transition-all shrink-0",style:{background:n.brand},children:L!==null?"Update Point":e.jsx(we,{size:20})}),L!==null&&e.jsx("button",{onClick:()=>{ae(null),D("")},className:"px-4 py-2.5 rounded-xl font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 transition shrink-0 text-xs",children:"Cancel"})]}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:l[c].map((te,pe)=>e.jsxs("div",{className:`flex items-center justify-between p-4 rounded-2xl group transition-all border shadow-sm ${L===pe?"ring-2 ring-amber-500 bg-amber-50/30":"hover:bg-gray-50"}`,style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1 min-w-0 pr-3",children:[e.jsx("div",{className:"w-6 h-6 rounded-lg bg-white flex items-center justify-center shadow-sm shrink-0",children:e.jsx("span",{className:"text-[10px] font-bold",style:{color:n.accent},children:pe+1})}),e.jsx("p",{className:"text-sm leading-relaxed",style:{color:n.text},children:te})]}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx(M,{onClick:()=>{ae(pe),D(te)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,onClick:()=>{p({...l,[c]:l[c].filter((Be,Ce)=>Ce!==pe)}),L===pe&&(ae(null),D(""))},children:e.jsx(W,{size:14})})]})]},pe))})]})})(),o==="Sliders"&&e.jsxs("div",{className:"space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl shadow-inner border border-dashed",style:{background:n.bg,borderColor:n.border},children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-sm",style:{color:n.text},children:"Department Hero Sliders"}),e.jsx("p",{className:"text-[11px] font-medium mt-0.5",style:{color:n.muted},children:"Upload high-resolution banner images for the department landing page (stored on Cloudinary)"})]}),e.jsxs("label",{className:"flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white cursor-pointer shadow-lg active:scale-95 transition-all hover:opacity-90",style:{background:n.brand},children:[e.jsx(re,{size:16})," Bulk Upload",e.jsx("input",{type:"file",multiple:!0,accept:"image/*",className:"hidden",onChange:c=>{c.target.files&&c.target.files.length>0&&(A(c,t._id),c.target.value="")}})]})]}),(()=>{const c=_.filter(j=>j.department?._id===t._id);return c.length===0?e.jsxs("div",{className:"flex flex-col items-center justify-center p-10 rounded-2xl border-2 border-dashed text-center",style:{borderColor:n.border,background:n.panel},children:[e.jsx("div",{className:"w-14 h-14 rounded-2xl flex items-center justify-center mb-3 shadow-inner",style:{background:`${n.brand}15`,color:n.brand},children:e.jsx(Z,{size:28})}),e.jsx("p",{className:"font-bold text-sm",style:{color:n.text},children:"No Sliders Uploaded Yet"}),e.jsxs("p",{className:"text-xs max-w-md mt-1 mb-5",style:{color:n.muted},children:["Upload one or multiple images for ",e.jsx("strong",{children:t.name}),". All images will be securely saved to Cloudinary and displayed immediately in the website banner."]}),e.jsxs("label",{className:"flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white cursor-pointer shadow-md active:scale-95 transition-all hover:opacity-90",style:{background:n.brand},children:[e.jsx(re,{size:14})," Choose Banner Images",e.jsx("input",{type:"file",multiple:!0,accept:"image/*",className:"hidden",onChange:j=>{j.target.files&&j.target.files.length>0&&(A(j,t._id),j.target.value="")}})]})]}):e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",children:c.map(j=>e.jsxs("div",{className:"group relative aspect-video rounded-2xl overflow-hidden shadow-md transition-all hover:shadow-xl",style:{border:`2px solid ${n.border}`},children:[e.jsx("img",{src:V(j.imageUrl),alt:"",className:"w-full h-full object-cover transition-transform duration-500 group-hover:scale-110",onError:D=>{D.currentTarget.onerror=null,D.currentTarget.src="https://placehold.co/600x400?text=Image+Unavailable"}}),j.imageUrl?.includes("cloudinary.com")&&e.jsx("span",{className:"absolute top-2 left-2 bg-emerald-600/90 text-white text-[9px] font-semibold px-2 py-0.5 rounded-full shadow backdrop-blur-xs",children:"Cloudinary"}),e.jsx("div",{className:"absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[1px]",children:e.jsx("button",{onClick:()=>N(`/sliders/${j._id}`),className:"p-3 bg-red-500 text-white rounded-2xl shadow-xl hover:bg-red-600 transform transition-transform group-hover:scale-110",title:"Delete Slider",children:e.jsx(W,{size:18})})})]},j._id))})})()]})]})]})]}):e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ce,title:"Academic Departments",subtitle:`Managing ${r.length} nursing specialties`,action:e.jsx(X,{onClick:()=>{p({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],logo:null}),P("department")},label:"New Department"})}),e.jsxs("div",{className:"admin-department-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",children:[r.map(c=>e.jsxs(ie.div,{whileHover:{y:-4},className:"admin-department-card p-6 rounded-3xl group transition-all relative overflow-hidden",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx("div",{className:"absolute top-0 right-0 w-20 h-20 bg-amber-500 opacity-[0.02] rounded-bl-[80px] group-hover:opacity-[0.06] transition-all"}),e.jsxs("div",{className:"admin-card-actions flex justify-end gap-1.5 mb-3",children:[e.jsx(M,{title:"Edit department",onClick:j=>{j.stopPropagation(),p({...c,logo:null}),P("department",c)},children:e.jsx(Q,{size:14})}),e.jsx(M,{danger:!0,title:"Delete department",onClick:j=>{j.stopPropagation(),N(`/departments/${c._id}`)},children:e.jsx(W,{size:14})})]}),e.jsxs("div",{className:"cursor-pointer",onClick:()=>{a(c),p({...c}),i("Overview")},children:[e.jsxs("div",{className:"admin-department-body flex items-center gap-4 mb-5",children:[c.logoUrl?e.jsx("img",{src:V(c.logoUrl),className:"admin-department-logo w-12 h-12 rounded-xl object-cover shrink-0 border shadow-sm group-hover:scale-105 transition-transform duration-300",alt:""}):e.jsx("div",{className:"w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0",style:{background:n.accentSoft},children:"🏥"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"admin-department-title font-bold text-sm truncate leading-tight mb-1",style:{color:n.text},children:c.name}),e.jsx(ha,{color:n.brand,children:c.category})]})]}),e.jsxs("div",{className:"admin-department-meta flex items-center justify-between text-[11px] font-bold uppercase tracking-wider",style:{color:n.muted},children:[e.jsxs("div",{className:"flex gap-2 flex-wrap",children:[e.jsxs("span",{children:[c.faculty?.length||0," Staff"]}),e.jsxs("span",{children:[c.facilities?.length||0," Labs"]})]}),e.jsx(ma,{size:14,className:"group-hover:translate-x-1 transition-transform",style:{color:n.accent}})]})]})]},c._id)),r.length===0&&e.jsx("div",{className:"col-span-full",children:e.jsx(he,{icon:ce,text:"No departments found"})})]})]})},ji=({editItem:t,formState:a,setFormState:r,closeModal:l,fetchData:p,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{if(s.preventDefault(),!t&&!a.media)return o(`Please select a ${a.mediaType==="video"?"video":"image"}`,"error");const b=new FormData;a.media instanceof File&&b.append("image",a.media),b.append("title",a.title||""),b.append("description",a.description||""),b.append("category",a.category||"college_campus_view"),b.append("mediaType",a.mediaType||"image");const m=t?`/gallery/${t._id}`:"/gallery";try{t?await i.put(m,b):await i.post(m,b),o(t?"Updated":"Created"),l(),p()}catch(k){const h=k.response?.data?.message||"Failed to save gallery item";o(h,"error")}},className:"space-y-5",children:[e.jsx("div",{className:"flex gap-1 p-1 rounded-2xl",style:{background:n.bg,border:`1px solid ${n.border}`},children:["image","video"].map(s=>e.jsxs("button",{type:"button",onClick:()=>r({...a,mediaType:s,media:null}),className:"flex-1 py-2.5 rounded-xl text-sm font-bold transition-all capitalize flex items-center justify-center gap-2",style:{background:a.mediaType===s?n.surface:"transparent",color:a.mediaType===s?n.text:n.muted,boxShadow:a.mediaType===s?"0 1px 6px rgba(0,0,0,0.08)":"none"},children:[s==="image"?e.jsx(Z,{size:15}):e.jsx("span",{style:{fontSize:"15px"},children:"🎬"}),s==="image"?"Image":"Video"]},s))}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Title",required:!0,children:e.jsx(y,{required:!0,value:a.title,onChange:s=>r({...a,title:s.target.value}),placeholder:"e.g. Main Academic Building"})}),e.jsx(x,{label:"Category",children:e.jsxs(xe,{value:a.category,onChange:s=>r({...a,category:s.target.value}),children:[e.jsx("option",{value:"college_campus_view",children:"College Campus View"}),e.jsx("option",{value:"college_highlight",children:"College Highlight"}),e.jsx("option",{value:"hospital",children:"Hospital Main/Additional Images"}),e.jsx("option",{value:"hospital_facility",children:"Hospital Facility & Department"}),e.jsx("option",{value:"event",children:"Main/Additional Event Images"}),e.jsx("option",{value:"event_academic",children:"Academic Events"}),e.jsx("option",{value:"event_cultural",children:"Cultural Events"}),e.jsx("option",{value:"event_sports",children:"Sports Events"}),e.jsx("option",{value:"event_community",children:"Community Service Events"})]})})]}),e.jsx(x,{label:"Description",children:e.jsx(H,{rows:3,value:a.description,onChange:s=>r({...a,description:s.target.value}),placeholder:"Media description..."})}),e.jsxs(x,{label:a.mediaType==="video"?"Video File":"Image File",children:[e.jsx("p",{className:"mb-2 text-xs font-semibold",style:{color:n.muted},children:"Recommended file size: 2–5 MB. Files larger than 5 MB are not accepted."}),e.jsxs("label",{className:"flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-dashed cursor-pointer hover:bg-gray-50 transition",style:{borderColor:a.media?n.accent:n.border},children:[e.jsx("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center shrink-0",style:{background:n.accentSoft},children:a.mediaType==="video"?e.jsx("span",{children:"🎬"}):e.jsx(Z,{size:16,style:{color:n.accent}})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold truncate",style:{color:a.media?n.text:n.muted},children:a.media&&typeof a.media=="object"?a.media.name:`Select ${a.mediaType==="video"?"video":"image"} file`}),e.jsx("p",{className:"text-[11px]",style:{color:n.muted},children:a.mediaType==="video"?"MP4, WebM, OGG, MOV · Max 100MB":"JPG, PNG, WEBP · Max 100MB"})]}),e.jsx("input",{type:"file",className:"hidden",accept:a.mediaType==="video"?"video/mp4,video/webm,video/ogg,video/quicktime":"image/*",onChange:s=>r({...a,media:s.target.files[0]})})]}),a.media&&a.media instanceof File&&(a.mediaType==="video"?e.jsx("video",{src:URL.createObjectURL(a.media),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"180px"}}):e.jsx("img",{src:URL.createObjectURL(a.media),className:"mt-2 h-20 w-20 object-cover rounded-xl border shadow-sm",alt:"preview"})),!a.media&&t&&(t.mediaType==="video"&&t.videoUrl?e.jsx("video",{src:V(t.videoUrl),controls:!0,className:"mt-2 w-full rounded-xl border shadow-sm",style:{maxHeight:"150px"}}):t.imageUrl?e.jsx("img",{src:V(t.imageUrl),className:"mt-2 h-16 w-16 object-cover rounded-xl border shadow-sm",alt:"current"}):null)]}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":a.mediaType==="video"?"Upload Video":"Create Image"})]}),yi=({galleryImages:t,galleryForm:a,setGalleryForm:r,openModal:l,del:p})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:Z,title:"Photo & Video Gallery",subtitle:"Manage all photos and videos in the gallery",action:e.jsx(X,{onClick:()=>{r({title:"",description:"",category:"college_campus_view",mediaType:"image",media:null}),l("gallery")},label:"Add Media"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(o=>e.jsx(be,{left:e.jsx("div",{className:"admin-media-thumb w-16 h-12 rounded-xl overflow-hidden border-2 shrink-0 shadow-sm relative",style:{borderColor:n.border},children:o.mediaType==="video"?e.jsx("div",{className:"w-full h-full flex items-center justify-center",style:{background:"#1a1a2e"},children:e.jsx("span",{style:{fontSize:"20px"},children:"🎬"})}):e.jsx("img",{src:V(o.imageUrl),className:"w-full h-full object-cover",alt:""})}),badge:`${o.mediaType==="video"?"🎬 VIDEO · ":""}${o.category.replace(/_/g," ")}`,title:o.title,sub:o.description?.substring(0,50)+"...",onEdit:()=>{r({...o,mediaType:o.mediaType||"image",media:null}),l("gallery",o)},onDelete:()=>p(`/gallery/${o._id}`)},o._id)),t.length===0&&e.jsx(he,{icon:Z,text:"No gallery media yet. Add your first photo or video."})]})]}),vi=({institutes:t,openModal:a,del:r})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ce,title:"Affiliated Institutes",subtitle:`${t.length} partners registered`,action:e.jsx(X,{onClick:()=>a("institute"),label:"Add Institute"})}),e.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[t.map(l=>e.jsx(be,{left:e.jsx("div",{className:"w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-2xl shadow-sm border border-amber-100",children:l.icon||"🏥"}),badge:l.type,title:l.name,sub:l.capacity,onEdit:()=>a("institute",l),onDelete:()=>r(`/institutes/${l._id}`)},l._id)),t.length===0&&e.jsx(he,{icon:ce,text:"No institutes registered yet"})]})]}),wi=({editItem:t,closeModal:a,fetchData:r,notify:l})=>{const[p,o]=u.useState({name:"",type:"",description:"",description2:"",description3:"",established:"",capacity:"",icon:"🏥",order:0,specialties:"",services:"",contact:{address:"",phone:"",website:""}});u.useEffect(()=>{t&&o({...t,order:t.order||0,specialties:Array.isArray(t.specialties)?t.specialties.join(", "):"",services:Array.isArray(t.services)?t.services.join(", "):"",contact:{address:t.contact?.address||"",phone:t.contact?.phone||"",website:t.contact?.website||""}})},[t]);const i=async s=>{s.preventDefault();const b={...p,specialties:p.specialties.split(",").map(m=>m.trim()).filter(Boolean),services:p.services.split(",").map(m=>m.trim()).filter(Boolean)};try{t?await v.put(`/institutes/${t._id}`,b):await v.post("/institutes",b),l(t?"Updated":"Created"),a(),r()}catch{l("Operation failed","error")}};return e.jsxs("form",{onSubmit:i,className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Institute Name",required:!0,children:e.jsx(y,{required:!0,value:p.name,onChange:s=>o({...p,name:s.target.value}),placeholder:"e.g. Government Spine Institute"})}),e.jsx(x,{label:"Type (e.g. Hospital)",required:!0,children:e.jsx(y,{required:!0,value:p.type,onChange:s=>o({...p,type:s.target.value}),placeholder:"e.g. Educational Institute"})})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-4",children:[e.jsx(x,{label:"Established",children:e.jsx(y,{value:p.established,onChange:s=>o({...p,established:s.target.value}),placeholder:"e.g. 1980"})}),e.jsx(x,{label:"Capacity",children:e.jsx(y,{value:p.capacity,onChange:s=>o({...p,capacity:s.target.value}),placeholder:"e.g. 80 Beds"})}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:p.icon,onChange:s=>o({...p,icon:s.target.value})})}),e.jsx(x,{label:"Sort Order",children:e.jsx(y,{type:"number",required:!0,value:p.order,onChange:s=>o({...p,order:parseInt(s.target.value)||0})})})]}),e.jsx(x,{label:"Main Description",required:!0,children:e.jsx(H,{required:!0,rows:3,value:p.description,onChange:s=>o({...p,description:s.target.value}),placeholder:"Main description..."})}),e.jsx(x,{label:"Additional Description",children:e.jsx(H,{rows:2,value:p.description2,onChange:s=>o({...p,description2:s.target.value}),placeholder:"Extra details..."})}),e.jsx(x,{label:"Clinical Areas (comma separated)",children:e.jsx(H,{rows:2,value:p.specialties,onChange:s=>o({...p,specialties:s.target.value}),placeholder:"e.g. Orthopedics, Spine Surgery"})}),e.jsx(x,{label:"Key Services (comma separated)",children:e.jsx(H,{rows:2,value:p.services,onChange:s=>o({...p,services:s.target.value}),placeholder:"e.g. Emergency, OPD, ICU"})}),e.jsx(ke,{title:"Contact Details",children:e.jsxs("div",{className:"p-4 rounded-2xl bg-white space-y-4 border border-gray-200",children:[e.jsx(x,{label:"Address",children:e.jsx(y,{value:p.contact.address,onChange:s=>o({...p,contact:{...p.contact,address:s.target.value}}),placeholder:"Institute address..."})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Phone",children:e.jsx(y,{value:p.contact.phone,onChange:s=>o({...p,contact:{...p.contact,phone:s.target.value}}),placeholder:"Contact number..."})}),e.jsx(x,{label:"Website",children:e.jsx(y,{value:p.contact.website,onChange:s=>o({...p,contact:{...p.contact,website:s.target.value}}),placeholder:"https://..."})})]})]})}),e.jsx(Y,{onCancel:a,submitLabel:t?"Save Changes":"Create Institute"})]})},Ni=({editItem:t,keyPersonForm:a,setKeyPersonForm:r,closeModal:l,fetchData:p,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{s.preventDefault();const b=t?`/contact/key-persons/${t._id}`:"/contact/key-persons",m={...a,responsibilities:typeof a.responsibilities=="string"?a.responsibilities.split(`
`).filter(Boolean):a.responsibilities};try{t?await i.put(b,m):await i.post(b,m),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:s=>r({...a,name:s.target.value}),placeholder:"Full name"})}),e.jsx(x,{label:"Position",required:!0,children:e.jsx(y,{required:!0,value:a.position,onChange:s=>r({...a,position:s.target.value}),placeholder:"e.g. Principal"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Qualification",children:e.jsx(y,{value:a.qualification,onChange:s=>r({...a,qualification:s.target.value}),placeholder:"e.g. M.Sc. Nursing, Ph.D."})}),e.jsx(x,{label:"Phone",children:e.jsx(y,{value:a.phone,onChange:s=>r({...a,phone:s.target.value}),placeholder:"Phone number"})})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Email",children:e.jsx(y,{value:a.email,onChange:s=>r({...a,email:s.target.value}),placeholder:"Email address"})}),e.jsx(x,{label:"Office Hours",children:e.jsx(y,{value:a.hours,onChange:s=>r({...a,hours:s.target.value}),placeholder:"e.g. 9:00 AM - 5:00 PM"})})]}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:a.icon,onChange:s=>r({...a,icon:s.target.value})})}),e.jsx(x,{label:"Responsibilities (one per line)",required:!0,children:e.jsx(H,{required:!0,rows:4,value:a.responsibilities,onChange:s=>r({...a,responsibilities:s.target.value}),placeholder:`Responsibility 1
Responsibility 2`})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Key Contact"})]}),Ci=({editItem:t,contactDeptForm:a,setContactDeptForm:r,closeModal:l,fetchData:p,notify:o,axiosInstance:i})=>e.jsxs("form",{onSubmit:async s=>{s.preventDefault();const b=t?`/contact/departments/${t._id}`:"/contact/departments";try{t?await i.put(b,a):await i.post(b,a),o("Saved"),l(),p()}catch{o("Failed","error")}},className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Department Name",required:!0,children:e.jsx(y,{required:!0,value:a.name,onChange:s=>r({...a,name:s.target.value}),placeholder:"e.g. Admission Office"})}),e.jsx(x,{label:"Icon Emoji",children:e.jsx(y,{value:a.icon,onChange:s=>r({...a,icon:s.target.value})})})]}),e.jsx(x,{label:"Phone",children:e.jsx(y,{value:a.phone,onChange:s=>r({...a,phone:s.target.value}),placeholder:"Phone number"})}),e.jsx(x,{label:"Email",children:e.jsx(y,{value:a.email,onChange:s=>r({...a,email:s.target.value}),placeholder:"Email address"})}),e.jsx(Y,{onCancel:l,submitLabel:t?"Save Changes":"Add Department Contact"})]}),ki=({contactSub:t,setContactSub:a,keyPersons:r,setKeyPersonForm:l,contactDepartments:p,setContactDeptForm:o,contactInfo:i,setContactInfo:s,openModal:b,del:m,notify:k,axiosInstance:h})=>e.jsxs("div",{className:"space-y-6",children:[e.jsx(Ee,{tabs:["Key Persons","Departments","College Info"],active:t,onChange:a}),t==="Key Persons"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ge,title:"Key Administrative Contacts",subtitle:"Manage main contacts shown on the contact page",action:e.jsx(X,{onClick:()=>{l({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),b("keyPerson")},label:"Add Person"})}),e.jsx("div",{className:"grid grid-cols-1 gap-3",children:r.map(w=>e.jsx(be,{icon:w.icon,title:w.name,sub:w.position,onEdit:()=>{l({...w,responsibilities:w.responsibilities?.join(`
`)||""}),b("keyPerson",w)},onDelete:()=>m(`/contact/key-persons/${w._id}`)},w._id))})]}),t==="Departments"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:ce,title:"Department Contact Directory",subtitle:"Manage specific departments on the contact page",action:e.jsx(X,{onClick:()=>{o({name:"",phone:"",email:"",icon:"📚"}),b("contactDept")},label:"Add Department"})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:p.map(w=>e.jsx(be,{icon:w.icon,title:w.name,sub:w.phone+" | "+w.email,onEdit:()=>{o({...w}),b("contactDept",w)},onDelete:()=>m(`/contact/departments/${w._id}`)},w._id))})]}),t==="College Info"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx(K,{icon:Et,title:"College Contact Information",subtitle:"Address, phone, and general emails"}),e.jsxs("div",{className:"p-6 rounded-2xl space-y-4 shadow-sm",style:{background:n.surface,border:`1px solid ${n.border}`},children:[e.jsx(x,{label:"College Address",children:e.jsx("textarea",{required:!0,rows:4,value:i.address||"",onChange:w=>s({...i,address:w.target.value}),className:`${T} resize-none`,style:q})}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsx(x,{label:"Reception Phone",children:e.jsx("input",{value:i.receptionPhone||"",onChange:w=>s({...i,receptionPhone:w.target.value}),className:T,style:q})}),e.jsx(x,{label:"Ambulance Phone",children:e.jsx("input",{value:i.ambulancePhone||"",onChange:w=>s({...i,ambulancePhone:w.target.value}),className:T,style:q})})]}),e.jsx(x,{label:"General Email",children:e.jsx("input",{value:i.generalEmail||"",onChange:w=>s({...i,generalEmail:w.target.value}),className:T,style:q})}),e.jsx("button",{onClick:async()=>{try{await h.put("/contact/info",i),k("Contact Info Saved")}catch{k("Failed to save","error")}},className:"px-6 py-2.5 rounded-xl text-sm font-bold text-white shadow-md hover:opacity-90",style:{background:n.brand},children:"Save College Info"})]})]})]}),Ai=({notify:t})=>{const{sectionsList:a,loading:r,toggleSection:l,togglePageSections:p,toggleDepartmentSections:o,refreshVisibility:i}=Ct(),[s,b]=u.useState("Home Page"),[m,k]=u.useState("all"),[h,w]=u.useState("");u.useEffect(()=>{typeof i=="function"&&i()},[]);const _=["Home Page","About Us","Admission","Departments","Gallery","Institutes","Student Corner","Contact Us","All Pages"],S=_.reduce((g,f)=>(g[f]=f==="All Pages"?a.length:a.filter(d=>d.page===f).length,g),{}),z=u.useMemo(()=>{const g=new Map;a.filter(d=>d.page==="Departments").forEach(d=>{let c=d.departmentSlug;c||(c=d.sectionKey.replace(/^dept_/,"").replace(/_(overview|facilities|faculty|activities)$/,""));let j=d.departmentName;j||(j=d.sectionName.split(" - ")[0]||c),g.has(c)||g.set(c,{slug:c,name:j,sections:[]}),g.get(c).sections.push(d)});const f={page:1,overview:2,facilities:3,faculty:4,activities:5};return g.forEach(d=>{d.sections.sort((c,j)=>{const D=f[c.subSection]||99,L=f[j.subSection]||99;return D-L})}),Array.from(g.values()).sort((d,c)=>d.name.localeCompare(c.name))},[a]),F=g=>g.subSection==="page"||g.sectionKey.endsWith("_page")||!g.subSection&&!g.sectionKey.includes("_overview")&&!g.sectionKey.includes("_facilities")&&!g.sectionKey.includes("_faculty")&&!g.sectionKey.includes("_activities")?{label:"Entire Page",tag:"Page Access",color:"#6B3F1D",bg:"#FDF0E6",icon:ce}:g.subSection==="overview"||g.sectionKey.endsWith("_overview")?{label:"Overview",tag:"Overview & Vision",color:"#0284C7",bg:"#E0F2FE",icon:Ae}:g.subSection==="facilities"||g.sectionKey.endsWith("_facilities")?{label:"Facilities",tag:"Labs & Equipment",color:"#7C3AED",bg:"#EDE9FE",icon:ve}:g.subSection==="faculty"||g.sectionKey.endsWith("_faculty")?{label:"Faculty",tag:"Faculty & Slider",color:"#D97706",bg:"#FEF3C7",icon:ge}:g.subSection==="activities"||g.sectionKey.endsWith("_activities")?{label:"Activities",tag:"Academic Activities",color:"#059669",bg:"#D1FAE5",icon:me}:{label:"Section",tag:"Section Control",color:"#4B5563",bg:"#F3F4F6",icon:ve},P=u.useMemo(()=>{let g=z;if(m!=="all"&&(g=g.filter(d=>d.slug===m)),!h.trim())return g;const f=h.toLowerCase();return g.map(d=>{if(d.name.toLowerCase().includes(f)||d.slug.toLowerCase().includes(f))return d;const j=d.sections.filter(D=>(D.sectionName||"").toLowerCase().includes(f)||(D.description||"").toLowerCase().includes(f)||(D.sectionKey||"").toLowerCase().includes(f));return j.length>0?{...d,sections:j}:null}).filter(Boolean)},[z,m,h]),N=u.useMemo(()=>a.filter(g=>{if(g.page==="Departments")return!1;const f=s==="All Pages"||g.page===s,d=!h.trim()||(g.sectionName||"").toLowerCase().includes(h.toLowerCase())||(g.description||"").toLowerCase().includes(h.toLowerCase())||(g.sectionKey||"").toLowerCase().includes(h.toLowerCase());return f&&d}),[a,s,h]),A=u.useMemo(()=>N.reduce((g,f)=>(g[f.page]=g[f.page]||[],g[f.page].push(f),g),{}),[N]),C=a.length,O=a.filter(g=>g.isVisible!==!1).length,J=C-O,$=C?Math.round(O/C*100):0,I=s==="Departments"||s==="All Pages",B=s!=="Departments";return e.jsxs("div",{className:"section-control-shell",children:[e.jsx("style",{children:`
        .section-control-shell {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .section-control-hero {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 22px;
          align-items: stretch;
          padding: 22px;
          border: 1px solid #E7DDD2;
          border-radius: 18px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.96), rgba(255,250,246,0.92)),
            linear-gradient(135deg, #6B3F1D, #E07B39);
          box-shadow: 0 18px 42px rgba(65, 42, 22, 0.08);
        }
        .section-control-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-icon {
          width: 46px;
          height: 46px;
          border-radius: 14px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          background: linear-gradient(135deg, #6B3F1D 0%, #A85D2A 100%);
          box-shadow: 0 12px 26px rgba(107, 63, 29, 0.22);
          flex: 0 0 auto;
        }
        .section-control-kicker {
          margin: 0 0 4px;
          color: #8A7A6A;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .section-control-title {
          margin: 0;
          color: #1A1208;
          font-size: 26px;
          line-height: 1.14;
          font-weight: 900;
          letter-spacing: 0;
        }
        .section-control-subtitle {
          margin: 8px 0 0;
          max-width: 660px;
          color: #786859;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.55;
        }
        .section-control-metrics {
          display: grid;
          grid-template-columns: repeat(3, minmax(92px, 1fr));
          gap: 10px;
          min-width: 340px;
        }
        .section-control-metric {
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          box-shadow: 0 10px 24px rgba(65, 42, 22, 0.06);
        }
        .section-control-metric strong {
          display: block;
          color: #1A1208;
          font-size: 25px;
          line-height: 1;
          font-weight: 900;
        }
        .section-control-metric span {
          display: block;
          margin-top: 7px;
          color: #7A6A5B;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .section-control-progress {
          grid-column: 1 / -1;
          height: 8px;
          overflow: hidden;
          border-radius: 99px;
          background: #EFE7DF;
        }
        .section-control-progress > span {
          display: block;
          height: 100%;
          width: var(--section-progress, 0%);
          border-radius: inherit;
          background: linear-gradient(90deg, #16A34A, #E07B39);
        }
        .section-control-toolbar {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(260px, 360px);
          gap: 16px;
          align-items: start;
          padding: 14px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .section-control-tabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          min-width: 0;
        }
        .section-control-tab {
          min-height: 36px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 7px 12px;
          color: #655646;
          background: #FBFAF8;
          font-size: 12px;
          font-weight: 800;
          line-height: 1;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .section-control-tab:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .section-control-tab.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        .section-control-count {
          min-width: 22px;
          height: 22px;
          padding: 0 7px;
          border-radius: 999px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: inherit;
          background: rgba(255,255,255,0.65);
          font-size: 11px;
          font-weight: 900;
        }
        .section-control-tab.is-active .section-control-count {
          background: rgba(255,255,255,0.18);
        }
        .section-control-search {
          position: relative;
          min-width: 0;
        }
        .section-control-search input {
          width: 100%;
          height: 42px;
          border: 1px solid #E6DCD1;
          border-radius: 12px;
          background: #FBFAF8;
          color: #1A1208;
          font-size: 13px;
          font-weight: 650;
          outline: none;
          padding: 0 38px 0 40px;
          transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-search input:focus {
          border-color: #C7773D;
          background: #FFFFFF;
          box-shadow: 0 0 0 4px rgba(224, 123, 57, 0.13);
        }
        .section-control-search svg {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #9A806B;
        }
        .section-control-clear {
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 26px;
          height: 26px;
          border-radius: 8px;
          color: #8A7A6A;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .section-control-clear:hover {
          background: #EFE7DF;
          color: #1A1208;
        }

        /* Department Filter Pills */
        .dept-filter-bar {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding: 12px 14px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FBFAF8;
        }
        .dept-filter-pill {
          min-height: 32px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 6px 12px;
          color: #655646;
          background: #FFFFFF;
          font-size: 12px;
          font-weight: 750;
          line-height: 1;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease;
        }
        .dept-filter-pill:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .dept-filter-pill.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 8px 18px rgba(107, 63, 29, 0.18);
        }
        .dept-filter-pill.is-active .dept-filter-count {
          background: rgba(255,255,255,0.22);
          color: #FFFFFF;
        }
        .dept-filter-count {
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 999px;
          background: #F1ECE6;
          color: #796858;
          font-weight: 800;
        }

        .section-control-loading {
          min-height: 280px;
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          color: #8A7A6A;
          font-size: 14px;
          font-weight: 800;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
        }
        .section-control-spinner {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          border: 3px solid #E8E0D8;
          border-top-color: #6B3F1D;
          animation: section-spin 800ms linear infinite;
        }
        @keyframes section-spin {
          to { transform: rotate(360deg); }
        }
        .section-control-groups {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        .section-control-group {
          border: 1px solid #E8E0D8;
          border-radius: 18px;
          background: #FFFFFF;
          box-shadow: 0 16px 38px rgba(65, 42, 22, 0.06);
          overflow: hidden;
        }
        .section-control-group-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 18px;
          border-bottom: 1px solid #EFE7DF;
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFCFA 100%);
        }
        .section-control-group-title {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .section-control-group-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          color: #6B3F1D;
          background: #FDF0E6;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
        }
        .section-control-group-title h3 {
          margin: 0;
          color: #1A1208;
          font-size: 16px;
          line-height: 1.2;
          font-weight: 900;
        }
        .section-control-group-title p {
          margin: 4px 0 0;
          color: #8A7A6A;
          font-size: 12px;
          font-weight: 700;
        }
        .dept-meta-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-top: 4px;
          flex-wrap: wrap;
        }
        .dept-slug-badge {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          font-size: 11px;
          font-weight: 700;
          padding: 2px 7px;
          border-radius: 6px;
          background: #F5EFE9;
          color: #6B3F1D;
          border: 1px solid #E8DDD2;
        }
        .dept-stat-badge {
          font-size: 11px;
          font-weight: 800;
          padding: 2px 8px;
          border-radius: 999px;
        }
        .dept-stat-badge.is-all {
          background: #ECFDF3;
          color: #146C3E;
          border: 1px solid #B8E7CA;
        }
        .dept-stat-badge.is-partial {
          background: #FFFBEB;
          color: #B45309;
          border: 1px solid #FDE68A;
        }
        .dept-stat-badge.is-none {
          background: #FFF1F1;
          color: #A13434;
          border: 1px solid #F4C7C7;
        }

        .section-control-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 0 0 auto;
        }
        .section-control-action {
          height: 34px;
          border: 1px solid transparent;
          border-radius: 10px;
          padding: 0 12px;
          font-size: 12px;
          font-weight: 900;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
        }
        .section-control-action:hover {
          transform: translateY(-1px);
        }
        .section-control-action.on {
          color: #146C3E;
          background: #ECFDF3;
          border-color: #B8E7CA;
        }
        .section-control-action.off {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-control-list {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          padding: 16px;
        }
        .section-control-card {
          position: relative;
          min-width: 0;
          min-height: 108px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 14px;
          align-items: center;
          padding: 16px 16px 16px 18px;
          border: 1px solid #E8E0D8;
          border-radius: 14px;
          background: #FFFFFF;
          transition: transform 160ms ease, border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
        }
        .section-control-card::before {
          content: "";
          position: absolute;
          left: 0;
          top: 12px;
          bottom: 12px;
          width: 4px;
          border-radius: 0 999px 999px 0;
          background: #16A34A;
        }
        .section-control-card:hover {
          transform: translateY(-1px);
          border-color: #D8C8B7;
          box-shadow: 0 14px 28px rgba(65, 42, 22, 0.08);
        }
        .section-control-card.is-hidden {
          background: #FBFAF8;
        }
        .section-control-card.is-hidden::before {
          background: #D94B4B;
        }
        .section-control-card-copy {
          min-width: 0;
        }
        .section-control-status-row {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
          margin-bottom: 9px;
          flex-wrap: wrap;
        }
        .section-control-status {
          min-width: 68px;
          border-radius: 999px;
          padding: 4px 8px;
          color: #146C3E;
          background: #ECFDF3;
          border: 1px solid #B8E7CA;
          font-size: 10px;
          font-weight: 950;
          line-height: 1;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-align: center;
          flex: 0 0 auto;
        }
        .section-control-card.is-hidden .section-control-status {
          color: #A13434;
          background: #FFF1F1;
          border-color: #F4C7C7;
        }
        .section-sub-tag {
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.04em;
          padding: 4px 8px;
          border-radius: 6px;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          flex: 0 0 auto;
        }
        .section-control-key {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          border: 1px solid #E7DDD2;
          border-radius: 8px;
          padding: 4px 8px;
          color: #725B45;
          background: #FFF8F1;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
          font-size: 11px;
          line-height: 1.2;
        }
        .section-control-card h4 {
          margin: 0;
          color: #1A1208;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 900;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .section-control-card p {
          margin: 5px 0 0;
          color: #756657;
          font-size: 12px;
          line-height: 1.45;
          font-weight: 600;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .section-toggle {
          width: 58px;
          height: 32px;
          border: 0;
          border-radius: 999px;
          background: #16A34A;
          padding: 3px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: flex-end;
          box-shadow: inset 0 0 0 1px rgba(0,0,0,0.08);
          transition: background 180ms ease;
        }
        .section-toggle.is-off {
          justify-content: flex-start;
          background: #CBD5E1;
        }
        .section-toggle span {
          width: 26px;
          height: 26px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #16A34A;
          background: #FFFFFF;
          box-shadow: 0 3px 8px rgba(0,0,0,0.18);
        }
        .section-toggle.is-off span {
          color: #64748B;
        }
        @media (max-width: 1180px) {
          .section-control-hero,
          .section-control-toolbar {
            grid-template-columns: 1fr;
          }
          .section-control-metrics {
            min-width: 0;
          }
        }
        @media (max-width: 860px) {
          .section-control-list {
            grid-template-columns: 1fr;
          }
          .section-control-group-head {
            align-items: flex-start;
            flex-direction: column;
          }
          .section-control-actions {
            width: 100%;
          }
          .section-control-action {
            flex: 1 1 0;
          }
        }
        @media (max-width: 560px) {
          .section-control-hero,
          .section-control-toolbar {
            padding: 14px;
            border-radius: 14px;
          }
          .section-control-title {
            font-size: 21px;
          }
          .section-control-title-row {
            align-items: flex-start;
          }
          .section-control-metrics {
            grid-template-columns: 1fr;
          }
          .section-control-card {
            grid-template-columns: 1fr;
          }
          .section-toggle {
            width: 100%;
            justify-content: flex-end;
          }
          .section-toggle.is-off {
            justify-content: flex-start;
          }
          .section-control-tabs {
            flex-wrap: nowrap;
            overflow-x: auto;
            padding-bottom: 2px;
          }
        }
      `}),e.jsxs("div",{className:"section-control-hero",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"section-control-title-row",children:[e.jsx("div",{className:"section-control-icon",children:e.jsx(ga,{size:22})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"section-control-kicker",children:"Site Content Manager"}),e.jsx("h2",{className:"section-control-title",children:"Section Visibility"})]})]}),e.jsx("p",{className:"section-control-subtitle",children:"Live control for public page sections & individual department modules (Full Page, Overview, Facilities, Faculty, Activities)."})]}),e.jsxs("div",{className:"section-control-metrics",children:[e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{children:C}),e.jsx("span",{children:"Total Sections"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#16A34A"},children:O}),e.jsx("span",{children:"Visible"})]}),e.jsxs("div",{className:"section-control-metric",children:[e.jsx("strong",{style:{color:"#D94B4B"},children:J}),e.jsx("span",{children:"Hidden"})]}),e.jsx("div",{className:"section-control-progress",style:{"--section-progress":`${$}%`},children:e.jsx("span",{})})]})]}),e.jsxs("div",{className:"section-control-toolbar",children:[e.jsx("div",{className:"section-control-tabs",children:_.map(g=>{const f=s===g;return e.jsxs("button",{type:"button",onClick:()=>{b(g),g==="Departments"&&k("all")},className:`section-control-tab ${f?"is-active":""}`,children:[g,e.jsx("span",{className:"section-control-count",children:S[g]})]},g)})}),e.jsxs("div",{className:"section-control-search",children:[e.jsx(Vt,{size:16}),e.jsx("input",{type:"text",placeholder:"Search sections or departments...",value:h,onChange:g=>w(g.target.value)}),h&&e.jsx("button",{type:"button",className:"section-control-clear",onClick:()=>w(""),"aria-label":"Clear search",children:e.jsx(oe,{size:15})})]})]}),s==="Departments"&&z.length>0&&e.jsxs("div",{className:"dept-filter-bar",children:[e.jsxs("span",{className:"text-xs font-bold text-stone-500 flex items-center gap-1.5 self-center mr-1",children:[e.jsx(ce,{size:14})," Filter Dept:"]}),e.jsxs("button",{type:"button",onClick:()=>k("all"),className:`dept-filter-pill ${m==="all"?"is-active":""}`,children:["All Departments",e.jsx("span",{className:"dept-filter-count",children:z.length})]}),z.map(g=>{const f=g.sections.filter(c=>c.isVisible!==!1).length,d=m===g.slug;return e.jsxs("button",{type:"button",onClick:()=>k(g.slug),className:`dept-filter-pill ${d?"is-active":""}`,title:g.name,children:[g.name.replace(/^Department of\s+/i,""),e.jsxs("span",{className:"dept-filter-count",children:[f,"/",g.sections.length]})]},g.slug)})]}),r?e.jsxs("div",{className:"section-control-loading",children:[e.jsx("span",{className:"section-control-spinner"}),"Loading visibility settings..."]}):e.jsxs("div",{className:"section-control-groups",children:[B&&Object.entries(A).map(([g,f])=>e.jsxs("div",{className:"section-control-group",children:[e.jsxs("div",{className:"section-control-group-head",children:[e.jsxs("div",{className:"section-control-group-title",children:[e.jsx("div",{className:"section-control-group-icon",children:e.jsx(ve,{size:20})}),e.jsxs("div",{children:[e.jsx("h3",{children:g}),e.jsxs("p",{children:[f.length," sections configured"]})]})]}),e.jsxs("div",{className:"section-control-actions",children:[e.jsxs("button",{type:"button",onClick:async()=>{try{await p(g,!0),t(`Turned ALL sections ON for ${g}`)}catch{t("Update failed","error")}},className:"section-control-action on",children:[e.jsx(de,{size:14})," All ON"]}),e.jsxs("button",{type:"button",onClick:async()=>{try{await p(g,!1),t(`Turned ALL sections OFF for ${g}`)}catch{t("Update failed","error")}},className:"section-control-action off",children:[e.jsx(oe,{size:14})," All OFF"]})]})]}),e.jsx("div",{className:"section-control-list",children:f.map(d=>{const c=d.isVisible!==!1;return e.jsxs("div",{className:`section-control-card ${c?"":"is-hidden"}`,children:[e.jsxs("div",{className:"section-control-card-copy",children:[e.jsxs("div",{className:"section-control-status-row",children:[e.jsx("span",{className:"section-control-status",children:c?"Visible":"Hidden"}),e.jsx("span",{className:"section-control-key",children:d.sectionKey})]}),e.jsx("h4",{children:d.sectionName}),d.description&&e.jsx("p",{children:d.description})]}),e.jsx("button",{type:"button","aria-pressed":c,"aria-label":`Toggle ${d.sectionName}`,onClick:async()=>{try{await l(d.sectionKey,!c),t(`${d.sectionName} is now ${c?"OFF (Hidden)":"ON (Visible)"}`)}catch{t("Update failed","error")}},className:`section-toggle ${c?"":"is-off"}`,children:e.jsx("span",{children:c?e.jsx(de,{size:15}):e.jsx(oe,{size:15})})})]},d.sectionKey)})})]},g)),I&&e.jsxs(e.Fragment,{children:[s==="All Pages"&&e.jsxs("div",{className:"flex items-center gap-3 pt-4 pb-1",children:[e.jsx("div",{className:"h-px bg-stone-300 flex-1"}),e.jsxs("span",{className:"text-xs font-black uppercase tracking-widest text-stone-500 flex items-center gap-2",children:[e.jsx(me,{size:16})," Department-Wise Section Controls (",z.length," Departments)"]}),e.jsx("div",{className:"h-px bg-stone-300 flex-1"})]}),P.length===0?e.jsx(he,{icon:De,text:"No departments or sections found matching search/filter."}):P.map(g=>{const f=g.sections.filter(D=>D.isVisible!==!1).length,d=g.sections.length,c=f===d,j=f===0;return e.jsxs("div",{className:"section-control-group",children:[e.jsxs("div",{className:"section-control-group-head",children:[e.jsxs("div",{className:"section-control-group-title",children:[e.jsx("div",{className:"section-control-group-icon",style:{background:"#FDF0E6",color:"#6B3F1D"},children:e.jsx(me,{size:22})}),e.jsxs("div",{children:[e.jsx("h3",{children:g.name}),e.jsxs("div",{className:"dept-meta-row",children:[e.jsxs("span",{className:"dept-slug-badge",children:["/department-",g.slug]}),e.jsxs("span",{className:`dept-stat-badge ${c?"is-all":j?"is-none":"is-partial"}`,children:[f," of ",d," Sections Visible"]})]})]})]}),e.jsxs("div",{className:"section-control-actions",children:[e.jsxs("button",{type:"button",onClick:async()=>{try{await o(g.slug,!0),t(`Turned ALL sections ON for ${g.name}`)}catch{t("Update failed","error")}},className:"section-control-action on",children:[e.jsx(de,{size:14})," All ON"]}),e.jsxs("button",{type:"button",onClick:async()=>{try{await o(g.slug,!1),t(`Turned ALL sections OFF for ${g.name}`)}catch{t("Update failed","error")}},className:"section-control-action off",children:[e.jsx(oe,{size:14})," All OFF"]})]})]}),e.jsx("div",{className:"section-control-list",children:g.sections.map(D=>{const L=D.isVisible!==!1,ae=F(D),ue=ae.icon;return e.jsxs("div",{className:`section-control-card ${L?"":"is-hidden"}`,children:[e.jsxs("div",{className:"section-control-card-copy",children:[e.jsxs("div",{className:"section-control-status-row",children:[e.jsx("span",{className:"section-control-status",children:L?"Visible":"Hidden"}),e.jsxs("span",{className:"section-sub-tag",style:{background:ae.bg,color:ae.color},children:[e.jsx(ue,{size:11})," ",ae.tag]}),e.jsx("span",{className:"section-control-key",children:D.sectionKey})]}),e.jsx("h4",{children:D.sectionName}),D.description&&e.jsx("p",{children:D.description})]}),e.jsx("button",{type:"button","aria-pressed":L,"aria-label":`Toggle ${D.sectionName}`,onClick:async()=>{try{await l(D.sectionKey,!L),t(`${D.sectionName} is now ${L?"OFF (Hidden)":"ON (Visible)"}`)}catch{t("Update failed","error")}},className:`section-toggle ${L?"":"is-off"}`,children:e.jsx("span",{children:L?e.jsx(de,{size:15}):e.jsx(oe,{size:15})})})]},D.sectionKey)})})]},g.slug)})]}),!I&&Object.keys(A).length===0&&e.jsx(he,{icon:De,text:"No sections found matching filter search."})]})]})},Si=({onLogout:t})=>{const[a,r]=u.useState("Home Page"),[l,p]=u.useState("Branding"),[o,i]=u.useState("Courses"),[s,b]=u.useState("Overview"),[m,k]=u.useState("Key Persons"),[h,w]=u.useState(!1),[_,S]=u.useState("null"),[z,F]=u.useState(null),[P,N]=u.useState(!1),[A,C]=u.useState(null),[O,J]=u.useState(!1),[$,I]=u.useState(!1),[B,g]=u.useState(""),[f,d]=u.useState(null),[c,j]=u.useState(window.innerWidth<1024);u.useEffect(()=>{const E=()=>j(window.innerWidth<1024);return window.addEventListener("resize",E),()=>window.removeEventListener("resize",E)},[]);const[D,L]=u.useState([]),[ae,ue]=u.useState([]),[te,pe]=u.useState([]),[Be,Ce]=u.useState({title:"",description1:"",description2:""}),[ya,Pe]=u.useState([]),[va,Ue]=u.useState({name:"",title:"",greeting:"",paragraphs:[],highlight:"",photoUrl:"",stats:[]}),[wa,$e]=u.useState({logoUrl:"",collegeName:"",tagline:""}),[Na,_e]=u.useState([]),[Ca,Te]=u.useState({heroTitle:"Our History",timelineTitle:"Institutional Timeline",timelineParagraphs:[],legacyTitle:"Legacy of Excellence",legacyParagraphs:[]}),[ka,Aa]=u.useState([]),[Da,Ea]=u.useState([]),[Sa,Fa]=u.useState([]),[za,Ba]=u.useState([]),[Pa,Ua]=u.useState([]),[$a,_a]=u.useState([]),[Ta,qa]=u.useState([]),[qe,La]=u.useState([]),[Ha,Oa]=u.useState([]),[Ra,Ma]=u.useState([]),[Ga,Va]=u.useState([]),[Wa,Le]=u.useState({address:"",receptionPhone:"",ambulancePhone:"",generalEmail:""}),[Ya,He]=u.useState({title:"",description:"",duration:"",category:"Undergraduate",courses:"",image:null}),[Oe,Re]=u.useState({name:"",role:"",content:"",rating:5,image:null}),[Me,Ge]=u.useState({year:"",event:"",icon:"🎯",color:"#1e3a8a",description:"",order:0}),[Ka,Ve]=u.useState({type:"vision",content:"",order:0}),[Ja,We]=u.useState({icon:"🌟",title:"",description:"",color:"from-amber-500 to-orange-500",order:0}),[Ia,Ye]=u.useState({category:"Undergraduate Programs",name:"",duration:"",seats:"",eligibility:"",description:"",icon:"👨‍⚕️",highlights:"",fees:"",admission:"",websiteLink:""}),[Qa,Ke]=u.useState({step:1,title:"",description:"",details:"",icon:"Calendar"}),[Xa,Je]=u.useState({category:"UnderGraduated Programs",title:"",description:"",icon:"CheckCircle"}),[Za,Ie]=u.useState({type:"student",title:"",content:"",order:0}),[et,Qe]=u.useState({category:"General Guidelines",subCategory:"",points:"",order:0}),[Xe,Ze]=u.useState({name:"",slug:"",category:"Nursing Department",description:"",overview:"",overview2:"",faculty:[],facilities:[],activities:[],icon:"🏥"}),[at,tt]=u.useState({name:"",designation:"",qualification:"",specialization:"",description:"",imageUrl:""}),[it,st]=u.useState(""),[rt,nt]=u.useState(""),[lt,ot]=u.useState(null),[dt,ct]=u.useState(null),[pt,xt]=u.useState({}),[mt,gt]=u.useState([]),[ea,aa]=u.useState({title:"",description:"",category:"college_campus_view",image:null}),[ht,ta]=u.useState({name:"",position:"",qualification:"",phone:"",email:"",hours:"",icon:"👨‍⚕️",color:"from-blue-500 to-blue-600",responsibilities:""}),[ut,ia]=u.useState({name:"",phone:"",email:"",icon:"📚"}),[bt,sa]=u.useState([]),[ft,ra]=u.useState({title:"",subtitle:"",tag:"",icon:"📄",color:"#F59E0B",borderColor:"#FCD34D",badgeColor:"#D97706",items:[],description:"",order:0}),U=(E,le="success")=>{C({message:E,type:le}),setTimeout(()=>C(null),3e3)};u.useEffect(()=>{R()},[]);const R=async()=>{N(!0);try{const E=await Promise.all([v.get("/programs"),v.get("/testimonials"),v.get("/content/academic"),v.get("/about/milestones"),v.get("/about/dean"),v.get("/about/college-logo"),v.get("/about/images"),v.get("/about/vision-mission"),v.get("/about/core-values"),v.get("/courses"),v.get("/admission-steps"),v.get("/admission-rules"),v.get("/bonds"),v.get("/guidelines"),v.get("/departments"),v.get("/sliders?department=all"),v.get("/gallery"),v.get("/institutes"),v.get("/contact/key-persons"),v.get("/contact/departments"),v.get("/contact/info"),v.get("/about/history-content")]);ue(E[0].data),pe(E[1].data),Ce(E[2].data),Pe(E[3].data),Ue(E[4].data),$e(E[5].data),_e(E[6].data),Aa(E[7].data),Ea(E[8].data),Fa(E[9].data),Ba(E[10].data),Ua(E[11].data),_a(E[12].data),qa(E[13].data),La(E[14].data),L(E[15].data),gt(E[16].data),Oa(E[17].data),Ma(E[18].data),Va(E[19].data),Le(E[20].data),E[21]?.data&&Te(E[21].data)}catch{U("Error fetching data","error")}finally{try{const{data:E}=await v.get("/student-corner");sa(Array.isArray(E)?E:[])}catch{sa([]),U("Unable to load Student Corner data","error")}N(!1)}},se=async(E,le=!0)=>{if(window.confirm("Are you sure?"))try{await v.delete(E),U("Deleted"),le&&R()}catch{U("Delete failed","error")}},na=async(E,le)=>{const je=Array.from(E.target?.files||[E]);if(!je.length)return;const Se=new FormData;je.forEach(vt=>Se.append("images",vt));const oa=le||_;oa!=="null"&&Se.append("department",oa);try{await v.post("/sliders/upload",Se),U("Uploaded"),R()}catch{U("Upload failed","error")}},jt=async(E,le)=>{const je=new FormData;je.append("image",le);try{await v.put(`/sliders/${E}`,je),U("Updated"),R()}catch{U("Update failed","error")}},ne=(E,le=null)=>{g(E),d(le),J(!0)},G=()=>{J(!1),d(null)},yt=[{name:"Section Control",icon:ga},{name:"Home Page",icon:Z},{name:"Academic",icon:Ae},{name:"Testimonials",icon:ge},{name:"About Us",icon:Fe},{name:"Admission",icon:ve},{name:"Departments",icon:ce},{name:"Institutes",icon:ce},{name:"Gallery",icon:Z},{name:"Student Corner",icon:me},{name:"Contact Us",icon:wt},{name:"Settings",icon:ca}],la={program:{title:f?"Edit Program":"Add Program",subtitle:"Academic program details"},testimonial:{title:f?"Edit Testimonial":"Add Testimonial",subtitle:"Student review"},milestone:{title:f?"Edit Milestone":"Add Milestone",subtitle:"Timeline entry"},visionMission:{title:f?"Edit Point":"Add Point",subtitle:"Vision or Mission statement"},coreValue:{title:f?"Edit Value":"Add Core Value",subtitle:"Institutional value"},course:{title:f?"Edit Course":"Add Course",subtitle:"Admission course"},step:{title:f?"Edit Step":"Add Step",subtitle:"Admission procedure step"},rule:{title:f?"Edit Rule":"Add Rule",subtitle:"Eligibility rule"},bond:{title:f?"Edit Bond":"Add Bond Point",subtitle:"Student bond"},guideline:{title:f?"Edit Guidelines":"Add Guidelines",subtitle:"Student / parent guidance"},department:{title:f?"Edit Dept":"Add Department",subtitle:"Create a new department"},gallery:{title:f?"Edit Photo":"Add Photo",subtitle:"Gallery image"},institute:{title:f?"Edit Institute":"Add Institute",subtitle:"Affiliated institute details"},keyPerson:{title:f?"Edit Contact":"Add Contact",subtitle:"Key administrative contact"},contactDept:{title:f?"Edit Dept":"Add Dept",subtitle:"Contact department"},studentCorner:{title:f?"Edit Section":"Add Section",subtitle:"Student Corner document section"}}[B]||{};return e.jsxs("div",{className:"admin-shell flex flex-1 h-full w-full min-h-0 bg-gray-50 text-gray-900 font-sans overflow-hidden relative items-stretch",style:{display:"flex",height:"100dvh",minHeight:"100dvh",maxHeight:"100dvh",width:"100%",overflow:"hidden"},children:[e.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
        * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
        html, body, #root {
          height: 100%;
        }
        body:has(.admin-shell) {
          overflow: hidden;
        }
        .admin-shell {
          display: flex !important;
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-sidebar {
          height: 100dvh !important;
          max-height: 100dvh !important;
          overflow: hidden !important;
          background:
            linear-gradient(180deg, #6B3F1D 0%, #633815 46%, #4E2B12 100%) !important;
          box-shadow: inset -1px 0 0 rgba(255,255,255,0.07);
        }
        .admin-sidebar nav button {
          min-height: 46px;
          border: 1px solid transparent;
        }
        .admin-sidebar nav button:hover {
          background: rgba(255,255,255,0.09) !important;
          color: rgba(255,255,255,0.9) !important;
          border-color: rgba(255,255,255,0.08);
        }
        .admin-sidebar nav button[style*="rgba(255,255,255,0.12)"] {
          background: rgba(255,255,255,0.15) !important;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 12px 24px rgba(37, 22, 10, 0.16);
        }
        .admin-main {
          display: flex !important;
          flex-direction: column !important;
          flex: 1 1 auto !important;
          min-width: 0 !important;
          min-height: 0 !important;
          height: 100dvh !important;
          overflow: hidden !important;
        }
        .admin-header {
          height: 64px !important;
          min-height: 64px !important;
        }
        .admin-content-scroll {
          flex: 1 1 auto !important;
          min-height: 0 !important;
          height: calc(100dvh - 64px) !important;
          overflow-y: auto !important;
          overflow-x: hidden !important;
          overscroll-behavior: contain;
        }
        .admin-page-inner {
          width: 100%;
          max-width: 1580px !important;
        }
        @media (max-width: 1023px) {
          .admin-header {
            height: 56px !important;
            min-height: 56px !important;
          }
          .admin-content-scroll {
            height: calc(100dvh - 56px) !important;
          }
        }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        /* Premium admin scrollbar */
        .admin-scroll::-webkit-scrollbar { width: 8px; }
        .admin-scroll::-webkit-scrollbar-track { background: #F4F1EE; border-radius: 10px; }
        .admin-scroll::-webkit-scrollbar-thumb { background: #C4A882; border-radius: 10px; border: 2px solid #F4F1EE; }
        .admin-scroll::-webkit-scrollbar-thumb:hover { background: #6B3F1D; }
        .admin-scroll { scrollbar-width: thin; scrollbar-color: #C4A882 #F4F1EE; -webkit-overflow-scrolling: touch; }
        .admin-header {
          background:
            linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,252,249,0.96)) !important;
          box-shadow: 0 1px 0 rgba(232, 224, 216, 0.78), 0 10px 30px rgba(65, 42, 22, 0.04);
        }
        .admin-header h2 {
          letter-spacing: 0;
        }
        .admin-header-chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          height: 32px;
          padding: 0 12px;
          border: 1px solid #EEE2D6;
          border-radius: 999px;
          color: #6B3F1D;
          background: #FFF8F1;
          font-size: 12px;
          font-weight: 800;
        }
        .admin-header-dot {
          width: 8px;
          height: 8px;
          border-radius: 999px;
          background: #16A34A;
          box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.12);
        }
        .admin-content-scroll {
          background:
            radial-gradient(circle at top right, rgba(224, 123, 57, 0.07), transparent 34%),
            linear-gradient(180deg, #F8F6F3 0%, #F4F1EE 100%);
        }
        .admin-section-header,
        .admin-row-item,
        .admin-department-card {
          border-radius: 18px !important;
          box-shadow: 0 14px 32px rgba(65, 42, 22, 0.055);
        }
        .admin-section-header {
          min-height: 76px;
          background:
            linear-gradient(135deg, rgba(255,255,255,0.98), rgba(255,248,241,0.88)) !important;
        }
        .admin-section-icon,
        .admin-row-icon {
          box-shadow: inset 0 0 0 1px rgba(224, 123, 57, 0.12);
        }
        .admin-section-title,
        .admin-row-title,
        .admin-department-title {
          letter-spacing: 0;
        }
        .admin-section-subtitle,
        .admin-row-subtitle {
          font-weight: 600;
        }
        .admin-add-btn {
          min-height: 38px;
          border-radius: 999px !important;
          padding-inline: 16px !important;
          background: linear-gradient(135deg, #6B3F1D 0%, #8A4E23 100%) !important;
          box-shadow: 0 12px 22px rgba(107, 63, 29, 0.18);
          white-space: nowrap;
        }
        .admin-icon-btn {
          width: 36px;
          height: 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(226, 217, 208, 0.82);
          border-radius: 12px !important;
          box-shadow: 0 6px 14px rgba(17, 24, 39, 0.04);
        }
        .admin-icon-btn.is-danger {
          border-color: rgba(254, 226, 226, 0.95);
        }
        .admin-row-item {
          min-height: 82px;
          background: rgba(255,255,255,0.96) !important;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-row-item:hover {
          transform: translateY(-2px);
          border-color: #D8C6B4 !important;
          box-shadow: 0 18px 38px rgba(65, 42, 22, 0.085);
        }
        .admin-row-actions {
          padding-left: 12px;
        }
        .admin-pill {
          border-radius: 999px !important;
          text-transform: none !important;
          letter-spacing: 0 !important;
          font-size: 12px !important;
          line-height: 1.15;
          padding: 5px 10px !important;
        }
        .admin-department-grid {
          align-items: stretch;
        }
        .admin-department-card {
          min-height: 178px;
          background: rgba(255,255,255,0.96) !important;
          cursor: default;
          transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
        }
        .admin-department-card:hover {
          border-color: #D8C6B4 !important;
          box-shadow: 0 20px 44px rgba(65, 42, 22, 0.1);
        }
        .admin-department-body {
          align-items: flex-start;
        }
        .admin-department-body > :first-child,
        .admin-media-thumb {
          box-shadow: 0 8px 18px rgba(65, 42, 22, 0.08);
        }
        .admin-department-title {
          white-space: normal !important;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
          min-height: 38px;
          font-size: 15px !important;
          line-height: 1.28 !important;
        }
        .admin-department-meta {
          margin-top: auto;
          padding-top: 14px;
          border-top: 1px solid #F0E7DF;
          letter-spacing: 0 !important;
          text-transform: none !important;
          font-size: 13px !important;
        }
        .admin-department-meta span {
          display: inline-flex;
          align-items: center;
          min-height: 24px;
          padding: 4px 9px;
          border-radius: 999px;
          color: #6F6254;
          background: #F7F2ED;
        }
        .admin-media-thumb {
          width: 72px !important;
          height: 52px !important;
          border-width: 1px !important;
        }
        .admin-subtabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding: 10px;
          border: 1px solid #E8E0D8;
          border-radius: 16px;
          background: #FFFFFF;
          box-shadow: 0 12px 30px rgba(65, 42, 22, 0.05);
        }
        .admin-subtabs button {
          min-height: 38px;
          border: 1px solid #E6DCD1;
          border-radius: 999px;
          padding: 8px 15px;
          color: #655646;
          background: #FBFAF8;
          font-size: 13px;
          font-weight: 850;
          line-height: 1;
          cursor: pointer;
          white-space: nowrap;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease, color 160ms ease, box-shadow 160ms ease;
        }
        .admin-subtabs button:hover {
          transform: translateY(-1px);
          border-color: #CFB69D;
          background: #FFF7EF;
        }
        .admin-subtabs button.is-active {
          color: #FFFFFF;
          border-color: #6B3F1D;
          background: #6B3F1D;
          box-shadow: 0 10px 22px rgba(107, 63, 29, 0.18);
        }
        @media (max-width: 640px) {
          .admin-section-header {
            padding: 16px !important;
          }
          .admin-add-btn {
            width: 100%;
            justify-content: center;
          }
          .admin-row-item {
            align-items: flex-start;
            gap: 12px;
            padding: 14px !important;
          }
          .admin-row-actions {
            opacity: 1 !important;
            padding-left: 0;
          }
          .admin-icon-btn {
            width: 34px;
            height: 34px;
          }
          .admin-subtabs {
            flex-wrap: nowrap;
            overflow-x: auto;
          }
        }
      `}),e.jsx(ci,{isMobile:c,sidebarOpen:h,setSidebarOpen:w,activeTab:a,setActiveTab:r,selectedDept:z,setSelectedDept:F,navItems:yt,onLogout:t}),e.jsxs("main",{className:"admin-main flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-gray-50",style:{height:"100dvh",minHeight:0,overflow:"hidden"},children:[e.jsx(xi,{setSidebarOpen:w,selectedDept:z,activeTab:a,onOpenResetPassword:()=>I(!0)}),e.jsx(It,{note:A,onDismiss:()=>C(null)}),e.jsx("div",{className:"admin-content-scroll flex-1 min-h-0 overflow-y-auto admin-scroll p-4 md:p-6 lg:p-8",children:e.jsxs("div",{className:"admin-page-inner max-w-7xl mx-auto pb-24",children:[P&&e.jsx("div",{className:"absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm",children:e.jsx("div",{className:"w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"})}),e.jsx(fe,{mode:"wait",children:e.jsxs(ie.div,{initial:{opacity:0,y:12},animate:{opacity:1,y:0},exit:{opacity:0,y:-12},transition:{duration:.25},children:[a==="Section Control"&&e.jsx(Ai,{notify:U}),a==="Home Page"&&e.jsx(mi,{selectedDeptForSlider:_,setSelectedDeptForSlider:S,departments:qe,sliders:D,handleSliderUpload:na,updateSliderImage:jt,del:se}),a==="Academic"&&e.jsx(gi,{programs:ae,academicContent:Be,setAcademicContent:Ce,axiosInstance:v,notify:U,openModal:ne,setProgramForm:He,del:se}),a==="Testimonials"&&e.jsx(hi,{testimonials:te,testimonialForm:Oe,setTestimonialForm:Re,openModal:ne,del:se}),a==="About Us"&&e.jsx(ui,{aboutSub:l,setAboutSub:p,collegeLogo:wa,setCollegeLogo:$e,logoFile:dt,setLogoFile:ct,deanMessage:va,setDeanMessage:Ue,deanPhotoFile:lt,setDeanPhotoFile:ot,milestones:ya,milestoneForm:Me,setMilestoneForm:Ge,openModal:ne,setMilestones:Pe,visionMission:ka,setVmForm:Ve,coreValues:Da,setCvForm:We,aboutImages:Na,setAboutImages:_e,aboutImageFiles:pt,setAboutImageFiles:xt,historyContent:Ca,setHistoryContent:Te,axiosInstance:v,notify:U,del:se}),a==="Admission"&&e.jsx(bi,{admSub:o,setAdmSub:i,courses:Sa,openModal:ne,setCourseForm:Ye,del:se,admissionSteps:za,setStepForm:Ke,admissionRules:Pa,setRuleForm:Je,bonds:$a,setBondForm:Ie,guidelines:Ta,setGuidelineForm:Qe}),a==="Departments"&&e.jsx(fi,{selectedDept:z,setSelectedDept:F,departments:qe,deptForm:Xe,setDeptForm:Ze,deptSub:s,setDeptSub:b,deptFacultyForm:at,setDeptFacultyForm:tt,deptFacilityInput:it,setDeptFacilityInput:st,deptActivityInput:rt,setDeptActivityInput:nt,sliders:D,axiosInstance:v,fetchData:R,notify:U,openModal:ne,del:se,handleSliderUpload:na}),a==="Gallery"&&e.jsx(yi,{galleryImages:mt,galleryForm:ea,setGalleryForm:aa,openModal:ne,del:se}),a==="Institutes"&&e.jsx(vi,{institutes:Ha,openModal:ne,del:se}),a==="Student Corner"&&e.jsx(di,{sections:bt,openModal:ne,setScForm:ra,del:se}),a==="Contact Us"&&e.jsx(ki,{contactSub:m,setContactSub:k,keyPersons:Ra,setKeyPersonForm:ta,contactDepartments:Ga,setContactDeptForm:ia,contactInfo:Wa,setContactInfo:Le,openModal:ne,del:se,notify:U,axiosInstance:v}),a==="Settings"&&e.jsxs("div",{className:"flex flex-col items-center justify-center py-32 text-center text-slate-400",children:[e.jsx(ca,{size:48,className:"mb-4 opacity-30"}),e.jsx("p",{className:"font-semibold",children:"Settings Console — feature coming soon"})]})]},a+(z?._id||""))})]})})]}),e.jsxs(fa,{show:O,onClose:G,title:la.title,subtitle:la.subtitle,children:[B==="program"&&e.jsx(Qt,{editItem:f,programForm:Ya,setProgramForm:He,closeModal:G,fetchData:R,notify:U}),B==="testimonial"&&e.jsx(Xt,{editItem:f,testimonialForm:Oe,setTestimonialForm:Re,closeModal:G,fetchData:R,notify:U}),B==="milestone"&&e.jsx(Zt,{editItem:f,milestoneForm:Me,setMilestoneForm:Ge,closeModal:G,fetchData:R,notify:U}),B==="visionMission"&&e.jsx(ei,{editItem:f,vmForm:Ka,setVmForm:Ve,closeModal:G,fetchData:R,notify:U}),B==="coreValue"&&e.jsx(ai,{editItem:f,cvForm:Ja,setCvForm:We,closeModal:G,fetchData:R,notify:U}),B==="course"&&e.jsx(ti,{editItem:f,courseForm:Ia,setCourseForm:Ye,closeModal:G,fetchData:R,notify:U}),B==="step"&&e.jsx(ii,{editItem:f,stepForm:Qa,setStepForm:Ke,closeModal:G,fetchData:R,notify:U}),B==="rule"&&e.jsx(si,{editItem:f,ruleForm:Xa,setRuleForm:Je,closeModal:G,fetchData:R,notify:U}),B==="bond"&&e.jsx(ri,{editItem:f,bondForm:Za,setBondForm:Ie,closeModal:G,fetchData:R,notify:U}),B==="guideline"&&e.jsx(ni,{editItem:f,guidelineForm:et,setGuidelineForm:Qe,closeModal:G,fetchData:R,notify:U}),B==="department"&&e.jsx(li,{editItem:f,deptForm:Xe,setDeptForm:Ze,closeModal:G,fetchData:R,notify:U}),B==="gallery"&&e.jsx(ji,{editItem:f,formState:ea,setFormState:aa,closeModal:G,fetchData:R,notify:U,axiosInstance:v}),B==="institute"&&e.jsx(wi,{editItem:f,closeModal:G,fetchData:R,notify:U}),B==="keyPerson"&&e.jsx(Ni,{editItem:f,keyPersonForm:ht,setKeyPersonForm:ta,closeModal:G,fetchData:R,notify:U,axiosInstance:v}),B==="contactDept"&&e.jsx(Ci,{editItem:f,contactDeptForm:ut,setContactDeptForm:ia,closeModal:G,fetchData:R,notify:U,axiosInstance:v}),B==="studentCorner"&&e.jsx(oi,{editItem:f,scForm:ft,setScForm:ra,closeModal:G,fetchData:R,notify:U})]}),e.jsx(pi,{show:$,onClose:()=>I(!1),notify:U})]})};export{Si as default};
